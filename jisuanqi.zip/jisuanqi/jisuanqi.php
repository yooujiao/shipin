<!doctype html>
<html lang="zh_CN" manifest="demo.appcache">
<head>
<!-- 添加viewport标签 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!-- 禁止将数字变为电话号码 -->
<meta name="format-detection" content="telephone=no">
<!-- 允许全屏模式浏览，隐藏浏览器导航栏 -->
<meta name="apple-mobile-web-app-capable" content="yes">
<!-- link标签，它支持用户将网页创建快捷方式到桌面时，其图标变为我们自己定义的图标。 -->
<!-- <link rel="apple-touch-icon-precomposed" href="http://3gimg.qq.com/wap30/info/info5/img/logo_icon.png"> -->

<!--UC强制全屏-->
<meta name="x5-fullscreen" content="true">

<meta http-equiv="Expires" content="0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-control" content="no-cache">
<meta http-equiv="Cache" content="no-cache">
<meta charset='utf-8'>
<title>我的计算器</title>
<link id="link" type="text/css" rel="stylesheet">
<script src='../js/common.js'></script>
<script src='./jisuanqi.js'></script>
</head>

<body>
<!-- <table>
<tr><th colspan='5'>计算器</th></tr>
<tr><td>重量（斤）</td><td></td><td>单价（元）</td><td></td><td>钱</td></tr>
<tr>
<td><input id='text_1' type='text'></td>
<td id='td_id'></td>
<td><input id='text_2' type='text' oninput='jisuan()'></td>
<td>=</td>
<td><input id='text_3' type='text'></td>
</tr>
</table> -->

<section id='jisuanqi'>

<!-- 计算器模块 -->
<table id='table_jisuanqi'>
	<!-- <tr><th colspan='4'>我的计算器</th></tr> -->
	<tr>
		<td class='shuzi' id='note_1' onclick='show_hide_note_1()'>0</td>
		<td class='shuzi' id='note_2' onclick='show_hide_note_2()'>0</td>
		<td id='hide_num' onclick='show_m(this, 0)'>隐藏</td>
		<td class='zhankai' id='zhankai_i' onclick='show_m(this, 1)'>展开</td>
	</tr>
	
	<tr class='tr_none' style='display:none'>
		<td class='text_c'>
			<input id='mingzi' type='text' placeholder='名字'>
		</td>
		<td class='text_c'>
			<input id='huowu' type='text' placeholder='货物'>
		</td>
		<td class='text_c'>
			<input id='huohao' type='text' placeholder='货号'>
		</td>
		<td class='reset_c'>
			<input type='submit' value='重填' id='chongtian' onclick='reset_m()'>
		</td>
	</tr>
	
	<tr class='tr_none' style='display:none'>
		<td class='num_c'>
			<input id='num_1' type='text' placeholder='重量' readonly="readonly">
		</td>
		<td class='num_c'>
			<input id='sign' type='text' placeholder='+-x/' readonly="readonly">
		</td>
		<td class='num_c'>
			<input id='num_2' type='text' placeholder='单价' readonly="readonly">
		</td>
		<td class='num_c'>
			<input id='res_str' type='text' placeholder='钱' readonly="readonly">
			<!-- <textarea rows="" cols=""></textarea> -->
		</td>
	</tr>
	
	<tr id='show_num_i'>
		<td class='show_num' id='str_1'></td>
		<td class='show_num' id='str_2'></td>
		<td class='show_num' id='str_3'></td>
		<td class='show_num' id='str_res'></td>
	</tr>
	
	<tr>
		<td name='color' onclick='text(this)'>AC</td>
		<td name='color' class='green' onclick='get_sign_2(this)'>+/-</td>
		<td name='color' class='sign' onclick='get_sign(this)'>%</td>
		<td name='color' class='sign' onclick='get_sign(this)'>/</td>
	</tr>
	
	<tr>
		<td name='color' class='green' onclick='text(this)'>7</td>
		<td name='color' class='green' onclick='text(this)'>8</td>
		<td name='color' class='green' onclick='text(this)'>9</td>
		<td name='color' class='sign' onclick='get_sign(this)'>x</td>
	</tr>
	
	<tr>
		<td name='color' class='green' onclick='text(this)'>4</td>
		<td name='color' class='green' onclick='text(this)'>5</td>
		<td name='color' class='green' onclick='text(this)'>6</td>
		<td name='color' class='sign' onclick='get_sign(this)'>-</td>
	</tr>
	
	<tr>
		<td name='color' class='green' onclick='text(this)'>1</td>
		<td name='color' class='green' onclick='text(this)'>2</td>
		<td name='color' class='green' onclick='text(this)'>3</td>
		<td name='color' class='sign' onclick='get_sign(this)'>+</td>
	</tr>
	
	<tr>
		<td name='color' class='green' onclick='text(this)'>C</td>
		<td name='color' class='green' onclick='text(this)'>0</td>
		<td name='color' class='green' onclick='text(this)'>.</td>
		<td name='color' class='green' id='get_res' onclick='get_res()'>=</td>
	</tr>
</table>

<!-- 计算记录模块 -->
<table id='show_data_info_1' style='display:none'>
</table>

<!-- 记账本 -->
<table id='show_data_info_2' style='display:none'>
</table>

</section>
</body>
</html>