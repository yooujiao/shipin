var text_1='';
var text_2='';
var text_3='';
var str_res='';

var str_1='',
str_2='',
str_3='',
str_res_v='';
var url_pc='./jisuanqi_pc.css';
var url_phone='./jisuanqi_phone.css';
window.onload=function(){
	text_1=document.getElementById('num_1');
	text_2=document.getElementById('sign');
	text_3=document.getElementById('num_2');
	str_res=document.getElementById('res_str');

	str_1=document.getElementById('str_1');
	str_2=document.getElementById('str_2');
	str_3=document.getElementById('str_3');
	str_res_v=document.getElementById('str_res');
	
	pc_phone_css(url_pc, url_phone);
	
	//显示计算记录
	show_data_1();
	show_data_2();
}
/*function click_event(){
	addEventHandler(get_obj("search_b"), "click", function(){
		get_weather_m(1);
	});//查询天气	
}
function addEventHandler(target,type,fn){
	if(target.addEventListener){
		target.addEventListener(type,fn);
	}else{
		target.attachEvent("on"+type,fn);
	}
}*/

/*显示、隐藏/展开、关闭*/
function show_m(obj, num){
	
	//tr框架
	var b=document.getElementById('show_num_i');
	
	if(num==0){
		
		//展开、关闭按钮
		var d=document.getElementById('zhankai_i');
		
		if(b.style.display=='none'){
			if(d.innerHTML=='关闭'){
				return false;
			}
			b.style.display='table-row';
			obj.innerHTML='隐藏';
		}else{
			b.style.display='none';
			obj.innerHTML='显示';	
		}
		return false;
	}
	
	if(num==1){
		
		//名字、货物、货号、重填（tr框架）
		var a=document.getElementsByClassName('tr_none');
		
		//隐藏、显示按钮
		var e=document.getElementById('hide_num');
		
		for(var i=0; i<a.length; i++){
			//如果tr框架隐藏
			if(a[i].style.display=='none'){
				//显示tr框架
				a[i].style.display='table-row';
				obj.innerHTML='关闭';
				
				//隐藏4个圆
				b.style.display='none';
				//清除4个圆内的数据
				clear_num('AC');

				//隐藏、显示按钮变灰色，表示不可点击
				e.style.backgroundColor='gray';
			}else{
				a[i].style.display='none';
				obj.innerHTML='展开'; //obj代表当前点击的按钮
				
				//显示4个圆
				b.style.display='table-row';
				
				//隐藏、显示按钮颜色恢复正常
				e.style.backgroundColor='';
			}	
		}
	}

}
//重填
function reset_m(){
	var a=document.getElementById('mingzi');
	var b=document.getElementById('huowu');
	var c=document.getElementById('huohao');
	if(a.value=='' && b.value=='' && c.value==''){
		return false;
	}
	a.value='';
	b.value='';
	c.value='';
	return true;
}

//获取数字
function text(obj){
	
	var num=obj.innerHTML;
	
	/*var style=document.getElementsByName('color');
	for(var i=0; i<style.length; i++){
		style[i].style.color='';	
	}
	obj.style.color='#669999';*/
	
	//清除输入的数字
	var a=clear_num(num);
	if(a==false){
		return false;
	}
	
	//有计算结果不往下走
	if(flag_res==1){
		return false;		
	}
	//拼接用户选择的数字
	if(text_2.value.length==0){
		//动态获取用户当前输入的数字
		text_1.value+=num;
	}else{
		text_3.value+=num;
	}
	
	//显示当前输入的数据
	show_num();
	
	return true;//获取数字成功
	
	//编程技巧：如果用户完成了一件事就做个标记
}
function clear_num(num){
	if(num=='AC'){
		text_1.value='';
		text_2.value='';
		text_3.value='';
		str_res.value='';
		//flag_text=0;
		flag_res=0;
		
		//置空输入的数据
		show_num(0);
		
		//jisuan();
		var style=document.getElementsByClassName('green');
		for(var i=0; i<style.length; i++){
			style[i].style.backgroundColor='';	
		}
		var b=document.getElementsByClassName('sign');
		for(var i=0; i<b.length; i++){
			b[i].style.backgroundColor='';	
		}
		
		return false;
	}
	
	if(num=='C'){
		if(flag_res==1){
			return false;
		}
		if(text_1.value.length==0){
			return false;
		}
		
		if(text_3.value.length>0){
			text_3.value=text_3.value.substring(0, text_3.value.length-1); 
		}else{
			text_1.value=text_1.value.substring(0, text_1.value.length-1);
			if(text_1.value.length==0){
				text_2.value='';
				//置空输入的数据
				//show_num(0);
				//return false;
			}
		}
		//显示当前输入的数据
		show_num();
		
		//jisuan();
		return false;
	}	
}
//显示输入的数据
function show_num(num){
	if(num==0){
		str_1.innerHTML='';
		str_2.innerHTML='';
		str_3.innerHTML='';
		str_res_v.innerHTML='';
		return false;
	}
	var a=document.getElementById('show_num_i');//tr框架包含数字结果
	var b=document.getElementById('zhankai_i');//展开按钮
	if(b.innerHTML=='关闭'){
		a.style.display='none';
		return false; //以下不显示
	}
	if(a.style.display=='none'){
		a.style.display='table-row';
		document.getElementById('hide_num').innerHTML='隐藏';
	}
	
	//获取三个input的值
	str_1.innerHTML=text_1.value;
	str_2.innerHTML=text_2.value;
	str_3.innerHTML=text_3.value;
	
	//如果有计算结果
	if(flag_res==1){
		//获取插入计算结果进框架
		str_res_v.innerHTML=str_res.value;
		//清空三个参与计算的数字
		str_1.innerHTML='';
		str_2.innerHTML='';
		str_3.innerHTML='';
	}
	
	return true; //显示成功
	
	//总结：减少函数调用有利于提升程序性能
}
//获取+-*/
function get_sign(obj){
	
	//如果计算结果是错误就不往下走
	if(str_res.value=='错误'){
		return false;
	}
	
	//如果计算结果包含元就不往下走
	if(str_res.value.lastIndexOf('元')>=0){
		return false;
	}
	
	//如果计算结果长度大于0
	if(str_res.value.length>0){

		//计算结果给第一个数
		text_1.value=str_res.value;
		
		//置空计算结果
		str_res.value='';

		//置空符号和第三个数
		text_2.value='';
		text_3.value='';
		
		flag_res=0;//0表示数字可以输入
		
		var style=document.getElementsByClassName('green');
		for(var i=0; i<style.length; i++){
			style[i].style.backgroundColor='';	
		}

		//置空输入的数据
		show_num(0);
	}
	
	//如果第一个数长度等于0
	if(text_1.value.length==0){
		return false;
	}
	
	//清除算术符号的背景颜色
	var style=document.getElementsByClassName('sign');
	for(var i=0; i<style.length; i++){
		style[i].style.backgroundColor='';	
	}	
	
	//给第二个格子加上算术符号
	text_2.value=obj.innerHTML;
	//给点击的算术符号加上背景颜色
	obj.style.backgroundColor='#669999';
	
	//如果第一个数不包含斤字
	var num=text_1.value.indexOf('斤');
	if(num==-1){
		var a=document.getElementById('zhankai_i');
		//如果展开按钮等于关闭(商业计算模式)
		if(a.innerHTML=='关闭'){
			text_1.value=text_1.value+'斤';
		}
	}
	
	//显示当前输入的数据
	show_num();

	return true;//获取+-*/成功
}
//获取-
function get_sign_2(obj){
	
	//有计算结果不往下走
	if(flag_res==1){
		return false;		
	}
	
	if(str_res.value=='错误'){
		return false;
	}
	
	if(text_2.value.length==0){
		var a=text_1.value.indexOf('-');
		if(a==-1){
			text_1.value='-'+text_1.value;
		}else{
			text_1.value=text_1.value.substring(1, text_1.value.length);
		}
	}else{
		var b=text_3.value.indexOf('-');
		if(b==-1){
			text_3.value='-'+text_3.value;
		}else{
			text_3.value=text_3.value.substring(1, text_3.value.length);
		}
	}
	
	//显示当前输入的数据
	show_num();
	
	return true;//获取-成功
}

var flag_res=0;
var arr_1=new Array();
var arr_2=new Array();
var arr_3=new Array();
var arr_res=new Array();
//计算结果
function get_res(){
	if(text_1.value.length==0){
		return false;
	}
	if(text_2.value.length==0){
		return false;
	}
	if(text_3.value.length==0){
		return false;
	}
	if(str_res.value.length>0){
		return false;
	}
	if(text_1.value=='-' && text_1.value.length==1){
		return false;
	}
	if(text_3.value=='-' && text_3.value.length==1){
		return false;
	}
	if(str_res.value.lastIndexOf('元')>=0){
		return false;
	}
	if(str_res.value=='错误'){
		return false;
	}
	
	var num_1=parseFloat(text_1.value);
	var num_2=parseFloat(text_3.value);
	var a='';
	switch(text_2.value)//开始计算
	{
		case '+':
		a=(num_1+num_2).toFixed(2);//a是string类型
		a=get_end_res(a);
		break;
		
		case '-':
		a=(num_1-num_2).toFixed(2);
		a=get_end_res(a);
		break;

		case 'x':
		a=(num_1*num_2).toFixed(2);
		a=get_end_res(a);
		break;

		case '/':
		a=(num_1/num_2).toFixed(2);
		a=get_end_res(a);
		break;

		case '%':
		a=num_1%num_2;
		a=a;
		break;
		
		default:
		a='NaN';
	}
	
	//如果计算结果是NaN(不往下走)
	if(a=='NaN'){
		str_res.value='错误';
		flag_res=1;
		return false;
	}
	
	//计算结果之后做个标记
	flag_res=1;
	
	//如果展开按钮等于关闭(商业计算模式)
	var b=document.getElementById('zhankai_i');//展开按钮
	if(b.innerHTML=='关闭'){
		str_res.value=a+'元';
	}else{
		str_res.value=a;
	}
	
	//计算结果之后将数字改为灰色(表示不可点击)
	var style=document.getElementsByClassName('green');
	for(var i=0; i<style.length; i++){
		style[i].style.backgroundColor='gray';	
	}
	
	//如果计算结果中包含元则算术符号的背景颜色全部改为灰色(表示不可点击)
	var d=document.getElementsByClassName('sign');
	if(str_res.value.lastIndexOf('元')>=0){
		for(var j=0; j<d.length; j++){
			d[j].style.backgroundColor='gray';	
		}	
	}
	
	//计算结果之后清除算术符号的背景颜色
	for(var k=0; k<d.length; k++){
		d[k].style.backgroundColor='';	
	}
	
	//将格子中的参数和计算结果保存到数组
	/*arr_1.push(text_1.value);
	arr_2.push(text_2.value);
	arr_3.push(text_3.value);
	arr_res.push(str_res.value);*/
	
	//显示计算结果
	show_num();
	
	//保存数据
	if(str_res.value.lastIndexOf('元')==-1){
		save_num(text_1.value, text_2.value, text_3.value, str_res.value);
	}else{
		save_data(text_1.value, text_2.value, text_3.value, str_res.value);
	}
	
	//从浏览器上获取数据并显示数据到网页
	show_data_1();
	show_data_2();
	
	return true;//表示计算成功
}
//计算最后的结果
function get_end_res(e){
	var end_num=e.substr(-2);//end_num是string类型
	if(end_num=='00'){
		//计算之后e是string类型
		e=e.substring(0, e.length-3);
	}
	return e;//最后的计算结果 
}
//记录计算数据到浏览器localstorage
function save_num(a, b, c, d){
	//获取localstorage对象
	var storage=window.localStorage;
	//判断浏览器是否支持localStorage
	if(!storage){
		alert("浏览器不支持localstorage，无法为你保存计算记录\n请更换浏览器");
		return false;
	}
	
	//获取数组的最后一个值
	/*var str_num_1=arr_1[arr_1.length-1];//.join('->')
	var str_num_2=arr_2[arr_2.length-1];
	var str_num_3=arr_3[arr_3.length-1];
	var str_num_res=arr_res[arr_res.length-1];*/

	var str_num_1=a;
	var str_num_2=b;
	var str_num_3=c;
	var str_num_res=d;
	var date_time_v=date_time(0);
	
	var key='';
	var arr=new Array();
	for(var i=0; i<storage.length; i++){
		//获取storage键
		key=storage.key(i);
		//如果storage键中包含data_
		if(key.indexOf('num_')==0){
			//获取key后面的部分
			arr.push(key.substr(4));	
		}
	}
	//求数组的最大值
	var max=Math.max.apply(null, arr);
	
	//如果localstorage上没有data键
	var num=0;
	if(arr.length==0){
		num=0;
	}else{
		num=max+1;
	}

	//将数据存入对象中
	var data={
		id:num,
		num_1:str_num_1,
		num_2:str_num_2,
		num_3:str_num_3,
		num_res:str_num_res,
		date_time:date_time_v,
		key:'num_'+num
	};
	//将data对象转为json字符串
	var str_2=JSON.stringify(data);

	//将json字符串数据存入localstorage
	storage.setItem('num_'+num, str_2);
}
//记录数据到浏览器localstorage
function save_data(d, e, f, g){
	//获取localstorage对象
	var storage=window.localStorage;
	//判断浏览器是否支持localStorage
	if(!storage){
		alert("浏览器不支持localstorage，无法为你保存计算记录\n请更换浏览器");
		return false;
	}
	
	//获取input对象
	var a=document.getElementById('mingzi');
	var b=document.getElementById('huowu');
	var c=document.getElementById('huohao');
	//定义变量用于存放数据
	var mingzi_str='';
	var huowu_str='';
	var huohao_str='';
	
	//获取名字、货物、货号数据
	if(a.value.length==0){
		mingzi_str='无';
	}else{
		mingzi_str=a.value;	
	}
	if(b.value.length==0){
		huowu_str='无';
	}else{
		huowu_str=b.value;	
	}
	if(c.value.length==0){
		huohao_str='无';
	}else{
		huohao_str=c.value;	
	}

	//获取数组的最后一个值
	/*var str_num_1=arr_1[arr_1.length-1];//.join('->')
	var str_num_2=arr_2[arr_2.length-1];
	var str_num_3=arr_3[arr_3.length-1];
	var str_num_res=arr_res[arr_res.length-1];*/
	var date_time_v=date_time(0);
	
	var key='';
	var arr=new Array();
	for(var i=0; i<storage.length; i++){
		//获取storage键
		key=storage.key(i);
		//如果storage键中包含data_
		if(key.indexOf('data_')==0){
			//获取key后面的部分
			arr.push(key.substr(5));	
		}
	}
	//求数组的最大值
	var max=Math.max.apply(null, arr);
	
	//如果localstorage上没有data键
	var num=0;
	if(arr.length==0){
		num=0;
	}else{
		num=max+1;
	}

	//将数据存入对象中
	var data={
		id:num,
		mingzi:mingzi_str,
		huowu:huowu_str,
		huohao:huohao_str,
		num_1:d,
		num_2:e,
		num_3:f,
		num_res:g,
		date_time:date_time_v,
		key:'data_'+num
	};
	//将data对象转为json字符串
	var str=JSON.stringify(data);

	//将json字符串数据存入localstorage
	storage.setItem('data_'+num, str);
}
//二维数组排序
function sort_id(arr, key){
	arr.sort(
		function(a, b){
			//var a1=parseInt(a['id']);  
			//var b1=parseInt(b['id']);
			var x=a[key];
			var y=b[key];
			if(x>y){  
				return -1;  
			}else if(x<y){  
				return 1;  
			}else{
				return 0;
			}
			
			//return b1-a1;
				
		}
	);
	
	//alert('成功');
	return arr; 	
}
function sort_obj(arr, key){
		return arr.sort(function(a, b){
		var x = a[key];
		var y = b[key];
		return x - y;
		//return y - x;
		//或者 return x > y ? 1 : (x < y ? -1 : 0);
	});
}
//显示、隐藏计算记录
function show_hide_note_1(){
	var a=document.getElementById('show_data_info_1');
	var b=document.getElementById('note_1');
	if(a.style.display=='none'){
		a.style.display='block';
		b.style.color='green';
	}else{
		a.style.display='none';
		b.style.color='red';
		show_data_1();
	}
}
//显示、隐藏记账本
function show_hide_note_2(){
	var a=document.getElementById('show_data_info_2');
	var b=document.getElementById('note_2');
	//var b=document.getElementById('show_data_info_1');
	if(a.style.display=='none'){
		a.style.display='block';
		b.style.color='green';
	}else{
		a.style.display='none';
		b.style.color='red';
		show_data_2();
	}
}

//插入localstorage数据到网页框架
function show_data_1(){
	var storage=window.localStorage;
	var key='';
	var arr=new Array();
	//获取data键数据
	for(var i=storage.length-1; i>=0; i--){
		
		//获取storage键
		key=storage.key(i);
		
		//如果storage键中包含data_
		if(key.indexOf('num_')==0){
			//获取num键和num值(json字符串)
			arr[key]=storage[key];
		}
	}	
	
	//遍历arr二维数组
	var arr_num=new Array();
	for(let key in arr){
		//获取num键的值(对象)
		arr_num.push(JSON.parse(arr[key]));
	}
	
	//对data_arr数组进行倒序排序
	sort_id(arr_num, 'id');
	
	var str='';
	str+='<tr>'
	+'<td class="num_close_del" colspan="9"><span>计算记录('+arr_num.length+'条)</span>'
	+'<a onclick="show_hide_note_1()">关闭</a>'
	+'<a onclick="static_num(2)">删除</a></td>'
	+'</tr>';
	
	//显示添加成功的记录
	document.getElementById('note_1').innerHTML=arr_num.length;
	
	//如果浏览器上没有data数据
	if(arr_num.length==0){
		document.getElementById('show_data_info_1').innerHTML=str;
		return false;
	}
		
	str+='<tr>'
	+'<th class="nav">数1</th><th class="nav">符号</th>'
	+'<th class="nav">数2</th><th class="nav">等号</th><th class="nav">数3</th>'
	+'<th class="nav">时间</th>'
	+'<th class="nav">ID</th>'
	+'<th class="nav">行号</th>'
	+'<th class="num_change_c"><span onclick="static_num(0)">反选</span></th>'
	+'</tr>';
	
	var num_sum_1=0;
	//var num_sum_3=0;
	var num_sum_res=0;
	var key='';
	var num=0;
	var arr_id=new Array();
	//开始计算
	for(var z=0; z<arr_num.length; z++){
		//显示计算记录
		key=arr_num[z]['key'];
		
		num++;
		
		str+='<tr id=tr_'+key+'>'
		+'<td class=num_'+key+'>'+arr_num[z]['num_1']+'</td>'
		+'<td class=num_'+key+'>'+arr_num[z]['num_2']+'</td>'
		+'<td class=num_'+key+'>'+arr_num[z]['num_3']+'</td>'
		+'<td class=num_'+key+'>=</td>'
		+'<td class=num_'+key+'>'+arr_num[z]['num_res']+'</td>'
		+'<td class="date_time_1">'+arr_num[z]['date_time']+'</td>'
		+'<td id="ID'+key+'">ID'+arr_num[z]['id']+'</td>'
		+'<td>'+num+'</td>'
		+'<td><input type="checkbox" name="num_jilu" value="'+key+'" onclick="static_num(1)"></td>'
		+'</tr>';
		
		//求第一个数的和
		num_sum_1+=parseFloat(arr_num[z]['num_1']);

		//求第三个数的和
		//num_sum_3+=parseFloat(arr_num[z]['num_3']);
		
		//求第四个数的和
		num_sum_res+=parseFloat(arr_num[z]['num_res']);

		//将id的值存入一个新数组中
		arr_id.push(arr_num[z]['id']);
	}
	
	num_sum_1=get_end_res(num_sum_1.toFixed(2));//toFixed之后是字符串
	//num_sum_3=get_end_res(num_sum_3.toFixed(2));
	num_sum_res=get_end_res(num_sum_res.toFixed(2));
	
	//插入计算记录的和到td框架
	str+='<tr><td>'+num_sum_1+'</td>'
	+'<td></td><td></td><td></td><td>'+num_sum_res+'</td><td colspan="4"></td></tr>';

	//插入数据到table框架
	document.getElementById('show_data_info_1').innerHTML=str;
	
	//求id的最大值
	var max=Math.max.apply(null, arr_id);

	//对最后一条计算记录加颜色
	var a=document.getElementsByClassName('num_num_'+max);
	for(var j=0; j<a.length; j++){
		a[j].style='color:green;font-weight:bold';	
	}

	return true;

	//总结：关联数组比索引数组靠谱，关联数组的键非常有用
	//二维数组比一维数组靠谱
}

//插入localstorage数据到网页框架
function show_data_2(){
	var storage=window.localStorage;
				
	var key='';
	var arr=new Array();
	//获取data键数据
	for(var i=storage.length-1; i>=0; i--){
	//for(var i=0; i<storage.length; i++){
		//获取storage键
		key=storage.key(i);
		
		//如果storage键中包含data_
		if(key.indexOf('data_')==0){
			//获取data键和data值(json字符串)
			arr[key]=storage[key];
		}
	}	
	
	//遍历数组
	var data_arr=new Array();
	for(let key in arr){
		//获取data值(对象)
		data_arr.push(JSON.parse(arr[key]));
	}
	
	/*var arr_obj=[
		{id:1, name:"张三"},
		{id:2, name:"王五"},
		{id:3, name:"张三"},
		{id:4, name:"李四"}
	];*/
	//获取对象的下标
	//var keys=Object.keys(arr_obj);
	/*var str='';
	for(let key in data_arr){
		str+=data_arr[key]['mingzi']+'\n';
	}
	alert(str);*/
	//return false;
	
	//对数组对象data_arr排序
	sort_id(data_arr, 'mingzi');
	
	var str='';
	str+='<tr><td class="data_close_del" colspan="9"><span>记账本('+data_arr.length+'条)</span>'
	+'<a id="close_a" onclick="show_hide_note_2()">关闭</a>'
	+'<a id="del_a" onclick="change_data(2)">删除</a></td></tr>';
	
	//显示添加成功的记录
	document.getElementById('note_2').innerHTML=data_arr.length;
	
	//如果浏览器上没有data数据
	if(data_arr.length==0){
		document.getElementById('show_data_info_2').innerHTML=str;
		return false;
	}

	str+='<tr><th class="nav">名字</th><th class="nav">货物</th><th class="nav">货号</th>'
	+'<th class="nav">重量</th><th class="nav">符号</th>'
	+'<th class="nav">单价</th><th class="nav">钱</th>'
	+'<th class="nav">时间</th>'
	+'<th class="data_change_c"><span onclick="change_data(0)">反选</span></th></tr>';
	
	var num_sum_1=0;
	var num_sum_res=0;
	var key='';
	var arr_id=new Array();
	var weight=0;
	var	money=0;
	var flag_num=0;
	var str_weight_mony='';
	var arr_weight_money=new Array();
	//开始计算
	for(var z=0; z<data_arr.length; z++){
	//for(let key in data_arr){
		
		//显示计算记录
		key=data_arr[z]['key'];
		
		str+='<tr id=tr_'+key+'>'
		+'<td id=td_'+key+'>'+data_arr[z]['mingzi']+'</td>'
		+'<td>'+data_arr[z]['huowu']+'</td>'
		+'<td>'+data_arr[z]['huohao']+'</td>'
		+'<td class=num_'+key+'>'+data_arr[z]['num_1']+'</td>'
		+'<td class=num_'+key+'>'+data_arr[z]['num_2']+'</td>'
		+'<td class=num_'+key+'>'+data_arr[z]['num_3']+'</td>'
		+'<td class=num_'+key+'>'+data_arr[z]['num_res']+'</td>'
		+'<td class="date_time_2">'+data_arr[z]['date_time']+'</td>'
		+'<td><input type="checkbox" name="data_jilu" value="'+key+'" onclick="change_data(1)"></td>'
		+'</tr>';
		
		if(z<data_arr.length-1){

			//如果前一条数据和后一条数据一样
			if(data_arr[z]['mingzi']==data_arr[z+1]['mingzi']){
				//记录重量
				weight+=parseFloat(data_arr[z]['num_1']);
				//记录钱
				money+=parseFloat(data_arr[z]['num_res']);
			}else{
				//如果前一条数据和后一条数据不一样
				weight+=parseFloat(data_arr[z]['num_1']);
				money+=parseFloat(data_arr[z]['num_res']);
				
				/*str+='<tr>'
				+'<td>'+data_arr[z]['mingzi']+'<br>重量合计:'+weight+'金钱合计:'+money+'</td>'
				+'</tr>';*/
				
				//以字符串的形式记录名字重量钱
				str_weight_money=data_arr[z]['mingzi']+'->'+weight+'->'+money;
				//将字符串加入到数组中
				arr_weight_money.push(str_weight_money);
				
				//记录新值
				flag_num=z+1;
				
				//如果后一条数据是新值就重置weight和money的值
				weight=0;
				money=0;
			}
		
		}
		
		if(z==data_arr.length-1){
			//情况不一样重置weight和money的值
			weight=0;
			money=0;
			
			for(var y=flag_num; y<=z; y++){
				weight+=parseFloat(data_arr[y]['num_1']);
				money+=parseFloat(data_arr[y]['num_res']);
			}
			
			//以字符串的形式记录名字重量钱
			str_weight_money=data_arr[z]['mingzi']+'->'+weight+'->'+money;
			//将字符串加入到数组中
			arr_weight_money.push(str_weight_money);
		}

		//求第一个数的和
		num_sum_1+=parseFloat(data_arr[z]['num_1']);
		
		//求第四个数的和
		num_sum_res+=parseFloat(data_arr[z]['num_res']);

		//将id的值存入一个新数组中
		arr_id.push(data_arr[z]['id']);
	}
	
	num_sum_1=get_end_res(num_sum_1.toFixed(2));//toFixed之后是字符串
	num_sum_res=get_end_res(num_sum_res.toFixed(2));
	
	//插入计算记录的和到框架
	str+='<tr id="tr_sum"><td colspan="3"></td><td>'+num_sum_1+'斤</td>'
	+'<td></td><td></td><td>'+num_sum_res+'元</td><td colspan="2"></td></tr>';
	
	var arr_1=new Array();
	for(let key in arr_weight_money){
		arr_1=arr_weight_money[key].split('->');
		str+='<tr>';
		str+='<td>'+arr_1[0]+'</td><td>'
		+arr_1[1]+'斤</td><td>'+arr_1[2]+'元</td><td colspan="6"></td>';
		str+='</tr>';
	}

	//插入数据到网页框架
	document.getElementById('show_data_info_2').innerHTML=str;
	
	//求id的最大值
	var max=Math.max.apply(null, arr_id);
	
	//给第一行数据加颜色
	//var name=document.getElementById('td_data_'+max);//获取第一行数据中的名字
	//如果名字的长度超过1(不是无)
	//if(name.innerHTML.length>1){
		//name.style='color:green;font-weight:bold';
	//}
	var a=document.getElementsByClassName('num_data_'+max);
	for(var j=0; j<a.length; j++){
		a[j].style='color:green;font-weight:bold';	
	}

	return true;

	//总结：关联数组比索引数组靠谱，关联数组的键非常有用
	//二维数组比一维数组靠谱
}
//获取复选框checkbox的值
function static_num(num) 
{   
	//获取checkbox复选框标记(数组)
	var items=document.getElementsByName('num_jilu');
	
	//反选checkbox
	if(num==0){
		var a='';
		for(var i=0; i<items.length; i++){
			if(items[i].checked==false){
				items[i].checked=true;
				
				//获取checkbox复选框的值
				a=items[i].value;
				
				a=document.getElementById('ID'+a);
				a.style='color:red';
			}else{
				items[i].checked=false;

				//获取checkbox复选框的值
				a=items[i].value;
				
				a=document.getElementById('ID'+a);
				a.style='color:black';
			}
		}
		return false;//一个函数实现多个功能
	}
	
	//单选checkbox
	if(num==1){
		var b='';
		for(i=0; i<items.length; i++){
			if(items[i].checked){
				//获取checkbox复选框的值
				b=items[i].value;
				document.getElementById('ID'+b).style='color:red';
			}else{
				//获取checkbox复选框的值(data键)
				b=items[i].value;
				
				//获取名字
				/*var name=document.getElementById('hanghao_'+b);
				//如果是第一行并且名字的长度超过1就加上绿色
				if(i==0 && name.innerHTML.length>1){
					name.style='color:green;font-weight:bold';
				}*/
				
				//如果不是第一行就恢复原来的颜色
				//if(i!=0){
					document.getElementById('ID'+b).style='color:black';
				//}
			}
		}
		return false;
	}
	
	if(num==2){
		//获取checkbox的值
		var arr=new Array();
		var c='';
		for(i=0; i<items.length; i++){
			if(items[i].checked){
				//c=parseInt(items[i].value);
				//获取被选中的checkbox复选框的值(localstorage的data键)
				c=items[i].value;
				//记录要删除的data键
				arr.push(c);
			}
		}
		//复选框的值就是数组的下标
		//alert('选择的个数为：'+typeof arr.length);
		
		if(arr.length==0){
			alert('请选择要删除的记录');
			return false;
		}
		
		//获取被选中的ID
		var str='';
		for(var j=0; j<arr.length; j++){
			if(j==arr.length-1){
				str+=document.getElementById('ID'+arr[j]).innerHTML;
				break;
			}
			str+=document.getElementById('ID'+arr[j]).innerHTML+'->';
		}
		
		if(!confirm('真的要删除以下记录？\n'+str)){
			return false;		
		}
		
		//执行删除操作
		del_row_2(arr);
	}
}
//获取复选框checkbox的值
function change_data(num) 
{   
	//获取checkbox复选框标记(数组)
	var items=document.getElementsByName('data_jilu');
	
	//反选checkbox
	if(num==0){
		var a='';
		for(var i=0; i<items.length; i++){
			if(items[i].checked==false){
				items[i].checked=true;
				
				//获取checkbox复选框的值
				a=items[i].value;
				
				a=document.getElementById('td_'+a);
				a.style='color:red';
			}else{
				items[i].checked=false;

				//获取checkbox复选框的值
				a=items[i].value;
				
				a=document.getElementById('td_'+a);
				a.style='color:black';
			}
		}
		return false;//一个函数实现多个功能
	}
	
	//单选checkbox
	if(num==1){
		var b='';
		for(i=0; i<items.length; i++){
			if(items[i].checked){
				//获取checkbox复选框的值
				b=items[i].value;
				document.getElementById('td_'+b).style='color:red';
			}else{
				//获取checkbox复选框的值(data键)
				b=items[i].value;
				
				//获取名字
				/*var name=document.getElementById('hanghao_'+b);
				//如果是第一行并且名字的长度超过1就加上绿色
				if(i==0 && name.innerHTML.length>1){
					name.style='color:green;font-weight:bold';
				}*/
				
				//如果不是第一行就恢复原来的颜色
				//if(i!=0){
					document.getElementById('td_'+b).style='color:black';
				//}
			}
		}
		return false;
	}
	
	if(num==2){
		//获取checkbox的值
		var arr=new Array();
		var c='';
		for(i=0; i<items.length; i++){
			if(items[i].checked){
				//c=parseInt(items[i].value);
				//获取被选中的checkbox复选框的值(localstorage的data键)
				c=items[i].value;
				//记录要删除的data键
				arr.push(c);
			}
		}
		//复选框的值就是数组的下标
		//alert('选择的个数为：'+typeof arr.length);
		
		if(arr.length==0){
			alert('请选择要删除的记录');
			return false;
		}
		
		//获取被选中的名字
		var str='';
		for(var j=0; j<arr.length; j++){
			if(j==arr.length-1){
				str+=document.getElementById('td_'+arr[j]).innerHTML;
				break;
			}
			str+=document.getElementById('td_'+arr[j]).innerHTML+'->';
		}
		
		if(!confirm('真的要删除以下记录？\n'+str)){
			return false;		
		}
		
		//执行删除操作
		del_row_2(arr);
	}
}
//删除localstorage上的data数据
function del_row_2(arr){
	var storage=window.localStorage;
	if(confirm('删除不可恢复，真的要删除选择的'+arr.length+'条记录？')){
		for(var i=0; i<arr.length; i++){
			storage.removeItem(arr[i]);
		}
	}else{
		return false;
	}
	
	alert('成功删除了'+arr.length+'条记录');
	
	//重新从浏览器上取数据并显示计算记录
	show_data_1();
	show_data_2();
}

/*if(z<data_arr.length-1){
//如果前一条数据和后一条数据一样
if(data_arr[z]['mingzi']==data_arr[z+1]['mingzi']){
//记录重量
weight+=parseFloat(data_arr[z]['num_1']);
//记录钱
money+=parseFloat(data_arr[z]['num_res']);
}else{
				//如果前一条数据和后一条数据不一样
				weight+=parseFloat(data_arr[z]['num_1']);
				money+=parseFloat(data_arr[z]['num_res']);
				
				str+='<tr>'
				+'<td>'+data_arr[z]['mingzi']+'<br>重量合计:'+weight+'金钱合计:'+money+'</td>'
				+'</tr>';
				
				//以字符串的形式记录名字重量钱
				str_weight_money=data_arr[z]['mingzi']+'->'+weight+'->'+money;
				//将字符串加入到数组中
				arr_weight_money.push(str_weight_money);
				
				//记录新值
				flag_num=z+1;
				
				//如果后一条数据是新值就重置weight和money的值
				weight=0;
				money=0;
			}
		
		}
		
		if(z==data_arr.length-1){
			//情况不一样重置weight和money的值
			weight=0;
			money=0;
			
			//如果没有新值
			if(flag_num==0){
				flag_num=0;		
			}
			
			/*for(var y=flag_num; y<=z; y++){
				weight+=parseFloat(data_arr[y]['num_1']);
				money+=parseFloat(data_arr[y]['num_res']);
			}
			
			//以字符串的形式记录名字重量钱
			str_weight_money=data_arr[z]['mingzi']+'->'+weight+'->'+money;
			//将字符串加入到数组中
			arr_weight_money.push(str_weight_money);
			
			/*str+='<tr>'
			+'<td>'+data_arr[z]['mingzi']+'<br>重量合计:'+weight+'金钱合计:'+money+'</td>'
			+'</tr>';
			
			var arr_1=new Array();
	for(let key in arr_weight_money){
		arr_1=arr_weight_money[key].split('->');
		str+='<tr>';
		str+='<td>'+arr_1[0]+'合计：</td><td>'+arr_1[1]+'斤</td><td>'+arr_1[2]+'元</td>';
		str+='</tr>';
	}
		}*/

/*//保存数据到浏览器LocalStorage
function SaveLocalStorage(){
	var storage=window.localStorage;
	//判断浏览器是否支持localStorage
	if(!storage){
		alert("浏览器不支持localstorage，无法为你保存计算记录\n请更换浏览器");
		return false;
	}
	
	//alert(date_time(0));return;
	var a=document.getElementById('mingzi');
	var b=document.getElementById('huowu');
	var c=document.getElementById('huohao');
	var mingzi='';
	var huowu='';
	var huohao='';
	//获取名字、货物、货号
	if(a.value.length==0){
		mingzi='无';
	}else{
		mingzi=a.value;	
	}
	if(b.value.length==0){
		huowu='无';
	}else{
		huowu=b.value;	
	}
	if(c.value.length==0){
		huohao='无';
	}else{
		huohao=c.value;	
	}
	
	//获取数组的最后一个值
	var str_num_1=arr_1[arr_1.length-1];//.join('->')
	var str_num_2=arr_2[arr_2.length-1];
	var str_num_3=arr_3[arr_3.length-1];
	var str_num_res=arr_res[arr_res.length-1];
	var date_time_v=date_time(0);
	
	//通过key来获取value
	var dt_mingzi=storage['mingzi'];
	var dt_huowu=storage['huowu'];
	var dt_huohao=storage['huohao'];
	
	var dt_1=storage['str_num_1'];
	var dt_2=storage['str_num_2'];
	var dt_3=storage['str_num_3'];
	var dt_res=storage['str_num_res'];
	var dt_date_time=storage['date_time'];

	if(dt_1==null || dt_1==''){
		//给localStorage设置初始值
		storage['mingzi']=mingzi;
		storage['huowu']=huowu;
		storage['huohao']=huohao;
		
		storage['str_num_1']=str_num_1;
		storage['str_num_2']=str_num_2;
		storage['str_num_3']=str_num_3;
		storage['str_num_res']=str_num_res;
		storage['date_time']=date_time_v;

		//alert('浏览器上没有数据了');
		//return false;
	}else{
		//将内存中的数据存入localStorage
		storage['mingzi']=mingzi+'->'+dt_mingzi;
		storage['huowu']=huowu+'->'+dt_huowu;
		storage['huohao']=huohao+'->'+dt_huohao;
		
		storage['str_num_1']=str_num_1+'->'+dt_1;
		storage['str_num_2']=str_num_2+'->'+dt_2;
		storage['str_num_3']=str_num_3+'->'+dt_3;
		storage['str_num_res']=str_num_res+'->'+dt_res;
		storage['date_time']=date_time_v+'->'+dt_date_time;
	}
	
	return true;
	
	//清空所有的key-value数据。
	//localStorage.clear();
	//alert(localStorage.length);	
}*/
/*//定义全局数组
var str_arr_mingzi=new Array(),
str_arr_huowu=new Array(),
str_arr_huohao=new Array(),
str_arr_1=new Array(),
str_arr_2=new Array(),
str_arr_3=new Array(),
str_arr_res=new Array(),
time=new Array();
function GetLocalStorage(){
	//重新从浏览器上取数据之前置空全局数组
	if(str_arr_1.length>0){
		str_arr_1.length=0;
		str_arr_2.length=0;
		str_arr_3.length=0;
		str_arr_res.length=0;
		time.length=0;

		str_arr_mingzi.length=0;
		str_arr_huowu.length=0;
		str_arr_huohao.length=0;
	}
	
	var storage=window.localStorage;
	if(storage.length==0){
		//alert('浏览器上没有数据了');
		return false;	
	}
	
	//获取LocalStorage数据
	var dt_1=storage['str_num_1'];//通过key来获取value
	if(dt_1==null || dt_1==''){
		return false;
	}
	
	var dt_2=storage['str_num_2'];
	var dt_3=storage['str_num_3'];
	var dt_res=storage['str_num_res'];
	var dt_date_time=storage['date_time'];

	var dt_mingzi=storage['mingzi'];
	var dt_huowu=storage['huowu'];
	var dt_huohao=storage['huohao'];
	
	//将localStorage上的数据存入数组(内存)
	str_arr_mingzi=dt_mingzi.split('->');//开始取数据(字符串转数组)
	str_arr_huowu=dt_huowu.split('->');
	str_arr_huohao=dt_huohao.split('->');

	str_arr_1=dt_1.split('->');//开始取数据
	str_arr_2=dt_2.split('->');
	str_arr_3=dt_3.split('->');
	str_arr_res=dt_res.split('->');
	time=dt_date_time.split('->');
	
	return true;	
}*/
//显示localstorage数据到浏览器
/*function show_data(){
	
	//var e=document.getElementById('show_data_info');
	
	//获取localstorage上的数据
	var a=GetLocalStorage();
	
	if(a==false){
		//alert('浏览器上没有数据了');
		
		//e.style.display='none';//隐藏table
		//return false;
	}
	//alert(str_arr_1.length);
	
	//成功获取数据就获取数组长度
	var length=str_arr_1.length;
	
	//e.style.display='block';//显示table
	
	var str='';
	str+='<tr><td id="jilu_close" colspan="9"><a>计算记录('+length+'条)</a>'
	+'<span id="close_ai" onclick="show_hide_note_m()">关闭</span>'
	+'<span id="del_ai" onclick="static_num(0)">删除</span></td></tr>';
	
	//显示添加成功的记录
	document.getElementById('note').innerHTML=length;

	if(length==0){
		document.getElementById('show_data_info').innerHTML=str;
		return false;
	}

	str+='<tr><th class="nav">名字</th><th class="nav">货物</th><th class="nav">货号</th>'
	+'<th class="nav">重量</th><th class="nav">符号</th>'
	+'<th class="nav">单价</th><th class="nav">钱</th>'
	+'<th class="nav">时间</th><th class="change_all_ac">'
	+'<span id="change_all" onclick="static_num(1)">反选</span></th></tr>';
	
	var num_sum_1=0;
	var num_sum_res=0;
	//开始计算
	for(var i=0; i<length; i++){
		
		//显示计算记录
		str+='<tr id=tr_'+i+'><td id=td_'+i+'>'+str_arr_mingzi[i]+'</td>'
		+'<td>'+str_arr_huowu[i]+'</td>'+'<td>'+str_arr_huohao[i]+'</td>'
		+'<td id=num_1'+i+'>'+str_arr_1[i]+'</td><td id=num_2'+i+'>'
		+str_arr_2[i]+'</td>'
		+'<td id=num_3'+i+'>'+str_arr_3[i]+'</td><td id=num_4'+i+'>'
		+str_arr_res[i]+'</td>'
		+'<td class="time_sc">'+time[i]+'</td>'
		+'<td><input type="checkbox" name="jilu"'
		+' value="'+i+'" onclick="static_num(2)"></td></tr>';
		
		//求第一个数的和
		num_sum_1+=parseFloat(str_arr_1[i]);
		
		//求第四个数的和
		num_sum_res+=parseFloat(str_arr_res[i]);
	}
	num_sum_1=get_end_res(num_sum_1.toFixed(2));//toFixed之后是字符串
	num_sum_res=get_end_res(num_sum_res.toFixed(2));
	
	str+='<tr id="tr_total"><td colspan="3"></td><td>总重量(斤)</td><td></td><td></td>'
	+'<td>总钱(元)</td><td colspan="2"></td></tr>';
	
	//插入计算记录的和到框架
	str+='<tr id="tr_sum"><td colspan="3"></td><td>'+num_sum_1+'</td>'
	+'<td></td><td></td><td>'+num_sum_res+'</td><td colspan="2"></td></tr>';
	
	//插入数据到网页框架
	document.getElementById('show_data_info').innerHTML=str;
	
	return true;
}*/
//删除LocalStorage上的数据
//function del_row(arr){
	/*var a=new Array();
	var b=new Array();
	var c=new Array();
	var d=new Array();
	var e=new Array();
	var g=new Array();
	var j=new Array();
	var r=new Array();*/

	/*if(confirm('删除不可恢复，真的要删除选择的'+arr.length+'条记录？')){
		var y=0;
		for(var i=arr.length-1; i>=0; i--){
			y=arr[i];
			str_arr_1.splice(y, 1);
			str_arr_2.splice(y, 1);
			str_arr_3.splice(y, 1);
			str_arr_res.splice(y, 1);
			time.splice(y, 1);

			str_arr_mingzi.splice(y, 1);
			str_arr_huowu.splice(y, 1);
			str_arr_huohao.splice(y, 1);
		}
	}else{
		return false;
	}*/
	
	/*//删除选中记录
	for(var i=0; i<arr.length; i++){
		var tr=document.getElementById('tr_'+arr[i]);
		tr.parentNode.removeChild(tr);
	}*/
	
	/*for(var i=0; i<str_arr_1.length; i++){
		if(str_arr_1[i]==''||str_arr_1[i]=='null'||typeof(str_arr_1[i])==undefined){
			str_arr_1.splice(i, 1);
			i=i-1;
		}
	}*/
	
	/*var storage=window.localStorage;
	if(str_arr_1.length==0){
		
		storage.clear();
		show_data_2();
		alert('所有记录删除成功');
		//alert('浏览器上没有数据了');
		return false;
	}
	//将数组转化为字符串
	var e1=str_arr_1.join('->');
	var e2=str_arr_2.join('->');
	var e3=str_arr_3.join('->');
	var e4=str_arr_res.join('->');
	var e5=time.join('->');
	
	var e6=str_arr_mingzi.join('->');
	var e9=str_arr_huowu.join('->');
	var e_huohao=str_arr_huohao.join('->');
	
	//删除之后，重新设置localstorage
	//数据经过编程语言加工之后重新保存到浏览器上
	storage['str_num_1']=e1;
	storage['str_num_2']=e2;
	storage['str_num_3']=e3;
	storage['str_num_res']=e4;
	storage['date_time']=e5;

	storage['mingzi']=e6;
	storage['huowu']=e9;
	storage['huohao']=e_huohao;
	
	alert('记录删除成功');
	
	//重新从浏览器上取数据并显示计算记录
	show_data();
	
	return true;*/
//}



/*function jisuan(){
	var text1=document.getElementById('text_1');
	var td_id=document.getElementById('td_id');
	var text2=document.getElementById('text_2');
	var res=document.getElementById('text_3');
	text1.value=text_1.innerHTML;
	td_id.innerHTML=text_2.innerHTML;
	text2.value=text_3.innerHTML;
	
	if(text1.value.length==0 || text2.value.length==0){
		res.value='';
		return false;
	}
	
	var num1=parseFloat(text_1.innerHTML);
	var num2=parseFloat(text_3.innerHTML);
	var b='';
	switch(td_id.innerHTML)//开始计算
	{
		case '+':
		b=(num1+num2).toFixed(2);//a是string类型
		b=get_end_res(b);
		break;
		
		case '-':
		b=(num1-num2).toFixed(2);
		b=get_end_res(b);
		break;

		case 'x':
		b=(num1*num2).toFixed(2);
		b=get_end_res(b);
		break;

		case '/':
		b=(num1/num2).toFixed(2);
		b=get_end_res(b);
		break;*/

		/*case '%':
		res.innerHTML=num_1%num_2;
		break;*/
		
		/*default:
		b=num1%num2;
		b=b;
	}
	if(b=='NaN'){
		res.value='错误';
		return false;
	}
	res.value=b+'元';
	return true; 
}*/
/*//删除行 
function delRow(obj){
	var tr=this.getRowObj(obj); 
	if(tr!=null){ 
		tr.parentNode.removeChild(tr); 
	}else{ 
		throw new Error("the given object is not contained by the table");
	}
}
//得到行对象 
function getRowObj(obj) 
{ 
var i = 0; 
while(obj.tagName.toLowerCase() != "tr"){ 
obj = obj.parentNode; 
if(obj.tagName.toLowerCase() == "table")return null; 
} 
return obj; 
}
//根据得到的行对象得到所在的行数 
function getRowNo(obj){ 
var trObj = getRowObj(obj); 
var trArr = trObj.parentNode.children; 
for(var trNo= 0; trNo < trArr.length; trNo++){ 
if(trObj == trObj.parentNode.children[trNo]){ 
alert(trNo+1); 
} 
} 
}*/