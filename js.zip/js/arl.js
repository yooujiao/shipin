//ajax连接php文件获取用户名
function GetLoginName(num){
	
	var url_php='./get_user_name.php';
	ajax_post(url_php, null);
	//alert(referer_num);

	if(referer_num==0){
		if(num==1){
			//alert('你是非法盗链者');
			window.location.href='warning.php';
		}
		return false;
	}
	
	//如果用户没有登录则跳回首页
	if(loginName==null){
		if(num==1){
			//alert('你没有登录，无法进入此页面');
			window.location.href='user_login01.php?errno=3';
		}
		return false;
	}
	
	//显示用户名
	document.getElementById("loginName").innerHTML=loginName;
}

var loginName=null;
var referer_num=1;
//获取登录名
function ajax_post(a, b){
				
	var myXmlHttpRequest='';
	myXmlHttpRequest=getXmlHttpObject(); //my.js文件
	
	if(!myXmlHttpRequest){
		alert('ajax对象创建失败');
	}
	
	//创建ajax引擎成功
	var url=a;
	var data=b;
	
	myXmlHttpRequest.open('post', url, false);
	myXmlHttpRequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	
	//指定回调函数
	myXmlHttpRequest.onreadystatechange=function chuli(){
			
		//接收数据json
		if(myXmlHttpRequest.readyState==4){ //完成http请求
					
			if(myXmlHttpRequest.status==200){ //成功拿到数据
				
				//取出并转成对象数组
				//var res=eval("("+myXmlHttpRequest.responseText+")");
				var res=JSON.parse(myXmlHttpRequest.responseText);
				//var res=myXmlHttpRequest.responseText;
				//给全局变量loginName赋值，从php那里获取登录名
				if(res.loginName){
					loginName=res.loginName;
				}else{
					console.log('ajax获取用户名失败');
				}
				alert(res.num);
				
				referer_num=res.num;
				
				if(res.num==0){
					console.log('用户在非法访问页面');	
				}
				
			}
		}
	}//回调函数结束
	
	//发送
	myXmlHttpRequest.send(data);
	
	//使用定时器，每隔5秒
	//window.setInterval("updateGoldPrice()",5000);

} //ajax函数结束

//现在的日期时间函数
function xzsj(num)
{
	//实例：现在的日期时间信息
	var arr = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
	//创建现在的日期对象
	var today = new Date();
	var weilai = new Date("2018/2/16");
	var year = today.getFullYear();
	var month = today.getMonth()+1;
	var date = today.getDate();
	var hours = today.getHours();
	var minutes = today.getMinutes();
	var seconds = today.getSeconds();
	var week = today.getDay();//取值0-6
	var timer1 = today.getTime();
	var timer2 = weilai.getTime();
	var chunjie = (timer2-timer1)/1000/3600/24;
	var guonian = Math.floor(chunjie);
	//不够两位，前面补0
	month = month<10? "0"+month : month;
	date = date < 10? "0"+date  : date;
	hours = hours<10? "0"+hours : hours;
	minutes = minutes<10? "0"+minutes : minutes;
	seconds = seconds<10? "0"+seconds : seconds;

	if(num==1){
		var str = year+"年"+month+"月"+date+"日"; 
		//str += "<br>"+arr[week];
		str += hours+":"+minutes+":"+seconds;
		return str;
	}
	
	//构造要输出的结果
	if(num==2){
		
		var obj=document.getElementById("my_clock");
		if(obj){
			var str = hours+":"+minutes+":"+seconds;
			str += "<br>"+arr[week];
			str += "<br>"+year+"年"+month+"月"+date+"日";
			//str += "<br>距离春节还有"+guonian+"天";
			obj.innerHTML=str;
		}
		
		var st="";
		if(hours < 6){
			st = "凌晨好，";
		}
		else if(hours < 10){
			st = "早上好，";	
		}
		else if(hours < 12){
			st = "上午好，";	
		}
		else if(hours < 14){
			st = "中午好，";	
		}
		else if(hours < 18){
			st = "下午好，";	
		}
		else if(hours < 22){
			 st = "晚上好，";	
		}
		else{
			st = "深夜好，";
		}

		//显示时间
		document.getElementById("nowTime").innerHTML=st;
		
		setTimeout("xzsj(2)", 1000);
	}
}

/*隐藏、显示时间日期*/
function hide_show_time()
{
	var a=document.getElementById("my_clock");
	var b=document.getElementById("time_date_id");
	if(a.style.display=="block"){
		a.style.display="none";
		b.style.color="red";
	}else{
		a.style.display="block";
		b.style.color="green";
	}	
}

//隐藏显示帐号管理退出
function hide_show_acound()
{	
	var a=document.getElementById('acount_out');
	var b=document.getElementById('content');
	if(loginName){
		if(a.style.display=='none'){
			a.style.display='block';
			//b.style.display='none';
		}else{
			a.style.display='none';	
		}
	}else{
			if(b.style.display=='none'){
				b.style.display='inline-block';
			}else{
				b.style.display='none';
			}
		}
}
//隐藏显示帐号管理退出
function hide_show_acound2()
{	
	var a=document.getElementById('show_ul_id');
	var b=document.getElementById('acount_out');
	var c=document.getElementById('reg_login_id');
	if(loginName){
		if(a.style.display=='none'){
			a.style.display='block';
			b.style.display='block';
		}else{
			a.style.display='none';
			b.style.display='none';
		}
	}else{
			if(a.style.display=='none'){
				a.style.display='block';
				c.style.display='block';
			}else{
				a.style.display='none';
				c.style.display='none';
			}
		}
}
//帐号管理
function Acount(){
	
	if(loginName){
		
		//登录状态
		if(confirm("是否要进入帐号管理中心")){
			window.location.href="user_upload.php";
			//$(location).attr('href', 'user_upload.php');
		}
	}else{
		
		//非登录状态
		alert("对不起，你不是本网站用户，无法进入帐号管理中心");
	}		
}
//退出
function UserOut()
{	
	if(loginName){
		if(confirm('真的要退出'))
		{	
			//如果退出则关闭当前窗口
			//open(location, '_self').close();
			window.location.href="safeOut.php";
			//$(location).attr('href', 'safeOut.php');
		}
	}else{
		alert('你没有登录，没必要退出');
	}
}

//判断用户是否要登录
function is_login()
{
	if(loginName){
		if(confirm("你已经处于登录状态,是否要重新登录")){
			window.location.href="user_login01.php?num=1";
			//$(location).attr('href', 'user_login01.php?num=1');
		}
	}else{
		if(confirm("是否要登录")){
			window.location.href="user_login01.php?num=1";
			//$(location).attr('href', 'user_login01.php?num=1');
		}
	}		
}
//判断用户是否要注册
function is_reg(){
	
	if(loginName){
		
		//登录状态
		if(confirm("你已经注册了一个帐号，是否要再注册一个帐号")){
			window.location.href="user_reg01.php";
			//$(location).attr('href', 'user_reg01.php');
		}
	}else{
		
		//非登录状态
		if(confirm("是否要注册帐号")){
			window.location.href="user_reg01.php";
			//$(location).attr('href', 'user_reg01.php');
		}
	}	
}



