var url_pc="./css/index_pc.css";
var url_phone="./css/index_phone.css";
window.onload=function(){
		
	//判断是手机进入网页还是电脑进入网页
	wangye(url_pc,url_phone);

	//登录自动修改为切换帐号
	//changeLogin();
	
	//获取登录名
	GetLoginName(0); //arl.js文件
	
	//显示现在的时间
	xzsj(2); //arl.js文件
	
	//显示帐号管理、退出
	hide_show_acound();

	get_ip();//获取ip地址

	get_weather_m(0);//获取天气预报数据

	click_event();//各个点击事件
}
//搜一下
function search_info_m(){
	
	var url_v='./SearchUI.php';
	var search_v=get_obj('audio_video_text').value;
	var data_v='?search='+search_v;
	window.location.replace('SearchUI.php?search='+search_v);
	//alert(window.location.href);
	return true;
	
	//window.location.href=url_v;
	//location.replace(url_v);
	//window.open(url_v);
}
//获取ip地址
var city_v='';
var a_v=0;
function get_ip(){
	
	var myXmlHttpRequest="";
	myXmlHttpRequest=getXmlHttpObject();
	
	if(!myXmlHttpRequest){
		alert("ajax对象创建失败");
		return false;
	}
	
	//创建ajax引擎成功
	var url="./tianqi/ip.php";
	var data="";
	
	myXmlHttpRequest.open("post",url,true);
	myXmlHttpRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	
	//指定回调函数
	myXmlHttpRequest.onreadystatechange=function chuli(){
			
		//接收数据json
		if(myXmlHttpRequest.readyState==4){//完成http请求
					
			if(myXmlHttpRequest.status==200){//成功拿到数据
				
				//取出并转成对象数组
				var a=eval("("+myXmlHttpRequest.responseText+")");
				//alert(a.ip);
				if(a.city){
					city_v=a.city;
					
					get_obj("ul_id").style.display="block";
					get_obj("hr_id").style.display="block";
					
					get_obj('ip').innerText='ip：'+a.ip;
					get_obj('region_city').innerText='位置：'+a.region+'->'+a.city;
					get_obj('isp').innerText='网络：'+a.region+a.isp;
					//alert(get_obj('isp').innerText);
				}else{
					var time_v=window.setTimeout("get_ip()", 1000);
					a_v++;
					if(a_v>5){
						//清除延时器
						window.clearTimeout(time_v);
						alert('自动获取ip失败');
						return false;
					}
				}
			}
		}
	}//回调函数结束
	
	//发送
	myXmlHttpRequest.send(data);
	
	//使用定时器，每隔5秒
	//window.setInterval("updateGoldPrice()",5000);	
	
}//ajax函数结束

//获取天气预报数据
var content_v;
var b_v=0;
function get_weather_m(num){
	
	var xml_v="";
	xml_v=getXmlHttpObject();
	
	if(!xml_v){
		alert("ajax对象创建失败");
		return false;
	}
	
	//创建ajax引擎成功
	var url='./tianqi/weather.php';
	var data='';
	if(num==0){
		//城市获取失败
		if(city_v==''){
			var time_v=window.setTimeout("get_weather_m(0)", 1000);
			b_v++;
			if(b_v>30){
				//清除延时器
				window.clearTimeout(time_v);
				alert('自动查询天气预报失败');
				return false;
			}
			return false;
		}
		
		if(city_v){
			if(city_v=='内网IP'){
				alert('内网ip无法查询');
				return false;
			}
			data='search_city='+city_v;
			//get_obj('weather_j').style.color='#669999';
			//get_obj('search_city').value=city_v;
			content_v=city_v;
		}
	
	}
	
	var content_v_new=get_obj('search_city').value;
	if(num==1){
		if(content_v_new.length==0){
			alert('输入的内容不能为空');
			return false;
		}
		if(content_v_new==content_v){
			alert('不要重复查询');
			return false;
		}
		content_v=content_v_new;
		data='search_city='+content_v;
		//get_obj('weather_j').style.color=RandomColor();
	}
		
	//alert(data);
	//return false;
	xml_v.open("post", url, true);
	xml_v.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	
	//指定回调函数
	xml_v.onreadystatechange=function chuli(){
			
		//接收数据json
		if(xml_v.readyState==4){//完成http请求
					
			if(xml_v.status==200){//成功拿到数据
				//alert(xml_v.responseText);
				var text_v=xml_v.responseText;
				if(text_v==1002){
					alert('天气预报数据获取失败\n请输入正确的城市\n而不是省份或者其他无意义的字符');
					return false;
				}
				if(text_v==0){
					alert('天气预报数据获取失败或者天气预报接口失效');
					return false;
				}

				//取出json数据转成对象数组
				var a=JSON.parse(text_v);
				if(a.jintian.type){
					get_obj('ul_id').style.display='block';
					get_obj('weather_j').style.color=RandomColor();
					
					var string_v1=a.jintian.low.substring(3);
					get_obj('weather_j').innerHTML=a.city+'->'+a.jintian.type
						+'->'+string_v1+'（今天'+a.jintian.date+'）';
					//get_obj('city').innerHTML=res_object.city;
					//get_obj('high_j').innerHTML=res_object.jintian.high;
					//get_obj('low_j').innerHTML=res_object.jintian.low;
					//get_obj('fengxiang_j').innerHTML=res_object.jintian.fengxiang;
					//get_obj('type_j').innerHTML=a.jintian.type;
					
					var string_v2=a.mingtian.low.substring(3);
					get_obj('weather_m').innerHTML=a.city+'->'+a.mingtian.type
						+'->'+string_v2+'（明天'+a.mingtian.date+'）';
					var str=a.ganmao;
					str=str.replace(/[^\x00-\xff]/g,"$&\x01")
						.replace(/.{30}\x01?/g,"$&<br>").replace(/\x01/g,"");
					get_obj('ganmao').innerHTML=str;
					//get_obj('high_m').innerHTML=a.mingtian.high;
					//get_obj('low_m').innerHTML=a.mingtian.low;
					//get_obj('fengxiang_m').innerHTML=res_object.mingtian.fengxiang;
					//get_obj('type_m').innerHTML=res_object.mingtian.type;
					//get_obj('wendu').innerHTML=a.wendu+'℃';
				}else{
					alert('天气预报数据获取失败');
					return false;
				}
			}
		}
	}//回调函数结束
	
	//发送
	xml_v.send(data);
	
	//使用定时器，每隔5秒
	//window.setInterval("updateGoldPrice()",5000);	
	
}//ajax函数结束
function RandomColor()
{
	//实例：网页随机背景色
	var min = 100000;
	var max = 999999;
	var random = Math.random()*(max-min)+min;
	//向下取整
	random = Math.floor(random);
	var color="#"+random;
	return color;
	//document.getElementById("movieBox").style.backgroundColor="#"+random;
}
/*
$(document).ready(
	function(){
		
		$("#guanbi_1").click(
			function(){
				close_page();//关闭网页
			}
		);
		
		$("#zhankai").click(
			function(){
				$("#guanbi_3").toggle();//打开黑色div
			}
		);
		
		$("#guanbi_2").click(
			function(){
				$("#guanbi_3").hide();//关闭黑色div
			}
		);
		
		$("#guanbi_3").click(
			function(){
				$(this).hide();//关闭黑色div
			}
		);
		
		$("#ul").click(
			function(){
				white_page();//白色ul
			}
		);
		
		$("#loginName").click(
			function(){
				hide_show_acound();//隐藏、显示帐号管理退出
			}
		);
		
		$("#zhgl").click(
			function(){
				Acound();//帐号管理
			}
		);
		
		$("#user_out").click(
			function(){
				UserOut();//退出
			}
		);
		
		$("#login").click(
			function(){
				is_login();//登录
			}
		); 

		$("#reg").click(
			function(){
				is_reg();//注册
			}
		); 

		$("#time_date_id").click(
			function(){
				hide_show_time();//时间日期
			}
		);
		
		/*$("#search_id").click(
			function(){
				search_info_m();//搜一下
			}
		);*/ 



		//JS网址跳转
		/*window.location.replace("//www.baidu.com");
		window.location.href = "//www.baidu.com";*/
		//jquery网址跳转
		/*$(location).attr('href', '//www.baidu.com');
		$(window).attr('location','//www.baidu.com');
		$(location).prop('href', '//www.baidu.com')*/
	//}
//);

//绑定监听事件
function click_event(){
	
	addEventHandler(get_obj("zhankai"), "click", function(){
		show_hide('guanbi_3');
	});//展开
	
	addEventHandler(get_obj("guanbi_1"), "click", close_page_m);//关闭
	
	addEventHandler(get_obj("guanbi_2"), "click", function(){
		show_hide('guanbi_3');
	});//关闭
	
	addEventHandler(get_obj("guanbi_3"), "click", function(){
		show_hide('guanbi_3');
	});//关闭黑色div
	
	addEventHandler(get_obj("ul"), "click", white_page);//白色ul
	addEventHandler(get_obj("loginName"), "click", hide_show_acound);//游客
	addEventHandler(get_obj("zhgl"), "click", Acount);//帐号管理
	addEventHandler(get_obj("user_out"), "click", UserOut);//退出
	addEventHandler(get_obj("login"), "click", is_login);//登录
	addEventHandler(get_obj("reg"), "click", is_reg);//注册
	addEventHandler(get_obj("time_date_id"), "click", hide_show_time);//时间日期
	addEventHandler(get_obj("search_id"), "click", search_info_m);//搜一下
	addEventHandler(get_obj("search_b"), "click", function(){
		get_weather_m(1);
	});//查询天气
}
function addEventHandler(target,type,fn){
	if(target.addEventListener){
		target.addEventListener(type,fn);
	}else{
		target.attachEvent("on"+type,fn);
	}
}
/*//function click_event(){
	document.addEventListener("click",
		function(event)
		{
			var target=event.target;
			if(target == $("guanbi_1")){
				close_page();//关闭index.php
			}else if(target == $("zhankai")){
				show_hide_page();//展开
			}else if(target == $("guanbi_2")){
				hide_page_f();//关闭
			}
			else if(target == $("hide_page_id")){
				hide_page_f();//关闭
			}
			else if(target == $("loginName")){
				ShowAcound();//用户名
			}
		}
	)
//}*/



//测试
//var btn5 = document.getElementById("btn5");
//addEventHandler($("zhankai"),"click",hide_page_f);//添加事件hello1
/*addEventHandler(btn5,"click",hello2);//添加事件hello2
removeEventHandler(btn5,"click",hello1);//移除事件hello1*/
//登录自动修改为切换帐号
/*var flag=0;
function changeLogin()
{
	if(loginName){
		document.getElementById('login').innerHTML="切换帐号";
		flag=1;
	}
}*/
//换帐号登录
/*function changeUser()
{
	if(flag==1){
		if(confirm('确定要换另一个帐号登录？')){
			window.location.href='user_login01.php';
		}
	}
	else{
		window.location.href='user_login01.php';	
	}
}*/
//显示隐藏上传音乐视频
/*function uploadSong()
{	
	if(loginName==""){
		//window.location.href='user_login01.php?errno=4';
		alert("想要上传文件，请先登录！");
		exit;
	}
	var upload_song=document.getElementById('uploadBox');
	//upload_song.style.display = "block";
	if(upload_song.style.display=="block")
	{
		upload_song.style.display="none";
		//document.getElementById('showSong').innerHTML = "隐藏音乐";
	}
	else
	{
		upload_song.style.display="block";
		//document.getElementById('showSong').innerHTML = "显示音乐";
	}	
}*/
//跳转到用户页面
/*function userAccount()
{
	if(loginName){
		window.location.href = "user_upload.php";
	}else{
		alert("游客，请先登录！");
	}
}*/

//显示帐号管理、退出
/*function ShowAcoundOut()
{	
	var a=document.getElementById('acount');
	if(loginName){
		if(a.style.display=='none'){
			a.style.display='block';
		}else{
			a.style.display='none';	
		}
	}else{
		//alert("游客，请先登录！");
		if(a.style.display=='none'){
			a.style.display='block';
			a.innerHTML='你是游客，请登录。';
		}else{
			a.style.display='none';	
		}
	}
}*/



/*function focus_username()
{
	//获取id=result_username的对象
	var resultObj = document.getElementById("result_username")
	//写入提示信息
	resultObj.innerHTML = "请输入用户名";
	resultObj.style.color = "gray";
	//给文本框加一个边框
	//document.form2.username.style = "border:1px solid red;background-color:f0f0f0";
}
function blur_username()
{
	//获取id=result_username的对象
	var resultObj = document.getElementById("result_username");
	//用户名的验证
	if(document.form2.userName.value.length == 0)
	{
		resultObj.innerHTML = "<font color='red'>用户名不能为空</font>";
		return false;
	}
	else if(document.form2.userName.value.length<9 || document.form2.userName.value.length>20)
	{
		resultObj.innerHTML = "<font color='red'>用户名的长度必须在9-20个字符之间</font>";
		return false;
	}
	else if(checkOtherChar(document.form2.userName.value))
	{
		//如果用户名含有特殊符号
		//window.alert("用户名中含有特殊符号！")
		resultObj.innerHTML = "<font color='red'>用户名中含有特殊符号</font>";
	}
	else
	{
		resultObj.innerHTML = "<font color='green'>验证通过</font>";
		return true;
	}
}
function focus_userpwd()
{
	//获取id=result_userpwd的对象
	var resultObj = document.getElementById("result_userpwd")
	//写入提示信息
	resultObj.innerHTML = "请输入你的密码";
	resultObj.style.color = "gray";
	//给文本框加一个边框
	//document.form2.username.style = "border:1px solid red;background-color:f0f0f0";
}
function blur_userpwd()
{
	//获取id=result_userpwd的对象
	var resultObj = document.getElementById("result_userpwd");
	//密码的验证
	if(document.form2.userPassword.value.length == 0)
	{
		resultObj.innerHTML = "<font color='red'>密码不能为空</font>";
		return false;
	}
	else if(document.form2.userPassword.value.length<9 || document.form2.userPassword.value.length>20)
	{
		resultObj.innerHTML = "<font color='red'>密码的长度必须在9-20个字符之间</font>";
		return false;
	}
	else
	{
		resultObj.innerHTML = "<font color='green'>验证通过</font>";
		return true;
	}
}
function checkOtherChar(str)
{
	//定义一个特殊符号的数组
	var arr = ["*","&","<",">","$","\\","/"];
	//循环比较：数组中的每一个字符，与用户名每一个字符进行比对
	for(var i=0;i<arr.length;i++)
	{
		for(var j=0;j<str.length;j++)
		{
			if(arr[i] == str.charAt(j))
			{
				return true;
			}
		}
	}
	//如果没找到
	return false;
}
function checkForm()
{
	var flag_username = blur_username();
	var flag_userpwd = blur_userpwd();
	if(flag_username==true && flag_userpwd==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}*/
//清除本地存储
/*var storage=window.localStorage;
storage.removeItem("a");*/
/*



W3C规范
语法：

element.addEventListener(event, function, useCapture)
event : （必需）事件名，支持所有 DOM事件 。

function：（必需）指定要事件触发时执行的函数。

useCapture：（可选）指定事件是否在捕获或冒泡阶段执行。true，捕获。false，冒泡。默认false。

注：IE8以下不支持。
封装事件监听
<input type="button" value="click me" id="btn5">

//绑定监听事件
function addEventHandler(target,type,fn){
	if(target.addEventListener){
		target.addEventListener(type,fn);
	}else{
		target.attachEvent("on"+type,fn);
	}
}

//移除监听事件
function removeEventHandler(target,type,fn){
	if(target.removeEventListener){
		target.removeEventListener(type,fn);
	}else{
		target.detachEvent("on"+type,fn);
	}
}

//测试
var btn5 = document.getElementById("btn5");
addEventHandler(btn5,"click",hello1);//添加事件hello1
addEventHandler(btn5,"click",hello2);//添加事件hello2
removeEventHandler(btn5,"click",hello1);//移除事件hello1

事件委托
事件委托就是利用冒泡的原理，把事件加到父元素或祖先元素上，触发执行效果。

<input type="button" value="click me" id="btn6">

var btn6 = document.getElementById("btn6");
document.onclick = function(event){
	event = event || window.event;
	var target = event.target || event.srcElement;
	if(target == btn6){
		alert(btn5.value);
	}
}
上面只是个例子，代码尽可能的简化了。在实际的代码中 我们可能用到jQuery的live()、delegate()、bind()、on()等。

事件委托优点
1、提高JavaScript性能。事件委托可以显著的提高事件的处理速度，减少内存的占用。 实例分析JavaScript中的事件委托和事件绑定 ，这篇文章写得还不错。

传统写法
<ul id="list">
  <li id="item1" >item1</li>
  <li id="item2" >item2</li>
  <li id="item3" >item3</li>
</ul>

<script>
var item1 = document.getElementById("item1");
var item2 = document.getElementById("item2");
var item3 = document.getElementById("item3");

item1.onclick = function(){
	alert("hello item1");
}
item2.onclick = function(){
	alert("hello item2");
}
item3.onclick = function(){
	alert("hello item3");
}
</script>
事件委托
<ul id="list">
  <li id="item1" >item1</li>
  <li id="item2" >item2</li>
  <li id="item3" >item3</li>
</ul>

<script>
var item1 = document.getElementById("item1");
var item2 = document.getElementById("item2");
var item3 = document.getElementById("item3");

document.addEventListener("click",function(event){
	var target = event.target;
	if(target == item1){
		alert("hello item1");
	}else if(target == item2){
		alert("hello item2");
	}else if(target == item3){
		alert("hello item3");
	}
})
</script>
2、动态的添加DOM元素，不需要因为元素的改动而修改事件绑定。

传统写法
<ul id="list">
  <li id="item1" >item1</li>
  <li id="item2" >item2</li>
  <li id="item3" >item3</li>
</ul>

<script>
var list = document.getElementById("list");

var item = list.getElementsByTagName("li");
for(var i=0;i<item.length;i++){
	(function(i){
		item[i].onclick = function(){
			alert(item[i].innerHTML);
		}
	})(i)
}

var node=document.createElement("li");
var textnode=document.createTextNode("item4");
node.appendChild(textnode);
list.appendChild(node);

</script>
点击item1到item3都有事件响应，但是点击item4时，没有事件响应。说明传统的事件绑定无法对动态添加的元素而动态的添加事件。

事件委托
<ul id="list">
  <li id="item1" >item1</li>
  <li id="item2" >item2</li>
  <li id="item3" >item3</li>
</ul>

<script>
var list = document.getElementById("list");

document.addEventListener("click",function(event){
	var target = event.target;
	if(target.nodeName == "LI"){
		alert(target.innerHTML);
	}
})

var node=document.createElement("li");
var textnode=document.createTextNode("item4");
node.appendChild(textnode);
list.appendChild(node);

</script>
当点击item4时，item4有事件响应。说明事件委托可以为新添加的DOM元素动态的添加事件。
*/






