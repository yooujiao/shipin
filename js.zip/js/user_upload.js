//全局变量初始化
var song_flag=null,//音乐id
video_flag,//视频id
audio,//音乐对象
video;//视频对象
var song_id_array=new Array();
var song_array=new Array();
var video_array=new Array();
var user_info_array=new Array();
var url_pc="./css/upload_pc.css";
var url_phone="./css/upload_phone.css";
window.onload=function(){
	
	//var screenWith_v=window.screen.width/640;
	//document.documentElement.style.fontSize=screenWith_v*20+"px";
	
	//判断是手机进入网页还是电脑进入网页
	wangye(url_pc, url_phone);
	
	//获取音乐对象
	audio = document.getElementById("audio");
	//audio.volume=0.3;

	//获取视频对象
	video = document.getElementById("video");
	
	//hideForm();
	
	//获取用户名
	GetLoginName(1); //arl.js文件

	//显示时间
	xzsj(2);
	
	//显示用户名
	//showUserName();
	
	//显示没有下架的歌曲
	ShowAudio();
	
	//显示视频
	ShowVideo();
	
	//显示用户信息
	userInfo()

	songMovie();
	
	//歌曲顺序播放
	seqPlay();
	
	//上传错误信息
	errInfo();
	
	//屏蔽浏览器后退按钮
	//disableBackward();
}
/******ajax请求模块******/
var myXmlHttpRequest="";
var audio_str="";
function DownTheSong(){

	if(audio_id.length==0){
		alert("请选择需要下架的歌曲");
		return false;
	}
	
	var str="";
	for(var i=0; i<audio_id.length; i++)
	{
		str+="\n"+audio_id[i];
	}
	
	if(str==audio_str){
		alert("歌曲已经下架了"+str);
		return false;
	}
	
	if(!confirm('真的要下架：'+str))
	{
		return false;
	}
	//记录下架的歌曲
	audio_str=str;
	
	//开始发送ajax请求
	myXmlHttpRequest=getXmlHttpObject();
	if(!myXmlHttpRequest){
		alert("ajax引擎创建失败");
		return false;	
	}
	
	var url="./DownTheSongController.php";
	var data="AudioId="+audio_id_str;
	
	//alert(audio_id_str);
	//return;

	myXmlHttpRequest.open("post",url,true);

	myXmlHttpRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		
	//指定回调函数
	myXmlHttpRequest.onreadystatechange=chuli; 

	//发送
	myXmlHttpRequest.send(data);
}
//处理函数
function chuli(){
						
	//接收xml数据
	if(myXmlHttpRequest.readyState==4){
		
		if(myXmlHttpRequest.status!=200){
			alert("ajax请求失败");
			return false;
		}
												
		if(!myXmlHttpRequest.responseXML){
			alert("xml数据获取失败");
			return false;
		}			
				
		var success=myXmlHttpRequest.responseXML.getElementsByTagName("success");
		var fail=myXmlHttpRequest.responseXML.getElementsByTagName("fail");
		var online_audio=myXmlHttpRequest.responseXML.getElementsByTagName("songname");
		var online_id=myXmlHttpRequest.responseXML.getElementsByTagName("songid");
		
		if(song_array.length>0){
			song_array.length=0;
			song_id_array.length=0;
		}
		
		for(var m=0;m<online_audio.length;m++){
			song_array.push(online_audio[m].childNodes[0].nodeValue);	
		}
		for(var z=0;z<online_id.length;z++){
			song_id_array.push(online_id[z].childNodes[0].nodeValue);
		}
		//alert(song_name.length);
		//return;
		
		/*if(audio_name.length>0){ //全局变量代表当前的一种状态，所以要置空
			audio_name.length=0;
			audio_user.length=0;
			audio_date.length=0;
			song_flag=null;
			y=-1;
		}
		if(video_name.length>0){
			video_name.length=0;
			video_user.length=0;
			video_date.length=0;
			video_flag=-1;
		}*/

		
		var audio_success=new Array();
		//取出搜索到的歌曲信息
		for(var i=0;i<success.length;i++){
					
			//歌曲名称
			audio_success.push(success[i].childNodes[0].nodeValue);
		}
		
		
		var str1="";
		//写出下架成功的歌曲
		for(var j=0;j<audio_success.length;j++){
			
			str1+="<br/>"+audio_success[j];		
		}
		document.getElementById("audio_success").innerHTML=str1;
		
		
		var audio_fail=new Array();
		//取出搜索到的视频信息
		for(var k=0;k<fail.length;k++){
					
			//视频名称
			audio_fail.push(fail[k].childNodes[0].nodeValue);
		}
		//写出下架失败的歌曲
		var str2="";
		for(var n=0;n<audio_fail.length;n++){
			
			str2+="<br/>"+audio_fail[n];		
		}
		document.getElementById("audio_fail").innerHTML=str2;

		//SearchSong();
		//清空表格样式
		/*if(res_video1.length>0){
			$('table02').style='';
		}*/
		//显示没有下架的歌曲
		ShowAudio();
		
		//显示搜索到的视频
		//ShowVideo();
		
		//显示搜索到的音乐、视频个数
		//AudVidNum();
	}
}
function ShowAudio(){
	//global $audio_array,$audio_id_array;
	//$count=count($audio_array);
	
	var str="";
	
	str+='<form action="delAudio.php" method="post" id="form01" onsubmit="return delAudio()">';
	
	str+='<table>';
	str+='<tr><td class="no_down"><a onclick="NoDownTheSong()">未上架歌曲</a></td><td class="close_page"><span id="editSongs" onclick="yincang()">编辑</span><a onclick="hideAudioList()">关闭</a></td></tr>';
	
	str+='<tr><td class="check_box"><input type="checkbox" name="selectAllSong" style="display:none" onclick="selectSong()"/></td><td><p>'+song_array.length+'首歌曲</p></td></tr>';
	
	for(var i=0;i<song_array.length;i++)
	{			
		str+='<tr name="songList">';
		
		str+="<td class='check_box' name='checkboxTd'><input type='checkbox' name='selectSong[]' value='"+song_array[i]+"+"+song_id_array[i]+"' onclick='checkboxChange(this)' style='display:none'/></td>";
		
		str+='<td class="songName"><a id=songList'+i+' onclick=PlaySong('+i+')>'+song_array[i]+'</a></td>';
		
		str+='</tr>';
	}
	
	str+='<tr name="songTr" style="display:none">';
	str+='<td></td><td class="xiajia" colspan="2"><input type="button" value="下架" onclick="DownTheSong()"><input type="submit" value="删除歌曲"></td>';
	str+='</tr>';
	
	 
		
	str+='<tr id="viewSong" style="display:none"><td></td><td class="chakan"><span id="hideSongs" onclick="viewMoreSong()">查看更多歌曲</span></td></tr>';
	
	str+='</table>';
	str+='</form>';
	
	document.getElementById("show_song").innerHTML=str;

	if(song_array.length==0){
		document.getElementById("editSongs").style.display="none";
	}
}
function NoDownTheSong(){
	
	//开始发送ajax请求
	myXmlHttpRequest=getXmlHttpObject();
	if(!myXmlHttpRequest){
		alert("ajax引擎创建失败");
		return false;	
	}
	
	var url="./DownTheSongController.php";
	var data="AudioId="+audio_id_str;
	
	//alert(audio_id_str);
	//return;

	myXmlHttpRequest.open("post",url,true);

	myXmlHttpRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		
	//指定回调函数
	myXmlHttpRequest.onreadystatechange=chuli; 

	//发送
	myXmlHttpRequest.send(data);	
}
//显示我的资料
function showUserBox()
{
	var y = document.getElementById("userBox");
	if(y.style.display == "none")
	{
		y.style.display = "block";
	}
	else
	{
		y.style.display = "none";	
	}
}
//切换帐号
function changeAccount()
{
	if(confirm('确定要换一个帐号登录?')){
		window.open("user_login01.php");
	}
}
//搜索资源
function backPage()
{	
	if(confirm('确定要离开此页面?'))
	{
		window.location.href = "index.php";
		//window.open("index.php");                 
	}
}

//判断音乐数组、视频数组是否为空
/*function hideForm()
{	//alert(song_array);
	if(song_array==null)
	{
		document.getElementById("form01").style.display = "none";
		document.getElementById("hideAudioList").style.color = "#ccc";
	}
	if(video_array==null)
	{
		document.getElementById("form02").style.display = "none";
		document.getElementById("hideVideoList").style.color = "#ccc";
	}
}*/

//判断歌曲列表是否超过6首歌曲
function songMovie()
{
	if(song_array)
	{
		var a=document.getElementsByName("songList");
		if(song_array.length>6)
		{	
			for(var i=6; i<song_array.length; i++)
			{
				a[i].style.display="none";
				
			}
			//值table-row解决了表格由隐藏到显示变形的问题
			document.getElementById("viewSong").style.display="table-row";
		}
	}
	
	if(video_array)
	{
		//判断视频列表是否超过3个视频
		var b=document.getElementsByName("videoList");
		if(video_array.length>3)
		{
			for(var j=3; j<video_array.length; j++)
			{
				b[j].style.display="none";
				
			}
			document.getElementById("viewVideo").style.display="table-row";
		}
	}
}

/******音乐模块******/
//显示、隐藏音乐列表
function hideAudioList()
{
	var a=document.getElementById("show_song");
	//var b=document.getElementById("hideAudioList");
	if(a.style.display=="block")
	{
		//if(confirm('确定要离开音乐列表?'))
		//{
			a.style.display="none";
		//}
		//b.style.color = "#ccc";
	}
	else
	{
		a.style.display="block";
		//b.style.color = "#669999";
	}
}
//播放当前点击的歌曲
function PlaySong(s)
{	
	//隐藏视频列表盒子
	document.getElementById("movieBox").style.display = "none";
	video.pause();
	
	var a = document.getElementById("songBox");
	a.style.display="block";
	
	if(userName){
		
		if(s==song_flag)
		{
			audio.play();
		}else{
			audio.src="upload/"+userName+"/"+song_array[s];
			audio.play();
			document.getElementById("songName").innerHTML="正在听歌："+song_array[s];
			song_flag=s;
			y=s;
			songColor(s);
		}
	}else{
		alert("登录超时，想要听歌，请重新登录。");
	}
	//songTime();
}
//歌曲列表顺序播放函数
var y=0;
function seqPlay()
{
		document.getElementById('seqPlay').style.color = 'green';
		document.getElementById("songLoop").style.color = '';
		audio.loop = "";
		audio.onended = function()
		{	
			//song_name.style.color = '#669999';
			y++;
			if(song_array[y])
			{
				songColor(y);
				//document.getElementById('songList'+ (y-1)).style.color = '#ccc';
				//this.setAttribute("src",path+song_path[i]);
				audio.src = "upload/"+userName+"/"+song_array[y];
				audio.play();
				document.getElementById("songName").innerHTML = "正在听歌："+song_array[y];
				song_flag = y;
				//document.getElementById("downLoadSong").href = "upload/"+song_array[y];
				//document.getElementById("downLoadSong").download = song_array[y];
				//abc();
			}
			else
			{
				//当song_path数组里元素的值为undefined时，执行以下代码
				//i = 0;
				alert("没有歌曲了！");
				//seqPlay();
				//vid.play();
			}
		}
}
//歌曲列表循环播放函数
function songLoop()
{	
	audio.loop = "loop";
	var song_loop = document.getElementById("songLoop");
	//input1.value = '单曲循环';
	song_loop.style.color = "red";
	document.getElementById('seqPlay').style.color = '';
}
//隐藏、显示音乐播放器
function hideAudioPlayer()
{
	var a=document.getElementById("songBox");
	
	if(a.style.display=="block"){
		a.style.display="none";
		document.getElementById("hidePlayer").innerHTML="显示音乐";
	}else{
		a.style.display="block";
		document.getElementById("hidePlayer").innerHTML="隐藏音乐";
	}
	
	/*if(confirm('确定要关闭音乐盒?'))
	{
	}*/
}
//显示listBox
function showListBox()
{
	var a = document.getElementById("listBox");
		a.style.display = "block";
}
//隐藏listBox
function hideListBox(){
	document.getElementById("listBox").style.display = "none";	
}
//下载歌曲
function downLoadSong()
{
	var a = document.getElementById("downLoadSong");
	a.href = "upload/"+userName+"/"+song_array[song_flag];
	a.download = song_array[song_flag];
}
//删除选中歌曲
function delAudio()
{
	//var a = document.getElementsByName("selectAllSong");
	var b = document.getElementsByName("selectSong[]");
	var str="";
	for(var i=0; i<b.length; i++){
		if(b[i].checked){
			str+="\n"+b[i].value;
		}
	}
	
	if(!str){
		alert("请选择要删除的歌曲");
		return false;
	}
	//alert(str);
	if(confirm('真的要删除：'+str))
	{
		return true;	
	}
	else
	{
		return false;
	}
}
//删除歌曲
function delSong()
{	
	var x=document.getElementById("song_id_text");
	x.value=song_id_array[song_flag];
	
	var y=document.getElementById("song_name_text");
	y.value=song_array[song_flag];
	
	if(confirm("真的要删除：\n"+y.value)){
		return true;	
	}else{
		return false;
	}
}
//查看更多歌曲
function viewMoreSong()
{
	var a = document.getElementsByName("songList");
	
	for(var i=6; i<song_array.length; i++)
	{
		if(a[i].style.display == "none")
		{
			a[i].style.display = "table-row";
			document.getElementById("hideSongs").innerHTML = "收起更多歌曲";
		}
		else
		{
			a[i].style.display = "none";
			document.getElementById("hideSongs").innerHTML = "查看更多歌曲";
		}
		
	}
}

/******视频模块******/
//显示、隐藏视频列表
function hideVideoList()
{
	//var a=document.getElementById("showVideo");
	if(video_array)
	{
		var a = document.getElementById("showVideo");
		//var b = document.getElementById("hideVideoList");
		if(a.style.display=="block")
		{
			//if(confirm('确定要离开视频列表?'))
			//{
				a.style.display="none";
			//}
			//b.style.color = "#ccc";
		}
		else
		{
			a.style.display="block";
			//b.style.color = "#669999";
		}
	}
	else
	{
		//a.style.display='block';
		//alert("你的视频列表没有任何视频，请先上传视频")
	}
}
/*//视频显示
function showVideo()
{	
	if(video_array)
	{
		var str = '<form action="video.php" method="post" id="form02" class="form02" style="display:block">'
		str += '<table>'
		<td>
			<input type="checkbox" name="selectAllVideo" onclick="selectVideo()" style="display:none">
		</td>
		//str += '<tr><td class="cvl"><input type="button" onclick="hideVideoList()" value="关闭页面"></td></tr>'
	
		//str += '<tr><td><p>'+video_array.length+'个视频</p></td></tr>'
		//for(var i=0; i < video_array.length; i++)
		//{*/
			/*<td>
			<input type='checkbox' name='selectVideo[]' value=\"$array_push[$i]\" onclick='showPlay()' style='display:none'>
			</td>*/
			//str += '<tr name="videoList">'
			//str += '<td><a id=videoList'+i+' onclick=videoBox('+i+')>'+video_array[i]+'</a></td>'
			//str += '</tr>'
		//}
		/*echo '<tr name="songTr" style="display:none">
				<td colspan=2>
					<input class="viewMore" type="submit" value="播放选中视频">
				</td>
			</tr>';*/
		/*str += '<tr id="viewVideo" style="display:none">'
		str += '<td colspan=2>'
		str += '<input  class="viewMore" id="hideVideos" type="button" value="查看更多视频"' 
		str += 'onclick="viewMoreMovie()">'
		str += '</td>'
		str += '</tr>'
		str += '</table>'
		str += '</form>'
		document.getElementById("showVideo").innerHTML = str;
	}
}*/

//视频显示
function ShowVideo()
{	
	//global $video_array;
	/*<section class="show_video" id="showVideo" style="display:none">
	<form action="#" method="post" id="form02">
	<span class="guanbi" onclick="hideVideoList()">关闭</span>
	<div style="clear:both"></div>
	<table>*/
	/*<td>
		<input type="checkbox" name="selectAllVideo" onclick="selectVideo()" style="display:none">
	</td>*/
	/*<td>
	<input type='checkbox' name='selectVideo[]' value=\"$array_push[$i]\" onclick='showPlay()' style='display:none'>
	</td>*/
	
	var str='<tr><td><p>'+video_array.length+'个视频</p></td></tr>';
	for(var i=0; i<video_array.length; i++)
	{			
		
		
		str+='<tr name=videoList>'
			+'<td class=video_name>'
			+'<a id=videoList'+i+ 'onclick=videoBox('+i+')>'
			+video_array[i]+'</a>'
			+'</td>'
			+'</tr>';
	}
	/*'<tr name="songTr" style="display:none">
				<td colspan=2>
					<input class="viewMore" type="submit" value="播放选中视频">
				</td>
			</tr>';*/
	
	str+='<tr id=viewVideo style=display:none>'
		+'<td><input id=hideVideos type=button value=查看更多视频 onclick=viewMoreMovie()></td>'
		+'</tr>';
	//id:table_show_video
		
		
		/*</table>
		//<input type="button" value="关闭视频列表" onclick="hideVideoList()">
		</form>
		</section>;*/
}

//播放当前点击的视频
function videoBox(v)
{	
	//点击视频变灰色
	//document.getElementById("videoList"+v).style.color = "#ccc";
	//暂停正在播放的音乐
	audio.pause();
	//获取视频盒子movieBox对象
	var a = document.getElementById("movieBox");
	if(v != video_flag)
	{	
		a.style.display = "none";
	}
	video_flag = v;
	if(a.style.display == "none")
	{
		a.style.display = "block";
		if(userName)
		{
			video.src = "upload/"+userName+"/"+video_array[video_flag];
			video.play();
			document.getElementById("videoName").innerHTML = "正在观看："+video_array[video_flag];
		}
	}
	else
	{
		a.style.display = "none";
		video.pause();
	}
	songColor();
	//songTime();
}
//下载视频
function downLoadMovie()
{
	var a = document.getElementById("downLoadMovie");
	a.href = "upload/"+userName+"/"+video_array[video_flag];
	a.download = video_array[video_flag];
}
//关闭视频页面
function shipin()
{
	if(confirm('真的要离开视频观看?'))
	{
		document.getElementById("movieBox").style.display = "none";
		video.pause();
	}
}
//查看更多视频
function viewMoreMovie()
{
	var a = document.getElementsByName("videoList");
	
	for(var i=3; i<video_array.length; i++)
	{
		if(a[i].style.display == "none")
		{
			a[i].style.display = "table-row";
			document.getElementById("hideVideos").value = "收起更多视频";
		}
		else
		{
			a[i].style.display = "none";
			document.getElementById("hideVideos").value = "查看更多视频";
		}
		
	}
}

/******音乐、视频模块******/
//歌曲、视频变色函数
function songColor(num)
{	
	if(num >= 0)
	{
		//歌曲变色
		for(var i = 0; i < song_array.length; i++)
		{
			document.getElementById('songList'+i).style.color = '';
		}
		document.getElementById('songList'+num).style.color = '#cc99cc';
	}
	if(video_flag >= 0)
	{
		//视频变色
		for(var j = 0; j < video_array.length; j++)
		{
			document.getElementById('videoList'+j).style.color = '';
		}
		document.getElementById('videoList'+video_flag).style.color = '#cc99cc';
	}

}
/*//音乐、视频播放时长控制
function songTime(){
	var play_time = 0;
	window.setTimeout('songTime()',1000);
	play_time += audio.currentTime;
	if(play_time > 300)
	{	
		audio.pause();
		audio.currentTime = 0;
		alert("试听结束，每首歌曲可以试听90秒！");
		return false;
	}
	//视频播放时长控制
	var movie_time = 0;
	//window.setTimeout('videoTime()',1000);
	movie_time += video.currentTime;
	if(movie_time > 3600)
	{	
		video.pause();
		video.currentTime = 0;
		alert("试听结束，每个视频可以试看6分钟！");
		return false;
	}	
}*/
/*//用户的歌曲列表
function userSongList()
{	var str = "";
	for(var i=0; i<played_song_array.length; i++)
	{
		str += "<a>"+played_song_array[i]+"</a><br>";
	}
	var a = document.getElementById("userSongList");
	document.getElementById("userSongList").innerHTML = str;
}*/

/******用户信息模块******/
//显示用户信息
function userInfo()
{
	var a = ['用户名：','性别：','密码：','QQ：','邮箱：']
	var b = ['','','密码修改','','']
	var str = '<table><tr><td class="closepage3" colspan="3" align="right"><span onclick="hideUserInfoPage()">关闭</span></td></tr>'
	
	for(var i=0; i < user_info_array.length; i++)
	{
		str += '<tr>'
		str += '<td align="right">'+a[i]+'</td>'
		str += '<td align="left">'+user_info_array[i]+'</td>'
		str += '<td align="left"><a onclick="showPasswordPage()">'+b[i]+'</a></td>'
		str += '</tr>'
	}
	str += '</table>'
	document.getElementById('userInfo').innerHTML = str;
}
//隐藏用户信息界面
function hideUserInfoPage()
{
	var a=document.getElementById('userInfo');
	if(a.style.display=='none')
	{
		a.style.display='block';
	}
	else
	{
		a.style.display='none';		
	}
}

/******用户密码模块******/
//显示用户密码修改页面
function showPasswordPage()
{
	document.getElementById('form03').style.display = "block";	
}
//关闭用户密码修改界面
function closePasswordPage(){
	if(confirm('确定放弃修改密码?'))
	{
		document.getElementById("form03").style.display="none";
	}
}
//用户密码修改验证
function check_reg()
{
	//&& check_len()==true && check_pass()==true && check_email()==true && check_qq()==true
	//check_user() && check_len() && check_qq() && check_email()
	
	if(check_len() && check_pass() && check_newpass_len())
	{
		return true;    
	}else{
		return false;
    }
}
//检查密码长度不能少于6
function check_len(){
	var psw=document.form03.password;
	if(psw.value.length==0)
    {
        document.getElementById('show_pass').innerHTML="密码不能为空";
		document.getElementById('show_pass').style.color="red";
        return false;
    }
	/*if(psw.value.length<6 || psw.value.length>20)
    {
        document.getElementById('show_pass').innerHTML="密码长度只能介于6-20位之间";
		document.getElementById('show_pass').style.color="red";
        return false;
    }*/
        document.getElementById('show_pass').innerHTML="验证通过";
		document.getElementById('show_pass').style.color="green";
        return true;
}
//检查俩次密码输入是否一致
function check_pass(){
    var pwd=document.form03.password;
	var rePwd=document.form03.rePassword;
    if(rePwd.value.length==0)
    {
        document.getElementById('show_repass').innerHTML="密码不能为空";
		document.getElementById('show_repass').style.color="red";
        return false;
    }
	if(rePwd.value!=pwd.value)
    {
        document.getElementById('show_repass').innerHTML="两次密码输入不一致";
		document.getElementById('show_repass').style.color="red";
        return false;
    }
        document.getElementById('show_repass').innerHTML="验证通过";
		document.getElementById('show_repass').style.color="green";
        return true;
}
//检查新密码长度
function check_newpass_len()
{
	var newPwd=document.form03.newPassword;
	if(newPwd.value.length==0)
    {
        document.getElementById('newPassword').innerHTML="密码不能为空";
		document.getElementById('newPassword').style.color="red";
        return false;
    }
	if(newPwd.value.length<6 || newPwd.value.length>20)
    {
        document.getElementById('newPassword').innerHTML="密码长度只能介于6-20位之间";
		document.getElementById('newPassword').style.color="red";
        return false;
    }
        document.getElementById('newPassword').innerHTML="验证通过";
		document.getElementById('newPassword').style.color="green";
        return true;
}

/******用户上传模块******/
function uploadSong()
{	
	/*var flag = '<?php echo $_SESSION["userName"];?>';
	if(flag == ""){
		window.alert("要上传文件，请先登录");
		exit;
	}*/
	var upload_song = document.getElementById('uploadBox');
	//upload_song.style.display = "block";
	if(upload_song.style.display == "block")
	{
		upload_song.style.display = "none";
		//document.getElementById('showSong').innerHTML = "隐藏音乐";
	}
	else
	{
		upload_song.style.display = "block";
		//document.getElementById('showSong').innerHTML = "显示音乐";
	}	
}
//用户安全退出
/*function safeOut()
{
	if(confirm('确定要退出登录?'))
	{
		return true;
	}
	return false;
}*/
//color函数
function color(col)
{
	var a = document.getElementsByName("color");
	for(var i=0; i<a.length; i++){
		a[i].style.color = "#669999";
	}
	col.style.color = "#cc99cc";
}

/******复选框模块******/
//显示复选框
/*function xianshi()
{	
	//显示音乐复选框
	//var a = document.getElementsByName("selectAllSong");
	var a = document.getElementsByName("checkboxTd");
	var b = document.getElementsByName("selectSong[]");
	if(song_flag>=0)
	{
		a[0].style.display="block";
		for(var i=0; i<b.length; i++)
		{
			b[i].style.display="block";
		}
	}
	return true;
	//显示视频复选框
	var c = document.getElementsByName("selectAllVideo");
	var d = document.getElementsByName("selectVideo[]");
	if(video_flag>=0)
	{
		c[0].style.display="block";
		for(var j=0; j<d.length; j++)
		{
			d[j].style.display="block";
		}
	}

}*/
//显示、隐藏音乐复选框
function yincang()
{	
	var a = document.getElementsByName("selectAllSong");
	var b = document.getElementsByName("selectSong[]");
	var c = document.getElementsByName("songTr");
	var d = document.getElementById("editSongs");
	if(a[0].style.display=="none"){
		//显示音乐复选框
		a[0].style.display="block";
		for(var i=0; i<b.length; i++)
		{
			b[i].style.display="block";
		}
		c[0].style.display="table-row";
		d.innerHTML="取消";
	}else{
		//隐藏音乐复选框
		a[0].style.display="none";
		for(var i=0; i<b.length; i++)
		{
			b[i].style.display="none";
		}
		c[0].style.display="none";
		d.innerHTML="编辑";
	}
	//a[0].checked=false;
	
	/*for(var i = 0; i<b.length; i++)
	{
		if(b[i].type=="checkbox")
		{
			b[i].checked=false;
		}
	}*/
	//document.getElementsByName("songTr")[0].style.display="none";
}
//全选音乐复选框
function selectSong()
{
	var a = document.getElementsByName("selectAllSong");
	var b = document.getElementsByName("selectSong[]");
	//var c = document.getElementsByName("songTr");
	if(a[0].checked)
	{
		for(var i = 0; i<b.length; i++)
		{
			b[i].checked = true;
		}
		
		//c[0].style.display = "table-row";
	}
	else
	{
		for(var i = 0;i<b.length;i++)
		{
			b[i].checked = false;
		}

		//c[0].style.display = "none";
	}
	
	//显示歌曲列表内的所有歌曲
	var d=document.getElementsByName("songList");
	if(a[0].checked)
	{
		for(var i=6; i<song_array.length; i++)
		{
			d[i].style.display="table-row";
		}
		document.getElementById("hideSongs").innerHTML="收起更多歌曲";
	}

	checkboxChange();
}
//复选框选中事件
var audio_id=new Array();
var audio_id_str="";
function checkboxChange(thisObj)
{	
	//显示播放选中歌曲按钮
	var a = document.getElementsByName("selectAllSong");
	var b = document.getElementsByName("selectSong[]");
	//var c = document.getElementsByName("songTr");
	var flag = 0;

	/*if(thisObj.checked==false){
		thisObj.checked=false;	
	}else{
		thisObj.checked=true;	
	}*/
	/*if(thisObj.checked==true){
		songs+=thisObj.value;
		alert(songs);
	}else{
		songs=thisObj.value;
		alert(songs);	
	}*/
	
	var song_str="";
	var song_box=new Array();
	var audio_box=new Array();
	var audio_id_box=new Array();
	for(var i=0; i<b.length; i++)
	{
		if(b[i].checked == false)
		{
			flag++;
			//break;
		}else{
			song_str+="+"+b[i].value;
			//audio_box.push(b[i].value);

		}
	}
	//audio_id=song_str;
	//alert(songs);
	
	song_box=song_str.split("+");
	
	//过滤掉数组中的空值
	for(var j=0; j<song_box.length; j++)
	{
		if(song_box[j]==''||song_box[j]==null||typeof(song_box[j])==undefined){
			song_box.splice(j,1);
			j=j-1;
		}		
	}
	
	//得到歌曲名称数组
	for(var k=0; k<song_box.length; k=k+2)
	{
		
		//alert(song_box[k]+"\n");
		audio_box.push(song_box[k]);
	}
	audio_id=audio_box;
	
	//得到歌曲名称和歌曲id数组
	for(var n=0; n<song_box.length; n++)
	{
		
		//alert(song_box[k]+"\n");
		audio_id_box.push(song_box[n]);
	}
	
	audio_id_str=JSON.stringify(audio_id_box);
	//alert(audio_id_str);
	
	if(flag > 0){
		a[0].checked=false;
	}//else{
		//c[0].style.display = "none";
	//}

	/*//显示播放选中视频按钮
	var fl = 0;
	var a = document.getElementsByName("selectVideo[]");
	for(var j=0; j<a.length; j++)
	{
		if(a[j].checked == true)
		{
			fl++;
		}
	}
	if(fl > 0){
		c[1].style.display = "table-row";
	}else{
		c[1].style.display = "none";
	}*/
	
}
//全选视频复选框
/*function selectVideo()
{
	var a = document.getElementsByName("selectAllVideo");
	var b = document.getElementsByName("selectVideo[]");
	
	//var c = document.getElementsByName("songTr");
	if(a[0].checked)
	{
		for(var i = 0; i<b.length; i++)
		{
			if(b[i].type == "checkbox")
			{
				b[i].checked = true;
			}
		}
		
		//c[1].style.display = "table-row";
	}
	else
	{
		for(var i = 0;i<b.length;i++)
		{
			if(b[i].type == "checkbox")
			{
				b[i].checked = false;
			}
		}
		
		//c[1].style.display = "none";
	}
	//showPlay();
}*/

