//判断是手机进入网页还是电脑进入网页
function pc_phone_css(url_pc, url_phone)
{
	var screenWith_v=window.screen.width/640;
	document.documentElement.style.fontSize=screenWith_v*20+"px";
	
	var system ={};  
    var p = navigator.platform;       
    system.win = p.indexOf("Win") == 0;  
    system.mac = p.indexOf("Mac") == 0;  
    system.x11 = (p == "X11") || (p.indexOf("Linux") == 0);     
    if(system.win||system.mac||system.xll){//如果是电脑跳转到百度
		document.getElementById("link").href=url_pc;
        //window.location.href="http://www.baidu.com/";  
    }else{  //如果是手机,跳转到谷歌
		document.getElementById("link").href=url_phone;
        //window.location.href="http://www.google.cn/";  
    }
	
	//判断浏览器是否支持离线缓存
	/*if(window.applicationCache){
        //alert("支持离线缓存");
    }
    else{
        alert("不支持离线缓存");
    }*/
}

function date_time(e){
	//实例：现在的日期时间信息
	var arr = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
	//创建现在的日期对象
	var today = new Date();
	var weilai = new Date("2018/2/16");
	var year = today.getFullYear();
	var month = today.getMonth()+1;
	var date = today.getDate();
	var hours = today.getHours();
	var minutes = today.getMinutes();
	var seconds = today.getSeconds();
	var week = today.getDay();//取值0-6
	var timer1 = today.getTime();
	var timer2 = weilai.getTime();
	var chunjie = (timer2-timer1)/1000/3600/24;
	var guonian = Math.floor(chunjie);
	/*//不够两位，前面补0
	month = month<10? "0"+month : month;
	date = date < 10? "0"+date  : date;*/
	hours = hours<10? "0"+hours : hours;
	minutes = minutes<10? "0"+minutes : minutes;
	seconds = seconds<10? "0"+seconds : seconds;

	if(e==0){
		var str=month+"月"+date+"日<br>"; 
		//str += "<br>"+arr[week];
		str+=hours+":"+minutes+":"+seconds;
		return str;
	}else if(e==1){
		var str=hours+":"+minutes+":"+seconds;
		return str;	
	}else if(e==2){
		var str=year+"年"+month+"月"+date+"日 "; 
		str+=hours+":"+minutes+":"+seconds;
		return str;	
	}

	//构造要输出的结果
	if(e==3){
		var str = hours+":"+minutes+":"+seconds;
		str += "<br>"+arr[week];
		str += "<br>"+year+"年"+month+"月"+date+"日";
		//str += "<br>距离春节还有"+guonian+"天";
		document.getElementById("my_clock").innerHTML=str;
		setTimeout("xzsj()", 1000);
	}
	
	var st="";
	if(hours < 6){
		st = "凌晨好，";
	}
	else if(hours < 10){
		st = "早上好，";	
	}
	else if(hours < 12){
		st = "上午好，";	
	}
	else if(hours < 14){
		st = "中午好，";	
	}
	else if(hours < 18){
		st = "下午好，";	
	}
	else if(hours < 22){
		 st = "晚上好，";	
	}
	else{
		st = "深夜好，";
	}
}

//JS日期时间排序算法
function sort(arr_data_time){
	/*timeArr.sort(
		function(a,b){
			return Date.parse(b.date.replace(/-/g,"/"))-Date.parse(a.date.replace(/-/g,"/"));
		}
	);*/
	arr_data_time.sort(
		function(a, b){  
			if(a.date>b.date){  
				return 1;  
			}else if(a.date<b.date){  
				return -1;  
			}
		}
	);

	return arr_data_time;
}
//一维数组排序
function sort_1(arr){
	
	//自定义函数排序
	arr.sort(
		function(a, b){  
			var a1=parseInt(a);  
			var b1=parseInt(b);  
			if(a1<b1){  
				return -1;  
			}else if(a1>b1){  
				return 1;  
			}
		}
	);
	
	return arr;  
}
//二维数组排序
function sort_2(arr){
	arr.sort(
		function(a, b){  
			var a1=parseInt(a[5]);  
			var b1=parseInt(b[5]);  
			if(a1<b1){  
				return -1;  
			}else if(a1>b1){  
				return 1;  
			}
		}
	);
	
	return arr; 	
}

//数组元素置顶移动
function to_first(arr, index){
	if(index!=0){
		//fieldData[index]=fieldData.splice(0, 1, fieldData[index])[0];这种方法是与另一个元素交换了位子
		arr.unshift(arr.splice(index, 1)[0]);
	}
	return arr; 
}