//全局变量初始化
var audio=null,//音乐对象

video=null,//视频对象

song_flag=null,//音乐id

video_flag=null,//视频id

num=true;//此变量用于隐藏时间

var url_pc_p='./css/search_pc.css';
var url_phone_p='./css/phone.css';
window.onload = function(){
	
	//获取音乐对象
	audio = document.getElementById("audio");
	//audio.volume=0.3;

	//获取视频对象
	video = document.getElementById("video");
	
	//hideForm();

	//songMovie();
	
	//歌曲顺序播放
	seqPlay();
	
	//判断歌曲路径是否错误
	avError();

	//视频顺序播放
	//videoSeqPlay();
	
	//屏蔽浏览器后退按钮
	disableBackward();
	
	//判断是手机进入网页还是电脑进入网页
	wangye(url_pc_p, url_phone_p);

	SearchInfo();
	
	//显示现在的时间
	xzsj();

	//缓存
	//cache();
}
/*//缓存
function cache(){
	
	applicationCache.addEventListener("progress",function(){
        alert(applicationCache.status); //3...    3表示正在下载
	},false);
	
	applicationCache.addEventListener("updateready",function(){
        alert("缓存更新完成");
	},false);
}*/

/******ajax请求模块******/
var audio_name=new Array(),
audio_user=new Array(),
audio_date=new Array(),
video_name=new Array(),
video_user=new Array(),
video_date=new Array(),
a_v_text,
myXmlHttpRequest="";
//flag=false,
function SearchInfo(num){
	
	//获取新输入的关键词
	var a_v_text_new=get_obj("a_v_id").value;
	
	//判断新输入的关键词是否为空
	if(num==0 && a_v_text_new.length==0){
		alert("输入不能为空");
		return false;	
	}
	
	//判断新输入的关键词与之前输入的关键词是否相等
	if(a_v_text_new==a_v_text){
		//alert(a_v_text_new+"——搜索过了，请输入新的关键词查询");
		return false;
	}
	//记录搜索过的关键词
	a_v_text=a_v_text_new;
	
	//开始发送ajax请求
	myXmlHttpRequest=getXmlHttpObject();
	if(!myXmlHttpRequest){
		alert("ajax引擎创建失败");
		return false;	
	}
	
	/*if(!window.localStorage){
		alert("浏览器不支持localstorage");
		return false;
	}
	var storage=window.localStorage;
	var a=storage.getItem("a");
	if(a=="yinle"){
		//storage.setItem("searchInfo",search);
		searchContent=storage.getItem("searchInfo");
	}else{
		searchContent=search;	
	}*/
	
	/*if(get_obj("username").value){
		searchContent=get_obj("username").value;
		flag=true;
		storage.setItem("searchInfo",searchContent);
		storage.setItem("a","yinle");
		//alert(storage.getItem("searchInfo",searchContent));
		//search=searchContent;
	}else{
		//searchContent=search;
		//var searchInfo=storage.getItem("searchInfo");
		//searchContent=searchInfo;
		//alert(searchInfo);
	}*/
	
	var url="./SearchController.php";
	var data;
	if(a_v_text){
		data="search="+a_v_text;
	}else{
		data="search="+search_content;	
	}

	myXmlHttpRequest.open("post", url, true);

	myXmlHttpRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		
	//指定回调函数
	myXmlHttpRequest.onreadystatechange=chuli; 

	//发送
	myXmlHttpRequest.send(data);
	
}
//处理函数
function chuli(){
						
	//接收xml数据
	if(myXmlHttpRequest.readyState==4){
		
		if(myXmlHttpRequest.status!=200){
			alert("ajax请求失败");
			return false;
		}
												
		if(!myXmlHttpRequest.responseXML){
			alert("音乐视频数据获取失败");
			return false;
		}			
				
		var res_audio1=myXmlHttpRequest.responseXML.getElementsByTagName("audioname");
		var res_audio2=myXmlHttpRequest.responseXML.getElementsByTagName("audiouser");
		var res_audio3=myXmlHttpRequest.responseXML.getElementsByTagName("audiodate");
					
		var res_video1=myXmlHttpRequest.responseXML.getElementsByTagName("videoname");
		var res_video2=myXmlHttpRequest.responseXML.getElementsByTagName("videouser");
		var res_video3=myXmlHttpRequest.responseXML.getElementsByTagName("videodate");

		if(audio_name.length>0){ //全局变量代表当前的一种状态，所以要置空
			audio_name.length=0;
			audio_user.length=0;
			audio_date.length=0;
			song_flag=null;
			y=-1;
		}
		if(video_name.length>0){
			video_name.length=0;
			video_user.length=0;
			video_date.length=0;
			video_flag=-1;
		}
		
		//取出搜索到的歌曲信息
		for(var i=0;i<res_audio1.length;i++){
					
			//歌曲名称
			audio_name.push(res_audio1[i].childNodes[0].nodeValue);
					
			//歌曲上传人
			audio_user.push(res_audio2[i].childNodes[0].nodeValue);

			//歌曲上传时间
			audio_date.push(res_audio3[i].childNodes[0].nodeValue);
		}
		//清空表格样式
		if(res_audio1.length>0){
			get_obj('table01').style='';
		}

		//取出搜索到的视频信息
		for(var i=0;i<res_video1.length;i++){
					
			//视频名称
			video_name.push(res_video1[i].childNodes[0].nodeValue);
					
			//视频上传人
			video_user.push(res_video2[i].childNodes[0].nodeValue);

			//视频上传时间
			video_date.push(res_video3[i].childNodes[0].nodeValue);
		}
		//清空表格样式
		if(res_video1.length>0){
			get_obj('table02').style='';
		}
		
		//显示搜索到的音乐
		ShowAudio();
		
		//显示搜索到的视频
		show_video_m();
		
		//显示搜索到的音乐、视频个数
		AudVidNum();
	}
}

/******音乐模块******/
//判断歌曲路径是否错误
function avError()
{
	audio.addEventListener("error",av,false);
	function av()
	{
		//alert(audio_name[song_flag]+"，歌曲文件不存在");
		/*audio.src="upload/"+audio_user[song_flag++]+"/"+audio_name[song_flag++];
		audio.play();
		get_obj("songName").innerHTML="正在听歌："+audio_name[song_flag++];
		songColor(song_flag++);*/
		
	}
}
//搜索到的音乐、视频数量
function AudVidNum()
{
	get_obj("resnum").innerHTML="搜索到"+(audio_name.length+video_name.length)+"条结果";
	get_obj("hideAudioList").innerHTML="音乐("+audio_name.length+")";
	get_obj("hideVideoList").innerHTML="视频("+video_name.length+")";
}
//判断音乐视频数组是否为空
/*function hideForm()
{	
	if(song_array.length==0)
	{
		//document.getElementById("form01").style.display = "none";
		document.getElementById("hideAudioList").style.color="#ccc";
	}
	if(video_array.length==0)
	{
		//document.getElementById("form02").style.display = "none";
		document.getElementById("hideVideoList").style.color="#ccc";
	}
}*/

//显示音乐
function ShowAudio()
{
	var str="";
	//<input type="checkbox" name="selectAllSong" onclick="selectSong()" style="display:none">
	
	for(var i=0; i<audio_name.length; i++)
	{
		str+="<tr name=songList>"
		str+="<td class=song_name_c>"
		str+="<span id=songList"+i+" onclick=play_song("+i+")>"+audio_name[i]+"</span>"
		str+="</td>"
		str+="<td class=showAudioList>"
		str+="<span id=xiaodian"+i+" onclick=audioList("+i+")>...</span>"
		str+="</td>" 
		str+="</tr>";

		str+="<tr id=playerlist"+i+" style=display:none>"
		str+="<td colspan=2>"
		str+="<p id=play_list_i>"
		str+="<span onclick=bfzt("+i+")>播放/暂停</span>"
		str+="<span id=downLoadAudio"+i+" onclick=downLoadAudio("+i+")>下载</span>"
		str+="<span onclick=ShowAudioInfo("+i+")>歌曲资料</span>"
		str+="</p>"
		str+="</td>"
		str+="</tr>";
	}
	//<input  class="viewMore" id="hideSongs" type="button" value="查看更多歌曲" onclick="viewMoreSong()">
	str+="<tr id=hideAudioTr style=display:none>"
	str+="<td><span id=end_line_i>到底了</span></td>"
	str+="<td></td>"
	str+="</tr>";
	
	if(audio_name.length==0){
		get_obj('table01').innerHTML='没找到音乐';
		get_obj('table01').style='width:100%;height:15rem;color:gray;font-size:1.6rem;font-weight:bold;display:flex;justify-content:center;align-items:Center;';
	}else{
		get_obj('table01').innerHTML=str;
	}
}

//音乐播放
var downUserName=null;
var downAudioName=null;
//var audio_num=0;
function play_song(s)
{
	//隐藏视频列表盒子
	//document.getElementById("movieBox").style.display="none";
	//video.pause();
	
	var a=document.getElementById("songBox");
	var b=document.getElementById("hide_show_i");
	if(a.style.display=="none"){
		a.style.display="block";
		b.innerHTML='隐藏音乐';
	}else{
		a.style.display="none";
		b.innerHTML='显示音乐';	
	}
	
	//如果当前点击的歌曲跟上一首歌曲不同，则执行以下代码
	if(s!=song_flag){
		
		a.style.display="block";	
		b.innerHTML='隐藏音乐';
		
		audio.src="upload/"+audio_user[s]+"/"+audio_name[s];
		audio.play();
		get_obj("songName").innerHTML="正在听歌："+audio_name[s];
		
		song_flag=s; //song_flag 代表当前播放的歌曲
		y=song_flag; //给顺序播放用

		songColor(s);

		//记录当前的播放地址和歌曲
		downUserName=audio_user[s];//给下载用
		downAudioName=audio_name[s];
		
		//隐藏点击的播放菜单
		if(s!=list_flag){
			get_obj('playerlist'+list_flag).style.display='none';
		}
	}else{
		//如果是同一首歌曲
		audio.play();	
	}
	
	/*for(var i=0; i<audio_name2.length; i++){
		
		if(audio_name[s]==audio_name2[i]){
			//flag++;
			//break;
			return;
		}
	}*/
	//audio_user2.push(audio_user[s]);
	//audio_name2.push(audio_name[s]);
	//abc(audio_name[s],audio_user[s]+"/"+audio_name[s]);
	/*for(var j=0; j<audio_name2.length; j++){
		alert(audio_user2[j]+"——"+audio_name2[j]);
	}*/
	//alert(y);
	//xianshi();
	//songTime();
}
//点击歌曲变色
function songColor(num)
{	
	if(num>=0)
	{
		//歌曲变色
		for(var i=0; i<audio_name.length; i++)
		{
			//$('songList'+i).style.color='';
			get_obj('songList'+i).style='color:none;background-color:none;';
			//$('playerlist'+i).style.display='none';
		}
		//$('songList'+num).style.color='#669999';
		get_obj('songList'+num).style='color:#cc99cc;padding:1rem;'
		+'background-color:#ebebeb;';
	}
}
//音乐播放、暂停函数
function bfzt(num)
{	
	//如果没有歌曲播放或者当前播放的歌曲与上一首不同
	if(audio.paused || num!=song_flag){
		play_song(num);
		//$('playerlist'+num).style.display='block';
	}else{
		audioPause(num);	
	}
}
//暂停当前播放的歌曲
function audioPause(num)
{	
	//暂停当前正在播放的歌曲
	if(num==song_flag){
		audio.pause();	
	}
}
//音乐顺序播放
var y=null;
function seqPlay()
{
	document.getElementById('seqPlay').style.color='green';
	document.getElementById("songLoop").style.color='';
			
	audio.loop="";
	audio.onended=function()
	{	
		//song_name.style.color = '#669999';
		y++;
		if(audio_name[y])
		{
			songColor(y);
			//this.setAttribute("src",path+song_path[i]);
			/*audio.src="upload/"+audio_user[y]+"/"+audio_name[y];
			audio.play();
			document.getElementById("songName").innerHTML="正在听歌："+audio_name[y];
			song_flag=y;*/
			play_song(y);//播放器
		}
		else
		{
			//当song_path数组里元素的值为undefined时，执行以下代码
			if(audio_name.length==0){
				alert("没有歌曲可播放了！");
			}else{
				y=0;
				seqPlay();
				play_song(y);
				/*audio.src="upload/"+audio_user[y]+"/"+audio_name[y];
				document.getElementById("songName").innerHTML="正在听歌："+audio_name[y];
				audio.play();
				songColor(y);*/
			}
		}
	}
}
//音乐循环播放
function songLoop()
{	
	audio.loop="loop";
	var song_loop = document.getElementById("songLoop");
	song_loop.style.color="red";
	document.getElementById('seqPlay').style.color='';
}
//下载
function downLoadAudio(id)
{
	if(userName){
		
		var url="./download.php?username="+audio_user[id]+"&filename="+audio_name[id];
		window.location.href=url;
		//alert(url);
		
		/*var a=document.getElementById("downLoadAudio"+id);
		a.href=url;
		a.download=audio_name[id];*/
	}else{
		
		alert("你还没有登录，不能下载该歌曲");
	}
}
//下载正在播放的歌曲
function downLoadSong()
{	
	//判断状态
	if(downUserName==null||downAudioName==null){
		alert("没有播放歌曲，不知怎么下载");
		return false;
	}
	//判断用户是否登录
	if(userName){
		var username_01=downUserName;
		var filename=downAudioName;
		var url="./download.php?username="+username_01+"&filename="+filename;
		window.location.href=url;
		//alert(url);
		
		//var url=down_src;
		/*var a=document.getElementById("downLoadSong");
		a.href=url;
		a.download=down_name;*/
	}else{
		
		alert("你还没有登录，不能下载该歌曲");
	}
}

var list_flag=0;
function audioList(num)
{
	list_flag=num;
	var a=get_obj('playerlist'+num);
	var b=get_obj('xiaodian'+num);
	if(a.style.display=="none"){
		for(var i=0; i<audio_name.length; i++){
			get_obj('playerlist'+i).style.display="none";
			get_obj('xiaodian'+i).style.color='';
		}
		a.style.display="table-row";
		b.style.color='#cc99cc';
	}else{
		a.style.display="none";
		b.style.color='';
	}
}
//隐藏音乐列表
function hideAudioList()
{
	var a=document.getElementById("form01");
	var b=document.getElementById("hideAudioList");
	var c=document.getElementById("hideVideoList");
	
	if(a.style.display=="none"){
		a.style.display="block";
		b.style.color="#cc99cc";
		//b.style.borderBottom="0.2rem solid #cc99cc";
		c.style.color="";
		c.style.borderBottom="";
		document.getElementById("form02").style.display="none";
	}
}
//显示歌曲信息
function ShowAudioInfo(num)
{	
	var a=document.getElementById('show_audio_info_i');
	if(a.style.display=="none"){
		a.style.display="block";
	}else{
		a.style.display="none";	
	}

	var b=document.getElementById('audio_name_i');
	var c=document.getElementById('audio_user_i');
	var d=document.getElementById('audio_date_i');
	b.innerHTML='歌名：'+audio_name[num];
	c.innerHTML='上传人：'+audio_user[num];
	d.innerHTML='上传时间：'+audio_date[num];
	
}
//判断歌曲、视频列表是否超过19首歌曲
function showSongListEnd()
{
	if(audio_name.length>19)
	{
		document.getElementById("hideAudioTr").style.display="table-row";		
	}

	/*if(video_array.length>19)
	{
		document.getElementById("hideVideoTr").style.display="table-row";		
	}*/
}

/*//查看更多歌曲
function viewMoreSong()
{
	var a=document.getElementsByName("songList");
	
	for(var i=6; i<song_array.length; i++)
	{
		if(a[i].style.display=="none")
		{
			a[i].style.display="table-row";
			document.getElementById("hideSongs").value="收起更多歌曲";
			document.getElementById("songBox").style.display="none";
		}
		else
		{
			a[i].style.display="none";
			document.getElementById("hideSongs").value="查看更多歌曲";
			document.getElementById("songBox").style.display="block";
		}
		
	}
}*/
/*//判断歌曲列表是否超过6首歌曲
function songMovie()
{
	var a=document.getElementsByName("songList");
	if(song_array)
	{
		if(song_array.length>6)
		{	//值table-row解决了表格由隐藏到显示变形的问题
			document.getElementById("viewSong").style.display="table-row";
			for(var i=6; i<song_array.length; i++)
			{
				a[i].style.display="none";
				
			}
		}
	}
	//判断视频列表是否超过3个视频
	var b=document.getElementsByName("videoList");
	if(video_array)
	{
		if(video_array.length>3)
		{
			document.getElementById("viewVideo").style.display="table-row";
			for(var j=3; j<video_array.length; j++)
			{
				b[j].style.display="none";
				
			}	
		}
	}
}*/
//用户的歌曲列表
/*function userSongList()
{	var str = "";
	for(var i=0; i<played_song_array.length; i++)
	{
		str += "<a>"+played_song_array[i]+"</a><br>";
	}
	var a = document.getElementById("userSongList");
	document.getElementById("userSongList").innerHTML = str;
}*/



/******视频模块******/
//显示视频
function ShowVideo()
{
	//echo '<form class="form02" id="form02" action="video.php" method="post" style="display:none">';
	//echo '<table>';
				/*<td>
					<input type="checkbox" name="selectAllVideo" onclick="selectVideo()" style="display:none">
				</td>*/
		/*echo '<tr>
				<td>
					<p>'.count($video_name).'个视频</p>
				</td>
				<!-- <td>
					<p>上传用户</p>
				</td> -->
			</tr>';*/
	var str="";
	for(var i=0; i<video_name.length; i++)
	{			/*<td>
					<input type='checkbox' name='selectVideo[]' value=\"$array_push[$i]\" onclick='showPlay()' style='display:none'>
				</td>*/
		str+="<tr name=videoList>"
		str+="<td>"
		str+="<span id=videoList"+i+" onclick=videoBox("+i+")>"+video_name[i]+"</span>"
		str+="<section id=uploadVideo"+i+" style=display:none>"
		str+="<ul>"
		str+="<li>视频："+video_name[i]+"</li>"
		str+="<li>上传人："+video_user[i]+"</li>"
		str+="<li>上传时间："+video_date[i]+"</li>"
		str+="<li class=yemian><span onclick=ShowVideoInfo()>关闭页面</span></li></ul>"
		str+="</section>"
		str+="</td>"
		str+="</tr>";
	}
		/*echo '<tr name="songTr" style="display:none">
				<td colspan=2>
					<input class="viewMore" type="submit" value="播放选中视频">
				</td>
			</tr>';*/
	
	/*echo '<tr id="viewVideo" style="display:none">
			<td colspan=2>
				<input  class="viewMore" id="hideVideos" type="button" value="查看更多视频" onclick="viewMoreMovie()">
			</td>
		</tr>';*/
	str+="<tr id=hideVideoTr style=display:none>"
	str+="<td class=viewMore colspan=2>到底了</td>"
	str+="</tr>";
	//echo '</table>';
	//echo '</form>';
	
	if(video_name.length==0){
		get_obj("table02").innerHTML='没找到视频';
		get_obj("table02").style='width:100%;height:15rem;color:gray;font-size:1.6rem;font-weight:bold;display:flex;justify-content:center;align-items:Center;';
	}else{
		get_obj("table02").innerHTML=str;
	}
}
//播放视频
function videoBox(v)
{	
	//暂停正在播放的音乐
	audio.pause();
	
	video_text_color_f(v);
	
	//获取视频盒子movieBox对象
	var a=document.getElementById("movieBox");
	a.style.display="block";
	
	if(v==video_flag)
	{	
		video.play();
	}else{
		video.src = "upload/"+video_user[v]+"/"+video_name[v];
		video.play();
		document.getElementById("videoName").innerHTML="正在观看："+video_name[v];
		video_flag=v;
		q=v;
	}
	
	//songColor();
	//xianshi();
	//songTime();
}

//显示搜索到的视频
function show_video_m()
{	
	var str="";
	for(var i=0; i<video_name.length; i++)
	{	
		str+="<tr name=videoList>"
		str+="<td>"
		str+="<span id=videoList"+i+" onclick=play_video_m("+i+")>"+video_name[i]+"</span>"
		str+="<section id=uploadVideo"+i+" style=display:none>"
		str+="<ul>"
		str+="<li>视频："+video_name[i]+"</li>"
		str+="<li>上传人："+video_user[i]+"</li>"
		str+="<li>上传时间："+video_date[i]+"</li>"
		str+="<li class=yemian><span onclick=ShowVideoInfo()>关闭页面</span></li></ul>"
		str+="</section>"
		str+="</td>"
		str+="</tr>";
	}
	str+="<tr id=hideVideoTr style=display:none>"
	str+="<td class=viewMore colspan=2>在怎么找，也没有了。</td>"
	str+="</tr>";
	
	if(video_name.length==0){
		get_obj("table02").innerHTML='没找到视频';
		get_obj("table02").style='width:100%;height:15rem;color:gray;font-size:1.6rem;font-weight:bold;display:flex;justify-content:center;align-items:Center;';
	}else{
		get_obj("table02").innerHTML=str;
	}
}
//播放视频
function play_video_m(key)
{	
	//暂停正在播放的音乐
	audio.pause();
	
	video_text_color_f(key);
	var video_info_o={
		video_user_v:video_user[key],
		video_name_v:video_name[key],
		video_date_v:video_date[key]
	}
	
	var video_info_v=JSON.stringify(video_info_o);
	var url_v='./play_video.php';
	var num_v=random_num_m(100000, 999999);
	//alert(num_v);
	var data_v='?video_info_v='+video_info_v+'&num_v='+num_v;
	window.open(url_v+data_v);
	return true;
	
	//post_m(url_v, video_info_v);
	/*var video_info_a=new Array(3);//固定数组长度为3
	video_info_a['video_user_k']=video_user[key];
	video_info_a['video_name_k']=video_name[key];
	video_info_a['video_date_k']=video_date[key];*/
	//暂停正在播放的音乐
	//audio.pause();
	//video_text_color_f(v);
	
	//var x_v=get_obj('videoList'+key);//获取当前点击的视频
	
	
	//if(x_v.addEventListener){//所有主流浏览器，除了 IE 8 及更早 IE版本
		
		//x_v.addEventListener('click', function(){
			
			
		
		//});
	
	//}else if(x_v.attachEvent){// IE 8 及更早 IE 版本
		
		//x_v.attachEvent('onclick', function(){
			
			//post_m(url_v, video_info_o);
		
		//});
	//}
	
	//get_obj('videoList'+key).addEventListener(click,post_m);
}
//随机数
function random_num_m(Min, Max){
	var Range = Max - Min;
	var Rand = Math.random();
	var num = Min + Math.round(Rand * Range);//四舍五入
	return num;
}
/*function post_m(url_v, video_v){
	
	var data_v='?video_info_v='+video_v;
	window.open(url_v);
	return true;
	
	var xml_v;
	xml_v=getXmlHttpObject();
	
	if(!xml_v){
		alert('ajax对象创建失败');
		return false;
	}
	
	var data_v='video_info_v='+video_v;
	//alert(data_v);
	//return;
	xml_v.open('post', url_v, false);
	xml_v.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	
	//发送
	xml_v.send(data_v);
	return true;
	//window.open(url_v);
	//location.href=url_v;
	//location.replace(url_v);
	//使用定时器，每隔5秒
	//window.setInterval("updateGoldPrice()",5000);

}//ajax函数结束*/

//关闭视频页面
function shipin()
{
	if(confirm('真的要离开视频观看?'))
	{
		document.getElementById("movieBox").style.display="none";
		video.pause();
		if(song_flag>=0){
			audio.play();
		}
	}
}
//显示视频资料
function ShowVideoInfo()
{	
	var a=document.getElementById("uploadVideo"+q);
	if(a.style.display=="none"){
		a.style.display="block";
	}else{
		a.style.display="none";	
	}
}
//点击视频变色
function video_text_color_f(num)
{
	if(num>=0)
	{
		//视频变色
		for(var j=0; j<video_name.length; j++)
		{
			document.getElementById('videoList'+j).style='color:none;background-color:none';
			//document.getElementById('uploadVideo'+j).style.display='none';
		}
		document.getElementById('videoList'+num).style='color:#cc99cc;'
		+'padding:1rem;background-color:#ebebeb';
		//document.getElementById('uploadVideo'+num).style.display='block';
	}
}
//视频顺序播放
var q=0;
function videoSeqPlay()
{
	
	document.getElementById('videoSeqPlay').style.color='green';
	document.getElementById("videoLoop").style.color='';
	video.loop='';
	
	video.onended=function()
	{	
		q++;
		if(video_name[q])
		{
			video_text_color_f(q);
			//this.setAttribute("src",path+song_path[i]);
			video.src="upload/"+video_user[q]+"/"+video_name[q];
			video.play();
			document.getElementById("videoName").innerHTML="正在观看："+video_name[q];
			video_flag=q;
			//document.getElementById("downLoadSong").href = "upload/"+song_array[y];
			//document.getElementById("downLoadSong").download = song_array[y];
		}
		else
		{
			//当song_path数组里元素的值为undefined时，执行以下代码
			//i = 0;
			alert("没有视频可观看了！");
		}
	}
}
//视频重复播放
function videoLoop()
{	
	var video_loop=document.getElementById("videoLoop");
	if(confirm('你确定要重新开始播放该视频？'))
	{
		video.src="upload/"+video_user[video_flag]+"/"+video_name[video_flag];
		video.play();
		video.loop="loop";
		video_loop.style.color="red";
		document.getElementById('videoSeqPlay').style.color='#669999';
	}else{
		video.loop="";
		video_loop.style.color="#669999";
	}
}
//下载视频
function downLoadMovie()
{
	if(userName){
		var a=document.getElementById("downLoadMovie");
		a.href="upload/"+video_user[video_flag]+"/"+video_name[video_flag];
		a.download=video_name[video_flag];
	}else{
		alert("想要下载该视频，请先登录");	
	}
}
//显示视频列表
function hideVideoList()
{
	var a=document.getElementById("form02");
	var b=document.getElementById("hideVideoList");
	var c=document.getElementById("hideAudioList");
	
	if(a.style.display=="none"){
		a.style.display="block";
		b.style.color="#cc99cc";
		//b.style.borderBottom="0.2rem solid #cc99cc";
		c.style.color="";
		c.style.borderBottom="";
		document.getElementById("form01").style.display="none";
		//document.getElementById("songBox").style.display="none";
	}/*else{
			//a.style.display="block";
		}*/
}
//查看更多视频
function viewMoreMovie()
{
	var a = document.getElementsByName("videoList");
	
	for(var i=3; i<video_array.length; i++)
	{
		if(a[i].style.display == "none")
		{
			a[i].style.display = "table-row";
			document.getElementById("hideVideos").value = "收起更多视频";
		}
		else
		{
			a[i].style.display = "none";
			document.getElementById("hideVideos").value = "查看更多视频";
		}
		
	}
}
/*//音乐、视频播放时长控制
function songTime(){
	var play_time = 0;
	window.setTimeout('songTime()',1000);
	play_time += audio.currentTime;
	if(play_time > 300)
	{	
		audio.pause();
		audio.currentTime = 0;
		alert("试听结束，每首歌曲可以试听90秒！");
		return false;
	}
	//视频播放时长控制
	var movie_time = 0;
	//window.setTimeout('videoTime()',1000);
	movie_time += video.currentTime;
	if(movie_time > 3600)
	{	
		video.pause();
		video.currentTime = 0;
		alert("试听结束，每个视频可以试看6分钟！");
		return false;
	}	
}*/



/*//随机网页背景色
function pageColor()
{
	//实例：网页随机背景色
	var min = 100000;
	var max = 999999;
	var random = Math.random()*(max-min)+min;
	//向下取整
	random = Math.floor(random);

	document.body.style.backgroundColor="#"+random;	
}*/
//随机视频背景色
function videoColor()
{
	//实例：网页随机背景色
	var min = 100000;
	var max = 999999;
	var random = Math.random()*(max-min)+min;
	//向下取整
	random = Math.floor(random);

	document.getElementById("movieBox").style.backgroundColor="#"+random;
}
//默认颜色
function defaultColor()
{
	//视频背景色
	document.getElementById("movieBox").style.backgroundColor="white";
}
/*//刷新当前页面函数
function test()
{
	location.href='';
}

//color函数
function color(col)
{
	var a = document.getElementsByName("color");
	for(var i=0; i<a.length; i++){
		a[i].style.color = "#669999";
	}
	col.style.color = "#cc99cc";
}
//判断服务器上是否存在文件
var xmlhttp;
function loadXMLDoc(url)
{
	xmlhttp=null;
	if(window.XMLHttpRequest)
	{	// code for all new browsers
		xmlhttp=new XMLHttpRequest();
	}
	else if(window.ActiveXObject)
	{	// code for IE5 and IE6
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(xmlhttp!=null)
	{
		xmlhttp.onreadystatechange=state_Change;
		xmlhttp.open("GET",url,true);
		xmlhttp.send(null);
	}
	else
	{
		alert("Your browser does not support XMLHTTP.");
	}
}
function state_Change()
{
	if(xmlhttp.readyState==4)
	{
		if(xmlhttp.status==200)
		{
			alert("文件存在");
		}
		else
		{
			alert("文件不存在");
		}
	}
}
function meimei()
{
	loadXMLDoc('./user_upload.php');
}

//显示复选框
function xianshi()
{	
	//显示音乐复选框
	var a = document.getElementsByName("selectAllSong");
	var b = document.getElementsByName("selectSong[]");
	if(song_flag>=0)
	{
		a[0].style.display="block";
		for(var i=0; i<b.length; i++)
		{
			b[i].style.display="block";
		}
	}
	//显示视频复选框
	var c = document.getElementsByName("selectAllVideo");
	var d = document.getElementsByName("selectVideo[]");
	if(video_flag>=0)
	{
		c[0].style.display="block";
		for(var j=0; j<d.length; j++)
		{
			d[j].style.display="block";
		}
	}

}
//全选音乐复选框
function selectSong()
{
	var a = document.getElementsByName("selectAllSong");
	var b = document.getElementsByName("selectSong[]");
	
	var c = document.getElementsByName("songTr");
	if(a[0].checked)
	{
		for(var i = 0; i<b.length; i++)
		{
			if(b[i].type == "checkbox")
			{
				b[i].checked = true;
			}
		}
		
		c[0].style.display = "table-row";
	}
	else
	{
		for(var i = 0;i<b.length;i++)
		{
			if(b[i].type == "checkbox")
			{
				b[i].checked = false;
			}
		}

		c[0].style.display = "none";
	}
	//showPlay();
}
//复选框选中事件
function showPlay()
{	
	//显示播放选中歌曲按钮
	var flag = 0;
	var b = document.getElementsByName("selectSong[]");
	var c = document.getElementsByName("songTr");
	for(var i=0; i<b.length; i++)
	{
		if(b[i].checked == true)
		{
			flag++;
		}
	}
	
	if(flag > 0){
		c[0].style.display = "table-row";
	}else{
		c[0].style.display = "none";
	}

	//显示播放选中视频按钮
	var fl = 0;
	var a = document.getElementsByName("selectVideo[]");
	for(var j=0; j<a.length; j++)
	{
		if(a[j].checked == true)
		{
			fl++;
		}
	}
	if(fl > 0){
		c[1].style.display = "table-row";
	}else{
		c[1].style.display = "none";
	}
	
}
//全选视频复选框
function selectVideo()
{
	var a = document.getElementsByName("selectAllVideo");
	var b = document.getElementsByName("selectVideo[]");
	
	var c = document.getElementsByName("songTr");
	if(a[0].checked)
	{
		for(var i = 0; i<b.length; i++)
		{
			if(b[i].type == "checkbox")
			{
				b[i].checked = true;
			}
		}
		
		c[1].style.display = "table-row";
	}
	else
	{
		for(var i = 0;i<b.length;i++)
		{
			if(b[i].type == "checkbox")
			{
				b[i].checked = false;
			}
		}
		
		c[1].style.display = "none";
	}
	//showPlay();
}*/
//隐藏浏览器工具栏菜单栏
/*function HideToolMenu()
{
	window.open('index.php','_blank','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,top=0,left=0,width=790,height=545');
}*/

//音乐信息数组转换成字符串
/*function AudioToString()
{	
	var str="";
	for(var i=0; i<audio_name2.length; i++){
		if(i==audio_name2.length-1){
			str+=audio_name2[i];
			break;
		}
		str+=audio_name2[i]+"+";
	}
	//alert(str);
	//abc(str);
}*/
//播放的歌曲存储到本地
/*function abc(str_audio_name,str)
{
	//通过key来获取value
	var dt=localStorage.getItem("SongName");
	var song_user=null;
	var song_name=null;
	var flag=0;
	if(songName==null){
		song_name=str_audio_name+"+";
		//localStorage.setItem("demokey",song_name);
	}else{
		song_name=str_audio_name+"+"+dt;
		
		var arr=dt.split("+");
		for (var j=0; j<arr.length; j++){ 
			if(str_audio_name==arr[j]){
				flag++;
				break;
			}
		}
	}

	//添加key-value 数据到 sessionStorage
	if(flag==0){
		localStorage.setItem("demokey",song_name);
		
		var dt2=localStorage.getItem("demokey");
		var arr2=dt2.split("+");
		var str2="";
		for (var i=0; i<arr2.length; i++){ 
			str2+=arr2[i]+"\n";	
		}
		alert(str2);
	}
	//dt=localStorage.getItem("demokey");
	//alert(dt);

	
	//清空所有的key-value数据。
	//localStorage.clear();
	//alert(localStorage.length);	
}*/

