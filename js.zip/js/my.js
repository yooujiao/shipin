//创建ajax引擎
function getXmlHttpObject(){
		
	var xmlHttpRequest;
		
	//不同的浏览器获取对象xmlhttprequest 对象方法不一样
	if(window.ActiveXObject){
		xmlHttpRequest=new ActiveXObject("Microsoft.XMLHTTP"); 
	}else{
		xmlHttpRequest=new XMLHttpRequest();
	}
	
	return xmlHttpRequest;
}



//这里我们写一个函数
function get_obj(id){
	return document.getElementById(id);	
}

//显示、隐藏
function show_hide(id)
{
	var a=document.getElementById(id);
	if(a.style.display=="none"){
		a.style.display="block";	
	}else{
		a.style.display="none";
	}
}
//隐藏、显示时间
function show_hide_color(id, color)
{
	var a=document.getElementById(id);
	var b=document.getElementById(color);
	if(a.style.display=="none"){
		a.style.display="block";
		b.style.color="green";
	}else{
		a.style.display="none";
		b.style.color="red";
	}
}
//显示、隐藏音乐播放器
function show_hide_a(id, num)
{
	var a=document.getElementById(id);
	var b=document.getElementById("hide_show_i");
	if(a.style.display=="none"){
		a.style.display="block";
		//b.style.color='green';
		b.innerHTML='隐藏音乐';
	}else{
		a.style.display="none";
		//b.style.color='#ccc';
		b.innerHTML='显示音乐';
	}
	//audio_num=num;
	//b.style.borderBottom="0.2rem solid #cc99cc";
}
//判断是手机进入网页还是电脑进入网页
function wangye(url_pc, url_phone)
{
	/*var a = escape("中国"+"px");
	alert(a);
	alert(unescape(a));*/
	
	var screenWith_v=window.screen.width/640;
	document.documentElement.style.fontSize=screenWith_v*20+"px";
	//alert(screenWith_v*20+"px");
	
	var system ={};  
    var p = navigator.platform;       
    system.win = p.indexOf("Win") == 0;  
    system.mac = p.indexOf("Mac") == 0;  
    system.x11 = (p == "X11") || (p.indexOf("Linux") == 0);     
    if(system.win||system.mac||system.xll){//如果是电脑跳转到百度
		document.getElementById("link").href=url_pc;
        //window.location.href="http://www.baidu.com/";  
    }else{  //如果是手机,跳转到谷歌
		document.getElementById("link").href=url_phone;
        //window.location.href="http://www.google.cn/";  
    }
	
	//判断浏览器是否支持离线缓存
	/*if(window.applicationCache){
        //alert("支持离线缓存");
    }
    else{
        alert("不支持离线缓存");
    }*/
}
//首页
function home_page()
{	
	if(confirm('是否要回到首页'))
	{
		//window.open('index.php');
		window.location.href="index.php";
	}
}
//后退
function back_page_m(){
	
	//if(confirm('是否要放弃注册，然后返回上一页？')){
		history.back();//返回但不刷新
		/*if(history.back()){
			//window.history.go(-1);//返回并刷新
		}else{
			window.location.href="SearchUI.php";
		}*/
		//window.location.href = document.referrer;//返回上一页并刷新
	//}

	//location.replace('./SearchUI.php');
	//location.assign('./SearchUI.php');
}

/*关闭网页*/
function close_page_m(){
	
	if(confirm('真的要关闭网页')){
		/***第一种关闭网页的方法***/
		/*window.opener = null;
		window.open('', '_self');
		window.close();*/
		
		/***第二种关闭网页的方法***/
		open(location, '_self').close();

		//关闭微信网页
		WeixinJSBridge.call('closeWindow');

		/*
			var userAgent = navigator.userAgent;
			if(userAgent.indexOf("Firefox") != -1 || userAgent.indexOf("Chrome") != -1){
				location.href = "about:blank";
			}else{
				window.opener = null;
				window.open('', '_self');
			}
			
			window.close();

			WeixinJSBridge.call('closeWindow');*/
		

		/*//兼容所有浏览器并不出现提示窗口的关闭当前页面函数
		if(navigator.userAgent.indexOf("MSIE") > 0){
			
			if(navigator.userAgent.indexOf("MSIE 6.0") > 0){	//适用于ie6不带提示关闭窗口
				window.opener = null;
				window.close();
			}else{
				window.open('', '_top');         //ie7之后不提示关闭窗口
				window.top.close();
			}
		
		}
		else if(navigator.userAgent.indexOf("Firefox") > 0){	//Firefox不提示关闭窗口
			window.location.href = 'about:blank';
		}
		else{
			window.opener = null;
			window.open('', '_self', ''); //其他浏览器
			window.close();
		}*/
	
	}

}

function white_page(){
	event.stopPropagation();//阻止触发外层元素的点击事件
}
//屏蔽浏览器后退按钮
function disableBackward()
{
	//防止页面后退
	history.pushState(null, null, document.URL);
	window.addEventListener('popstate', function(){
	history.pushState(null, null, document.URL);
	});
}