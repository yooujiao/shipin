<?php
//session_start();
//echo '<pre>';
print_r(search_info());
//echo '</pre>';
//上证指数、深证成指
function sh_sz($e){
	
	if($e==0){
		$url_1='http://hq.sinajs.cn/list=s_sh000001';
		
		$res_sh=file_get_contents($url_1);
		$res_sh=iconv('gbk', 'utf-8', $res_sh);
		$res_sh=str_replace('"', '', $res_sh);
		$res_sh=trim(str_replace(';', '', $res_sh));
		$res_sh=substr($res_sh, strripos($res_sh, "=")+1);
		
		$arr_h=array();
		$arr_h=explode(',', $res_sh);
		
		$arr_sh=array();
		$arr_sh['sh_sz']=$arr_h[0];
		$arr_sh['xianzai']=sprintf("%.2f", $arr_h[1]);
		$arr_sh['zhangdie']=sprintf("%.2f", $arr_h[2]);
		$arr_sh['zhangdielv']=$arr_h[3].'%';
		$arr_sh['shuliang']=sprintf("%.2f", $arr_h[4]/1000000).'亿';
		$arr_sh['jine']=sprintf("%.2f", $arr_h[5]/10000).'亿';
		$arr_sh['daima']='000001';
		$arr_sh['id']=0;
		
		foreach($arr_sh as $key=>$value){ 
			$arr_sh[$key]=urlencode($value); 
		}
		return $arr_sh;
	}
	
	if($e==1){
		$url_2='http://hq.sinajs.cn/list=s_sz399001';
		
		$res_sz=file_get_contents($url_2);
		$res_sz=iconv('gbk', 'utf-8', $res_sz);
		$res_sz=str_replace('"', '', $res_sz);
		$res_sz=trim(str_replace(';', '', $res_sz));
		$res_sz=substr($res_sz, strripos($res_sz, "=")+1);
		
		$arr_z=array();
		$arr_z=explode(',', $res_sz);
		$arr_sz=array();
		$arr_sz['sh_sz']=$arr_z[0];
		$arr_sz['xianzai']=sprintf("%.2f", $arr_z[1]);
		$arr_sz['zhangdie']=sprintf("%.2f", $arr_z[2]);
		$arr_sz['zhangdielv']=$arr_z[3].'%';
		$arr_sz['shuliang']=sprintf("%.2f", $arr_z[4]/100000000).'亿';
		$arr_sz['jine']=sprintf("%.2f", $arr_z[5]/10000).'亿';
		$arr_sz['daima']='399001';
		$arr_sz['id']=1;
		
		foreach($arr_sz as $key=>$value){ 
			$arr_sz[$key]=urlencode($value); 
		}
		return $arr_sz;
	}

	/*$arr_sh_sz=array();
	$arr_sh_sz['sh']=$arr_sh;
	$arr_sh_sz['sz']=$arr_sz;
	
	//返回json字符串
	if($e==0){
		
		$arr_info=array();
		$arr_info['sh_sz']=$arr_sh_sz;
		
		$str_sh_sz=urldecode(json_encode($arr_info, JSON_PRETTY_PRINT));
		return $str_sh_sz;
	}
	if($e==1){
		
		$info_a=array();
		$info_a['sh']=$arr_sh;
		$info_a['sz']=0;

		$arr_info=array();
		$arr_info['sh_sz']=$info_a;
		
		$str_sh=urldecode(json_encode($arr_info, JSON_PRETTY_PRINT));
		
		return $str_sh;
	}
	if($e==2){
		
		$info_a=array();
		$info_a['sh']=0;
		$info_a['sz']=$arr_sz;

		$arr_info=array();
		$arr_info['sh_sz']=$info_a;
		
		$str_sz=urldecode(json_encode($arr_info, JSON_PRETTY_PRINT));
		
		return $str_sz;
	}
	
	//返回数组
	if($e==3){
		return $arr_sh_sz;
	}*/
}
//新浪实时股票
function search_info(){
	$serach_info=$_POST['daima_info'];//股票代码json字符串
	/*if(!empty($serach_info)){
		$_SESSION['daima_info']=$serach_info;
	}
	$serach_info=$_SESSION['daima_info'];*/
	$arr=array();
	$arr=json_decode($serach_info);//股票代码
	//return $arr;
	//$arr=['000001','399001','603369','002646'];
	
	/*if($serach_info==''){
		
		//返回上证指数和深证成指json字符串
		return -1;		
	}
		
	//session记录用户输入不为空的信息
	//$_SESSION['serach_info']=$serach_info;
	//$serach_info=$_SESSION['serach_info'];
	
	//判断用户输入的数字是否为六位数
	if(strlen($serach_info)<6){
		return 1;//——低于六位数不是股票代码，查询失败
	}
	
	if($serach_info=='000001'){
		
		//返回上证指数json字符串
		return sh_sz(1);
	}else if($serach_info=='399001'){
		
		//返回深证成指json字符串
		return sh_sz(2);
	}*/
	$sh_sz=array();
	$url=array();
	$arr_num=array();
	//判断用户输入的股票代码是上证股票还是深证股票
	for($i=0; $i<count($arr); $i++){
		if($arr[$i]=='000001'){
			$sh_sz[]=sh_sz(0);
			//不往下走
			continue;
		}else if($arr[$i]=='399001'){
			$sh_sz[]=sh_sz(1);
			//不往下走
			continue;
		}
		$num=substr($arr[$i], 0, 1);
		if($num==6){
			$url[]='http://hq.sinajs.cn/list=sh'.$arr[$i];
			$arr_num[]=$arr[$i];
		}else{
			$url[]='http://hq.sinajs.cn/list=sz'.$arr[$i];
			$arr_num[]=$arr[$i];
		}
	}
	//return $arr_num;
	
	//获取当前股票代码
	$a=array();
	for($i=0; $i<count($url); $i++){
		$a[]=file_get_contents($url[$i]);
	}
	//return $a_v;
	
	/*if(strlen($a_v)<29){
		return 2;//'——不是有效的股票代码，查询失败';
	}*/
	
	//到此说明查询个股成功
	$str='';
	$b=array();
	$arr_info=array();
	for($i=0; $i<count($a); $i++){
	
		$str=substr($a[$i], strripos($a[$i], "=")+1);
		$b=explode(',', $str);

		$arr_info[$i]['guming']=iconv('gbk', 'utf-8', str_replace('"', '', $b[0]));
		$arr_info[$i]['jinkai']=sprintf("%.2f", $b[1]);
		$arr_info[$i]['zuoshou']=sprintf("%.2f", $b[2]);
		$arr_info[$i]['xianzai']=sprintf("%.2f", $b[3]);
		$arr_info[$i]['zuigao']=sprintf("%.2f", $b[4]);
		$arr_info[$i]['zuidi']=sprintf("%.2f", $b[5]);
		$arr_info[$i]['daima']=$arr_num[$i];
	}
	/*foreach($arr_info as $key=>$value){ 
		$arr_info[$key]=urlencode($value); 
	}*/
	for($i=0; $i<count($arr_info); $i++){
		foreach($arr_info[$i] as $key=>$value){ 
			$arr_info[$i][$key]=urlencode($value); 
		}		
	}
	//return $arr_info; 
	
	$search_res=array();
	
	//返回上证指数、深证成指数组
	$search_res['sh_sz']=$sh_sz;
	
	//个股信息
	$search_res['stock_info']=$arr_info;
	
	$str_info=urldecode(json_encode($search_res, JSON_PRETTY_PRINT));
	
	return $str_info;
	
	/*$a=stock_info($serach_info, 1);
	if($a==0){
		$str_info=urldecode(json_encode($search_res, JSON_PRETTY_PRINT));
		return $str_info;	
	}
	$search_res['stock_info']=$a;*/
}

/*//查询用户输入的信息是否含有汉字
	$p=preg_match("/^[\x7f-\xff]+$/", $serach_info);
	
	if($p==1){
		
		//返回的是数组，数字0
		$arr_info=stock_info($serach_info, 0);
		//return $arr_info;
		
		if($arr_info==0){
			return $arr_info;//查询的股票不存在
		}
		
		return $arr_info;
	}*/