<?php

header("Content-Type: text/html;charset=utf-8");

//encrypt加密解密算法
//加密解密的过程均需要用到一个加密密钥(即参数$key)
$data = 'PHP加密解密算法';//被加密信息
$key = '123';//密钥
$encrypt = encrypt($data, $key);
$decrypt = decrypt($encrypt, $key);
echo $encrypt.'<br>'.$decrypt;
exit;

//加密算法
function encrypt($data, $key)
{
    $key    =    md5($key);
    $x        =    0;
    $len    =    strlen($data);
    $l        =    strlen($key);
    for ($i = 0; $i < $len; $i++)
    {
        if ($x == $l) 
        {
            $x = 0;
        }
        $char .= $key{$x};
        $x++;
    }
    for ($i = 0; $i < $len; $i++)
    {
        $str .= chr(ord($data{$i}) + (ord($char{$i})) % 256);
    }
    return base64_encode($str);
}
//解密算法
function decrypt($data, $key)
{
    $key = md5($key);
    $x = 0;
    $data = base64_decode($data);
    $len = strlen($data);
    $l = strlen($key);
    for ($i = 0; $i < $len; $i++)
    {
        if ($x == $l) 
        {
            $x = 0;
        }
        $char .= substr($key, $x, 1);
        $x++;
    }
    for ($i = 0; $i < $len; $i++)
    {
        if (ord(substr($data, $i, 1)) < ord(substr($char, $i, 1)))
        {
            $str .= chr((ord(substr($data, $i, 1)) + 256) - ord(substr($char, $i, 1)));
        }
        else
        {
            $str .= chr(ord(substr($data, $i, 1)) - ord(substr($char, $i, 1)));
        }
    }
    return $str;
}

//session_start();
//require '../SqliHelper.class.php';

//echo '<pre>';
print_r(search_info());
//echo '</pre>';

//上证指数、深证成指
function sh_sz(){
	
	$url_1='http://hq.sinajs.cn/list=s_sh000001';
	$url_2='http://hq.sinajs.cn/list=s_sz399001';	
	
	$res_sh=file_get_contents($url_1);
	$res_sh=iconv('gbk', 'utf-8', $res_sh);
	$res_sh=str_replace('"', '', $res_sh);
	$res_sh=trim(str_replace(';', '', $res_sh));
	$res_sh=substr($res_sh, strripos($res_sh, "=")+1);
	
	$arr_h=array();
	$arr_h=explode(',', $res_sh);
	
	$arr_sh=array();
	$arr_sh['sh']=$arr_h[0];
	$arr_sh['xianzai']=sprintf("%.2f", $arr_h[1]);
	$arr_sh['zhangdie']=sprintf("%.2f", $arr_h[2]);
	$arr_sh['zhangdielv']=$arr_h[3].'%';
	$arr_sh['shuliang']=sprintf("%.2f", $arr_h[4]/1000000).'亿';
	$arr_sh['jine']=sprintf("%.2f", $arr_h[5]/10000).'亿';
	
	foreach($arr_sh as $key=>$value){ 
		$arr_sh[$key]=urlencode($value); 
	}
	
	$res_sz=file_get_contents($url_2);
	$res_sz=iconv('gbk', 'utf-8', $res_sz);
	$res_sz=str_replace('"', '', $res_sz);
	$res_sz=trim(str_replace(';', '', $res_sz));
	$res_sz=substr($res_sz, strripos($res_sz, "=")+1);
	
	$arr_z=array();
	$arr_z=explode(',', $res_sz);
	
	$arr_sz=array();
	$arr_sz['sz']=$arr_z[0];
	$arr_sz['xianzai']=sprintf("%.2f", $arr_z[1]);
	$arr_sz['zhangdie']=sprintf("%.2f", $arr_z[2]);
	$arr_sz['zhangdielv']=$arr_z[3].'%';
	$arr_sz['shuliang']=sprintf("%.2f", $arr_z[4]/100000000).'亿';
	$arr_sz['jine']=sprintf("%.2f", $arr_z[5]/10000).'亿';
	
	foreach($arr_sz as $key=>$value){ 
		$arr_sz[$key]=urlencode($value); 
	}

	$arr_sh_sz=array();
	$arr_sh_sz['sh']=$arr_sh;
	$arr_sh_sz['sz']=$arr_sz;
	
	//返回json字符串
	/*if($e==0){
		
		$arr_info=array();
		$arr_info['sh_sz']=$arr_sh_sz;
		
		$str_sh_sz=urldecode(json_encode($arr_info, JSON_PRETTY_PRINT));
		return $str_sh_sz;
	}
	if($e==1){
		
		$info_a=array();
		$info_a['sh']=$arr_sh;
		$info_a['sz']=0;

		$arr_info=array();
		$arr_info['sh_sz']=$info_a;
		
		$str_sh=urldecode(json_encode($arr_info, JSON_PRETTY_PRINT));
		
		return $str_sh;
	}
	if($e==2){
		
		$info_a=array();
		$info_a['sh']=0;
		$info_a['sz']=$arr_sz;

		$arr_info=array();
		$arr_info['sh_sz']=$info_a;
		
		$str_sz=urldecode(json_encode($arr_info, JSON_PRETTY_PRINT));
		
		return $str_sz;
	}*/
	
	//返回数组
	return $arr_sh_sz;
}
//新浪实时股票
function search_info(){
	
	$serach_info=$_POST['search_info'];//股票代码
	//$serach_info='000001';
	
	if($serach_info==''){
		
		//为空则返回-1
		return -1;		
	}
		
	//session记录用户输入不为空的信息
	//$_SESSION['serach_info']=$serach_info;
	//$serach_info=$_SESSION['serach_info'];
	
	//判断用户输入的数字是否为六位数
	if(strlen($serach_info)<6){
		return 1;//——低于六位数不是股票代码，查询失败
	}
	
	//查询用户输入的信息是否都是汉字
	//$p=preg_match("/^[\x7f-\xff]+$/", $serach_info);
	
	//查询用户输入的信息是否含有汉字
	//$p=preg_match('/[\x{4e00}-\x{9fa5}]/u', $serach_info);
	$p=preg_match("/[\x7f-\xff]/", $serach_info);
	//$e=eregi("[^\x80-\xff]", $serach_info);
	if($p>0){
		
		//返回的是数组，数字0
		/*$arr_info=stock_info($serach_info, 0);
		//return $arr_info;
		
		if($arr_info==0){
			return $arr_info;//查询的股票不存在
		}*/
		
		return 3;//不支持股票名称查询
	}

	if($serach_info=='399001'){
		return 4;//不支持深证指数查询
	}

	//判断用户输入的股票代码是上证股票还是深证股票
	$num=substr($serach_info, 0, 1);
	if($num==6){
		$url='http://hq.sinajs.cn/list=sh'.$serach_info;
	}else{
		$url='http://hq.sinajs.cn/list=sz'.$serach_info;	
	}

	$a_v=file_get_contents($url);
	if(strlen($a_v)<39){
		return 2;//'——不是有效的股票代码，查询失败';
	}
	
	//到此说明查询个股成功
	$a_v=substr($a_v, strripos($a_v,"=")+1);
	$a_v=explode(',', $a_v);

	$arr=array();
	$arr['guming']=iconv('gbk', 'utf-8', str_replace('"', '', $a_v[0]));
	$arr['jinkai']=sprintf("%.2f", $a_v[1]);
	$arr['zuoshou']=sprintf("%.2f", $a_v[2]);
	$arr['xianzai']=sprintf("%.2f", $a_v[3]);
	$arr['zuigao']=sprintf("%.2f", $a_v[4]);
	$arr['zuidi']=sprintf("%.2f", $a_v[5]);
	$arr['jingaiyi']=sprintf("%.2f", $a_v[6]);
	$arr['jingmaiyi']=sprintf("%.2f", $a_v[7]);
	$arr['shuliang']=round($a_v[8]/100);
	if($a_v[9]>99999999){
		$arr['jine']=sprintf("%.2f", $a_v[9]/100000000).'亿';
	}else{
		$arr['jine']=sprintf("%.1f", $a_v[9]/10000).'万';	
	}

	$arr['ai_1shuliang']=round($a_v[10]/100);
	$arr['ai_1jine']=sprintf("%.2f", $a_v[11]);
	$arr['ai_2shuliang']=round($a_v[12]/100);
	$arr['ai_2jine']=sprintf("%.2f", $a_v[13]);
	$arr['ai_3shuliang']=round($a_v[14]/100);
	$arr['ai_3jine']=sprintf("%.2f", $a_v[15]);
	$arr['ai_4shuliang']=round($a_v[16]/100);
	$arr['ai_4jine']=sprintf("%.2f", $a_v[17]);
	$arr['ai_5shuliang']=round($a_v[18]/100);
	$arr['ai_5jine']=sprintf("%.2f", $a_v[19]);

	$arr['mai_1shuliang']=round($a_v[20]/100);
	$arr['mai_1jine']=sprintf("%.2f", $a_v[21]);
	$arr['mai_2shuliang']=round($a_v[22]/100);
	$arr['mai_2jine']=sprintf("%.2f", $a_v[23]);
	$arr['mai_3shuliang']=round($a_v[24]/100);
	$arr['mai_3jine']=sprintf("%.2f", $a_v[25]);
	$arr['mai_4shuliang']=round($a_v[26]/100);
	$arr['mai_4jine']=sprintf("%.2f", $a_v[27]);
	$arr['mai_5shuliang']=round($a_v[28]/100);
	$arr['mai_5jine']=sprintf("%.2f", $a_v[29]);

	$arr['riqi']=$a_v[30];
	$arr['shijian']=$a_v[31];
	
	foreach($arr as $key=>$value){ 
		$arr[$key]=urlencode($value); 
	}
	
	$search_res=array();
	
	//返回上证指数、深证成指数组
	$search_res['sh_sz']=sh_sz();
	
	//新浪实时股票信息
	$search_res['search_info']=$arr;

	//$search_res['daimai']=$serach_info;

	$str_info=urldecode(json_encode($search_res, JSON_PRETTY_PRINT));
	
	return $str_info;
	
	/*$a=stock_info($serach_info, 1);
	if($a==0){
		$str_info=urldecode(json_encode($search_res, JSON_PRETTY_PRINT));
		return $str_info;	
	}
	$search_res['stock_info']=$a;*/
}

/*$mingzi=$stock_info['mingzi'];
	$daima=$stock_info['daima'];
	$shiyinglv=$stock_info['shiyinglv'];
	$meigushouyi=$stock_info['meigushouyi'];
	$liutongguben=$stock_info['liutongguben'];
	$zongguben=$stock_info['zongguben'];
	$junxian1=$stock_info['junxian1'];
	$junxian2=$stock_info['junxian2'];
	$junxian3=$stock_info['junxian3'];
	$lingyu=$stock_info['lingyu'];*/
//echo $daima.$mingzi.'的市盈率：'.($shiyinglv+2);

//本地股票
/*function stock_info($serach_info, $e){
	
	$sqli_helper=new SqliHelper();
	$sql="select * from stock where mingzi='$serach_info'";
	//return $serach_info;
	
	$stock_info=array();
	$stock_info=$sqli_helper->execute_dql2($sql);
	
	if(empty($stock_info)){
		return 0;//股票不存在
	}
	
	foreach($stock_info[0] as $key=>$value){ 
		$stock_info[0][$key]=urlencode($value); 
	}
	
	$arr_info=array();
	$arr_info['sh_sz']=sh_sz(3);
	$arr_info['stock']=$stock_info[0];
	
	//返回json字符串
	if($e==0){
		
		$str_info=urldecode(json_encode($arr_info, JSON_PRETTY_PRINT));
		
		return $str_info;
	}
	
	//返回数组
	if($e==1){
		return $arr_info;
	}
}*/