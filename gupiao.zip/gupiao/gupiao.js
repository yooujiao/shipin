var url_pc='./gupiao_pc.css';
var url_phone='./gupiao_phone.css';
window.onload=function(){
	wangye(url_pc, url_phone);

	//获取当前时间
	//get_time();

	//获取网页元素
	get_ele();
	
	//获取浏览器上存的表单数据
	get_input_data();

	//检查表单数据
	//check_input();

	//取股票数据和自选股票数据
	start_num(1);
	
	//显示股票
	//hide_show_now_stock();
	
	//显示自选股
	show_hide_optional_stock();
	
	event();
}

var storage=window.localStorage;
var div_stock_k='';
var optional_stock_k='';
var p_k='';
var err_info_k='';
//var stock_info_k='';
var all_stock_info_k='';
var optional_stock_num_k='';
var stock_num_k='';
var input_a='';
//var optional_stock_b='';
//var now_stock_b='';

//获取网页元素
function get_ele(){
	
	//股票框架
	div_stock_k=document.getElementById('div_stock');

	//自选股框架
	optional_stock_k=document.getElementById('show_optional_stock');
	
	p_k=document.getElementById('p_i');
	err_info_k=document.getElementById('error_info');
	
	//停止更新自选股提示
	all_stock_info_k=document.getElementById('all_stock_info_k');
	
	//停止更新股票指数和股票提示
	//stock_info_k=document.getElementById('stock_info_k');
	
	//记录自选股更新次数
	optional_stock_num_k=document.getElementById('optional_stock_num_k');
	
	//记录股票指数和股票更新次数
	stock_num_k=document.getElementById('stock_num_k');
	
	//表单对象
	input_a=document.getElementById('input_i');
	
	//optional_stock_b=document.getElementById('optional_stock_b');
	//now_stock_b=document.getElementById('now_stock_b');
}

//点击事件
function event(){

	addEventHandler(get_obj('input_i'), 'input', check_input);
	
	//单击查询股票
	addEventHandler(get_obj('search_stock_a'), 'click', function(){
		start_num();
	});
	
	//股票指数
	addEventHandler(get_obj('zhishu_a'), 'click', hide_show_table);
	
	/*//关闭上证指数
	addEventHandler(get_obj('close_sh_a'), 'click', function(){
		hide_sh_sz(0);
	});
	//关闭深证成指
	addEventHandler(get_obj('close_sz_a'), 'click', function(){
		hide_sh_sz(1);
	});*/
	
	//自选股票
	addEventHandler(get_obj('optional_stock_a'), 'click', show_hide_optional_stock);
	
	//股票
	addEventHandler(get_obj('now_stock_a'), 'click', hide_show_now_stock);
	//关闭股票
	addEventHandler(get_obj('close_stock_a'), 'click', hide_show_now_stock);
	
	//暂停
	addEventHandler(get_obj('stop_a'), 'click', function(){
		stop_num(2);
	});
	
	//刷新页面
	//addEventHandler(get_obj('reload_page_a'), 'click', reload_page);
}
function addEventHandler(target,type,fn){
	if(target.addEventListener){
		target.addEventListener(type,fn);
	}else{
		target.attachEvent("on"+type,fn);
	}
}

//刷新页面
/*function reload_page(){
	window.location.href=window.location.href; 
	window.location.reload;
}*/

//按回车键执行代码
function abc(e){
	
	if(e.keyCode==13)
    {
		//获取股票数据和自选股票数据
		start_num();
		return false;                               
    }
}

//保存input数据到浏览器上
function save_input_data(){
	var a=document.getElementById('input_i');
	if(a.value.length<6){
		return false;
	}
	//保存用户输入的数据
	storage['input_data']=a.value;
}

//从浏览器上获取input数据
function get_input_data(){
	var b=storage['input_data'];
	var a=document.getElementById('input_i');
	if(b){
		a.value=b;		
	}
}

var flag_input=0;
//检查表单输入
function check_input(){
	//p_k.style.display='block';
	
	if(input_a.value.length<6 || input_a.value=='399001'){
		
		//不合法提示
		err_info_k.innerHTML='股票代码不合法';
		err_info_k.style.color='red';
		
		//不合法标志
		flag_input=1;
		
		return false;
	}
	
	//合法提示
	err_info_k.innerHTML='股票代码合法';
	err_info_k.style.color='green';
	
	//合法标志
	flag_input=0;
}
/*function hide_stock_k(){
	//隐藏当前网页正在显示的数据
	//get_obj('table_sh').style.display='none';
	//get_obj('div_sh_sz').style.display='none';
	//get_obj('div_stock').style.display='none';
	//get_obj('now_time').style.display='none';
}*/

var flag_research=0;
function start_num(num){
	//var a=document.getElementById('stop_a');
	
	//如果是重复查询
	if(input_a.value==storage['input_data']){
		
		//记录重复查询的次数
		flag_research++;
		
		//如果是重复查询就清除延时器
		window.clearTimeout(time_stock);
	
	}else{
		
		//第一次查询标志
		flag_research=0;	
	}
	
	//如果重复查询超过3次
	if(flag_research>3){
		
		alert(input_a.value+'——查询已超过3次，请换只股票查询');
		
		//给出停止更新股票数据提示隐藏暂停按钮
		stop_num(0);
		
		return false;
	}
	
	//取数据之前对延时器放行
	flag_stop=0;
	
	//开始取股票指数和股票数据
	get_stock_info(input_a.value, 0);
			
	//开始取自选股票数据
	//get_info();

	//如果查询成功
	if(flag_fail==2){
		
		//如果不是系统调用就显示股票框架
		if(num!=1){
			get_obj('div_stock').style.display='block';
		}
		
		//隐藏停止更新数据提示显示暂停按钮
		stop_num(1);
		
		//数据获取成功就清除自选股票的颜色
		flag_color=0;
		
		//如果查询成功就重置x和y的值
		x=0;
		y=0;
	}else{
		alert('获取数据失败');
	}
	
	//总结
	//算法最重要的是成功了返回什么
	//失败了返回什么
	//代码封装的越好越有价值
	//ajax的同步比异步靠谱
}

//停止更新股票
var flag_stop=0;
function stop_num(id){
	
	var a=document.getElementById('stop_a');
	
	if(id==0){
		
		//暂停延时器
		flag_stop=1;
		
		//隐藏暂停按钮
		a.style.display='none';

		//给出停止更新股票数据提示
		all_stock_info_k.style.display='block';
		all_stock_info_k.innerHTML='已停止更新所有股票数据';
		
		//失败返回1
		flag_fail=1;
		
		return false;
	}
	
	if(id==1){
		
		//启动延时器
		//flag_stop=0;
		
		//显示暂停按钮
		a.style.display='inline';
		a.innerHTML='暂停';
		a.style.color='red';
		
		//隐藏停止更新数据提示
		all_stock_info_k.style.display='none';
		
		return false;
	}
	
	/*if(id==3 && flag_stop==1){
		
		//对延时器放行
		flag_stop=0;
		
		//开始取自选股票数据
		get_info();
		
		if(flag_id){
			//数据重新更新就隐藏提示
			all_stock_info_k.style.display='none';
			a.innerHTML='暂停';
			a.style.color='red';
		}
	}*/
	
	if(id==2){	
		if(flag_stop==1){
			
			//对延时器放行
			flag_stop=0;
			
			//开始取股票指数和股票数据
			if(flag_id.length==6){
				
				//flag_id是当前查询的股票代码
				get_stock_info(flag_id, 0);
					
				//开始取自选股票数据
				get_info();
			}else{
				alert('股票代码非法');
				return false;
			}

			//数据重新更新就隐藏提示
			all_stock_info_k.style.display='none';
			a.innerHTML='暂停';
			a.style.color='red';
		
		}else{
		
			//暂停延时器
			flag_stop=1;

			//给出停止更新股票数据提示
			all_stock_info_k.style.display='block';
			all_stock_info_k.innerHTML='已停止更新所有股票数据';
			
			a.innerHTML='继续';
			a.style.color='green';
		}
	}
}

//点击自选股调用xyz函数
var flag_color=0;
var xyz_num=0;
function xyz(id, num){
	//id:股票代码
	//num:股票序号
	
	//如果是上证指数或是深证指数
	if(id=='000001' || id=='399001'){
		alert('不支持指数查询');
		return false;	
	}
	
	//如果是重复查询
	if(id==storage['input_data']){
		//记录重复查询的次数
		xyz_num++;
	}else{
		//如果是第一次查询
		xyz_num=0;	
	}
	
	//如果重复查询超过2次
	if(xyz_num>2){
		alert('重复查询次数太多，请换只股票查询');
		return false;
	}	
	
	//如果是个股就开始获取数据
	if(num>0){
		
		//记录股票代码序号
		flag_color=num;
		
		//清除延时器
		window.clearTimeout(time_stock);
		window.clearTimeout(time_optional_stock);
		
		flag_input=0;//放行
		flag_stop=0;//放行

		//input框内填入当前股票代码
		input_a.value=id;
		
		//开始取股票数据
		get_stock_info(input_a.value, 1);
		get_info();
		
		//调用函数结束后如果获取数据成功
		if(flag_fail==2){
			
			//改变股票按钮颜色
			var b=document.getElementById('now_stock_a');//按钮
			b.style.color='#cc99cc';
			
			//显示股票框架
			get_obj('div_stock').style.display='block';
		}
	
	}
}

var flag_fail=0;
var flag_id='';
var xml_v='';
//从服务器取数据到股票行情框架
function get_stock_info(id, num){
	
	//有input删除操作时不允许向服务器取数据
	if(flag_input==1){
		
		//给出停止更新股票数据提示隐藏暂停按钮
		stop_num(0);
		
		return false;
	}
	
	if(flag_stop==1){
		
		//执行了停止动作就不往下走
		return false;
	}
	
	//开始发送ajax请求
	xml_v=getXmlHttpObject();
	
	if(!xml_v){
		alert("ajax对象创建失败");
	}
	//创建ajax引擎成功，开始从服务器取数据
	
	var url='./gupiao2.php';
	var data='search_info='+id;
	
	xml_v.open("post", url, false);
	xml_v.setRequestHeader("Content-type","application/x-www-form-urlencoded");

	//调用回调函数之前
	flag_fail=0;
	
	//指定回调函数
	xml_v.onreadystatechange=chuli;

	//发送
	xml_v.send(data);
	
	
	
	flag_id='';
	//如果获取数据成功
	if(flag_fail==2){
		
		//保存表单股票代码
		save_input_data();
		
		//记录股票代码参数id
		flag_id=id;
		
		//隐藏停止更新提示显示暂停按钮
		stop_num(1);
	}
	//给出停止更新提示隐藏暂停按钮
	//stop_num(0);
	//alert('查询出错——'+id);
}

var x=0;
var time_stock=0;
//回调函数
function chuli(){
	if(xml_v.readyState!=4){
		err_info_k.innerHTML='连接服务器失败';
		err_info_k.style.color='red';
		
		//失败返回1
		//flag_fail=1;

		//给出停止更新提示隐藏暂停按钮
		stop_num(0);
		
		return false;	
	}
	if(xml_v.status!=200){
				
		err_info_k.innerHTML='获取服务器数据失败';
		err_info_k.style.color='red';
		
		//失败返回1
		//flag_fail=1;

		//给出停止更新提示隐藏暂停按钮
		stop_num(0);
		
		return false;	
	}
				
	//取出并转成对象数组
	//res=eval("("+myXmlHttpRequest.responseText+")");
	var res=JSON.parse(xml_v.responseText);//json字符串转数组
	//var res=xml_v.responseText;
	
	var flag=0;
	switch(res){
					
		case -1:
		err_info_k.innerHTML='输入不能为空，查询失败';
		err_info_k.style.color='red';
		flag=1;
		break;
					
		case 0:
		err_info_k.innerHTML='查询的股票不存在，查询失败';
		err_info_k.style.color='red';
		flag=1;
		break;
					
		case 1:
		err_info_k.innerHTML='不是股票代码，查询失败';
		err_info_k.style.color='red';
		flag=1;
		break;
					
		case 2:
		err_info_k.innerHTML='不是有效的股票代码，查询失败';
		err_info_k.style.color='red';
		flag=1;
		break;

		case 3:
		err_info_k.innerHTML='不支持股票名称查询，查询失败';
		err_info_k.style.color='red';
		flag=1;
		break;

		case 4:
		err_info_k.innerHTML='不支持深证指数查询，查询失败';
		err_info_k.style.color='red';
		flag=1;
		break;
					
		default:
		err_info_k.innerHTML='股票代码合法，查询成功';
		err_info_k.style.color='green';

		//查询成功
		//flag=2;
	}
				
	//查询失败就不往下走
	if(flag==1){
		
		//失败返回1
		//flag_fail=1;
		
		//给出停止更新提示隐藏暂停按钮
		stop_num(0);
		
		return false;
	}
	/*查询成功就往下走*/
	
	//如果获取上证指数数据成功就插入上证指数数据到网页框架
	if(res.sh_sz.sh){
				
		//有数据就往下走
		var sh=get_obj('sh'),
		xianzai_sh=get_obj('xianzai_sh'),
		zhangdie_sh=get_obj('zhangdie_sh'),
		zhangdielv_sh=get_obj('zhangdielv_sh'),
		shuliang_sh=get_obj('shuliang_sh'),
		jine_sh=get_obj('jine_sh');
						
		if(res.sh_sz.sh.zhangdie>0){
			xianzai_sh.style.color='red';
			zhangdie_sh.style.color='red';
			zhangdielv_sh.style.color='red';
		}else if(res.sh_sz.sh.zhangdie<0){
			xianzai_sh.style.color='green';
			zhangdie_sh.style.color='green';
			zhangdielv_sh.style.color='green';
		}
						
		sh.innerHTML=res.sh_sz.sh.sh;
		xianzai_sh.innerHTML=res.sh_sz.sh.xianzai;
		zhangdie_sh.innerHTML=res.sh_sz.sh.zhangdie;
		zhangdielv_sh.innerHTML=res.sh_sz.sh.zhangdielv;
		shuliang_sh.innerHTML=res.sh_sz.sh.shuliang;
		jine_sh.innerHTML=res.sh_sz.sh.jine;
		
		//插入数据到框架不显示框架
		
		//如果本地没有上证指数就添加保存上证指数
		if(!storage['上证指数']){
			save_optional_stock(0, 0);
		}

		//判断上证指数在浏览器上是否存在
		save_optional_stock(0, 1);
	}
			
	//如果获取深证指数数据成功就插入深证指数数据到网页框架
	if(res.sh_sz.sz){
					
		//有数据就往下走
		var sz=get_obj('sz'),
		xianzai_sz=get_obj('xianzai_sz'),
		zhangdie_sz=get_obj('zhangdie_sz'),
		zhangdielv_sz=get_obj('zhangdielv_sz'),
		shuliang_sz=get_obj('shuliang_sz'),
		jine_sz=get_obj('jine_sz');
				
		if(res.sh_sz.sz.zhangdie>0){
			xianzai_sz.style.color='red';
			zhangdie_sz.style.color='red';
			zhangdielv_sz.style.color='red';
		}else if(res.sh_sz.sz.zhangdie<0){
			xianzai_sz.style.color='green';
			zhangdie_sz.style.color='green';
			zhangdielv_sz.style.color='green';
		}
					
		sz.innerHTML=res.sh_sz.sz.sz;
		xianzai_sz.innerHTML=res.sh_sz.sz.xianzai;
		zhangdie_sz.innerHTML=res.sh_sz.sz.zhangdie;
		zhangdielv_sz.innerHTML=res.sh_sz.sz.zhangdielv;
		shuliang_sz.innerHTML=res.sh_sz.sz.shuliang;
		jine_sz.innerHTML=res.sh_sz.sz.jine;
		
		//判断深证指数在本地浏览器上是否存在
		save_optional_stock(1, 1);
	}
	
	//实时股票信息
	if(!res.search_info){
		//没有数据就不往下走
		alert('股票数据获取失败');
		return false;
	}
	
	//取到数据就往下走
	//开始往框架插入数据
	var guming=get_obj('guming'),
	jinkai=get_obj('jinkai'),
	zuoshou=get_obj('zuoshou'),
	xianzai=get_obj('xianzai'),
	zuigao=get_obj('zuigao'),
	zuidi=get_obj('zuidi'),
	shuliang=get_obj('shuliang'),
	jine=get_obj('jine');

	var mai_5jine=get_obj('mai_5jine'),
	mai_5shuliang=get_obj('mai_5shuliang'),
	mai_4jine=get_obj('mai_4jine'),
	mai_4shuliang=get_obj('mai_4shuliang'),
	mai_3jine=get_obj('mai_3jine'),
	mai_3shuliang=get_obj('mai_3shuliang'),
	mai_2jine=get_obj('mai_2jine'),
	mai_2shuliang=get_obj('mai_2shuliang'),
	mai_1jine=get_obj('mai_1jine'),
	mai_1shuliang=get_obj('mai_1shuliang');

	var ai_1jine=get_obj('ai_1jine'),
	ai_1shuliang=get_obj('ai_1shuliang'),
	ai_2jine=get_obj('ai_2jine'),
	ai_2shuliang=get_obj('ai_2shuliang'),
	ai_3jine=get_obj('ai_3jine'),
	ai_3shuliang=get_obj('ai_3shuliang'),
	ai_4jine=get_obj('ai_4jine'),
	ai_4shuliang=get_obj('ai_4shuliang'),
	ai_5jine=get_obj('ai_5jine'),
	ai_5shuliang=get_obj('ai_5shuliang');
				
	var a=res.search_info.jinkai;//今开
	var b=res.search_info.zuoshou;//昨收
	var c=res.search_info.xianzai;//现在
	//var d=res.search_info.zuigao;//最高
	//var e=res.search_info.zuidi;//最低
	
	var now_price=parseFloat(c);//最新价格
	var yesterday_price=parseFloat(b);//昨收
	//得到涨跌
	var zhangdie_z=now_price-yesterday_price;
	zhangdie_z=zhangdie_z.toFixed(2);
	//得到涨幅
	var zhangfu_z=zhangdie_z/yesterday_price*100;
	zhangfu_z=zhangfu_z.toFixed(2);
	
	var zhangdie=get_obj('zhangdie');
	var zhangfu=get_obj('zhangfu');
	if(zhangdie_z>0){
		zhangdie.style.color='red';						
	}else{
		zhangdie.style.color='green';
	}
	
	if(zhangfu_z>0){
		zhangfu.style.color='red';						
	}else{
		zhangfu.style.color='green';
	}
	//涨跌
	zhangdie.innerHTML=zhangdie_z;
	//涨幅
	zhangfu.innerHTML=zhangfu_z+'%';
					
	if(a>b){
		jinkai.style.color='red';	
	}else if(a<b){
		jinkai.style.color='green';
	}
					
	if(c>b){
		xianzai.style.color='red';	
	}else if(c<b){
		xianzai.style.color='green';	
	}

	zuigao.style.color='red';//最高
	zuidi.style.color='green';//最低

	//股票名字
	guming.innerHTML=res.search_info.guming;
					
	//昨天收盘价
	zuoshou.innerHTML=res.search_info.zuoshou;
				
	//今天开盘价
	jinkai.innerHTML=res.search_info.jinkai;
					
	//现在股价
	xianzai.innerHTML=res.search_info.xianzai;
					
	//最高价
	zuigao.innerHTML=res.search_info.zuigao;
					
	//最低价
	zuidi.innerHTML=res.search_info.zuidi;
		
	//成交数量
	shuliang.innerHTML=res.search_info.shuliang;
					
	//成交金额
	jine.innerHTML=res.search_info.jine;
				
	//卖5金额数量
	mai_5jine.innerHTML=res.search_info.mai_5jine;
	mai_5shuliang.innerHTML=res.search_info.mai_5shuliang;
					
	//卖4金额数量
	mai_4jine.innerHTML=res.search_info.mai_4jine;
	mai_4shuliang.innerHTML=res.search_info.mai_4shuliang;
					
	//卖3金额数量
	mai_3jine.innerHTML=res.search_info.mai_3jine;
	mai_3shuliang.innerHTML=res.search_info.mai_3shuliang;
					
	//卖2金额数量
	mai_2jine.innerHTML=res.search_info.mai_2jine;
	mai_2shuliang.innerHTML=res.search_info.mai_2shuliang;
					
	//卖1金额数量
	mai_1jine.innerHTML=res.search_info.mai_1jine;
	mai_1shuliang.innerHTML=res.search_info.mai_1shuliang;
				
	//买1金额数量
	ai_1jine.innerHTML=res.search_info.ai_1jine;
	ai_1shuliang.innerHTML=res.search_info.ai_1shuliang;

	//买2金额数量
	ai_2jine.innerHTML=res.search_info.ai_2jine;
	ai_2shuliang.innerHTML=res.search_info.ai_2shuliang;

	//买3金额数量
	ai_3jine.innerHTML=res.search_info.ai_3jine;
	ai_3shuliang.innerHTML=res.search_info.ai_3shuliang;

	//买4金额数量
	ai_4jine.innerHTML=res.search_info.ai_4jine;
	ai_4shuliang.innerHTML=res.search_info.ai_4shuliang;

	//买5金额数量
	ai_5jine.innerHTML=res.search_info.ai_5jine;
	ai_5shuliang.innerHTML=res.search_info.ai_5shuliang;
	//数据插入成功不显示股票框架

	//取颜色
	var td_jine=document.getElementsByClassName('jine');
	var b=res.search_info.zuoshou;//昨收
	var num=0;
	for(var i=0; i<td_jine.length; i++){
		num=parseFloat(td_jine[i].innerHTML);
		if(num>b){
			td_jine[i].style.color='red';	
		}else if(num<b){
			td_jine[i].style.color='green';	
		}else{
			td_jine[i].style.color='black';	
		}			
	}
	
	//判断框架中显示的股票是否已关注
	save_optional_stock(2, 1);

	//如果数据更新超过9次
	if(x>9){
		x=0;
	}
	
	//记录更新股票指数、股票的次数
	stock_num_k.innerHTML=x;

	//统计获取数据成功的次数
	x++;

	//获取数据成功的标志
	flag_fail=2;
	
	//更新自选股票数据
	get_info();

	//重复从服务器获取数据
	time_stock=window.setTimeout("get_stock_info(flag_id, 0)", 1000);
	//清除延时器(函数执行完成延时器停止)
	//window.clearTimeout(time);
	
	//该函数功能：取数据->插入数据->做数据插入成功的标志
}

//隐藏、显示股票框架
function hide_show_now_stock(){
	var a=document.getElementById('div_stock');//框架
	var b=document.getElementById('now_stock_a');//按钮
	
	if(a.style.display=='none'){
		//显示股票框架
		a.style.display='block';
		b.style.color='#cc99cc';
	}else{
		//隐藏股票框架
		a.style.display='none';
		b.style.color='black';
	}
}
//显示、隐藏股票指数框架
function hide_show_table(){
	var a=document.getElementById('div_sh_sz');//框架
	var b=document.getElementById('zhishu_a');//按钮
	if(a.style.display=='none'){
		a.style.display='block';
		b.style.color='#cc99cc';
	}else{
		a.style.display='none';
		b.style.color='black';
	}
}
/*关闭上证、深证指数*/
/*function hide_sh_sz(num){
	var sh=document.getElementById('table_sh');//框架
	var sz=document.getElementById('table_sz');//框架
	var a=document.getElementById('div_sh_sz');//框架
	var b=document.getElementById('zhishu_a');//按钮
	
	if(num==0){
		sh.style.display='none';
	}
	if(num==1){
		sz.style.display='none';
	}
	if(sh.style.display=='none' && sz.style.display=='none'){
		a.style.display='none';
		b.style.color='black';
	}
}*/
//显示、隐藏自选股票框架
function show_hide_optional_stock(){
	var a=document.getElementById('show_optional_stock');//框架
	var b=document.getElementById('optional_stock_a');//按钮
	
	if(a.style.display=='none'){
		//显示自选股票框架
		a.style.display='table';
		b.style.color='#cc99cc';
	}else{
		//隐藏自选股票框架
		a.style.display='none';
		b.style.color='black';
	}
}
//显示、隐藏编辑股票框架
function show_hide_set_stock(){
	var a=document.getElementById('set_optional_stock');//框架
	if(a.style.display=='none'){
		//取数据插入数据到框架
		set_optional_stock();
		//显示框架
		a.style.display='block';
	}else{
		a.style.display='none';
	}
}
//检查用户的输入
/*function check_data(){
	
	var a=document.getElementById('input_i');
	
	//只能输入数字
	a.value=a.value.replace(/\D/g, ''); //onafterpaste="this.value=this.value.replace(/\D/g,'')";
	
	//只能输入中文
	//this.value=this.value.replace(/[^\u4e00-\u9fa5]/g, '');
}*/
/*function check_data_2(){
	
	var a=document.getElementById('input_i');
	//get_obj('input_i').value=a.value.length;
	
	
}*/

/*隐藏关注成功*/
function none(){
	var a=document.getElementById('black');
	a.style.display='none';
}
/*显示关注成功*/
function guanzhu(){
	var a=document.getElementById('black');
	a.style.display='block';
	window.setTimeout('none()', 1000);
}

//添加保存自选股
function save_optional_stock(num_1, num_2){
	//添加上证指数
	if(num_1==0){
		//如果上证指数存在则不往下走
		get_obj('add_sh').innerHTML='关注';
		get_obj('add_sh').style.color='#669999';
		if(storage['上证指数']){
			get_obj('add_sh').innerHTML='已关注';
			get_obj('add_sh').style.color='gray';
			//alert('上证指数已经关注了');
			return false;
		}
		
		//如果参数不为0则不往下走
		if(num_2!=0){
			return false;
		}
		
		//开始插入上证指数数据到本地
		var sh=get_obj('sh').innerHTML,
		xianzai_sh=get_obj('xianzai_sh').innerHTML,
		zhangdie_sh=get_obj('zhangdie_sh').innerHTML,
		zhangdielv_sh=get_obj('zhangdielv_sh').innerHTML;

		var str_1=sh+'->'+xianzai_sh+'->'+zhangdielv_sh
		+'->'+zhangdie_sh+'->'+'000001'+'->'+0;
		storage['上证指数']=str_1;

		//重新取数据插入数据到自选股框架
		get_optional_stock_data();

		//重新取数据插入数据到编辑股票框架
		//set_optional_stock();
	}
	
	//添加深证成指
	if(num_1==1){
		//如果深证成指存在则不往下走
		get_obj('add_sz').innerHTML='关注';
		get_obj('add_sz').style.color='#669999';
		if(storage['深证成指']){
			get_obj('add_sz').innerHTML='已关注';
			get_obj('add_sz').style.color='gray';
			//alert('深证成指已经关注了');
			return false;
		}
		
		//如果参数不为0则不往下走
		if(num_2!=0){
			return false;
		}
		
		//开始插入深证指数数据到本地
		var sz=get_obj('sz').innerHTML,
		xianzai_sz=get_obj('xianzai_sz').innerHTML,
		zhangdie_sz=get_obj('zhangdie_sz').innerHTML,
		zhangdielv_sz=get_obj('zhangdielv_sz').innerHTML;
		
		var str_2=sz+'->'+xianzai_sz+'->'+zhangdielv_sz
		+'->'+zhangdie_sz+'->'+'399001'+'->'+1;
		storage['深证成指']=str_2;

		//重新取数据插入数据到自选股框架
		get_optional_stock_data();

		//重新取数据插入数据到编辑股票框架
		set_optional_stock();

		//显示提示框架
		guanzhu();
	}
	
	//添加个股
	if(num_1==2){
		
		//开始获取浏览器上的数据
		var arr=get_localStorage_data();

		//如果浏览器上没有数据或者关注的股票为0则不往下走
		if(arr.length==0){
			return false;
		}
		
		//如果当前显示的股票存在则不往下走
		var stock_name=get_obj('guming').innerHTML;
		get_obj('add_stock').innerHTML='关注';
		get_obj('add_stock').style.color='#669999';
		for(var i=0; i<arr.length; i++){
			if(stock_name==arr[i][0]){
				get_obj('add_stock').innerHTML='已关注';
				get_obj('add_stock').style.color='gray';
				//alert(stock_name+'已经关注了');
				return false;
			}
		}
		
		//如果参数不为0则不往下走
		if(num_2!=0){
			return false;
		}
		
		//开始插入股票数据到本地
		var now_price=get_obj('xianzai').innerHTML;
		var zuoshou=get_obj('zuoshou').innerHTML;
		
		var a=parseFloat(now_price);
		var b=parseFloat(zuoshou);
		//得到涨跌
		var c=a-b;
		c=c.toFixed(2);
		//得到涨幅
		var d=c/b*100;
		d=d.toFixed(2)+'%';
		
		var daima=storage['input_data'];
		var str_3=stock_name+'->'+now_price+'->'+d
		+'->'+c+'->'+daima+'->'+2;
		storage[stock_name]=str_3;

		//重新取数据插入数据到自选股框架
		get_optional_stock_data();
		//get_info();

		//重新取数据插入数据到编辑股票框架
		set_optional_stock();

		//显示提示框架
		guanzhu();
	}
	
	//文件数据变化了，网页框架数据也要跟着变化
}

//判断字符串是否含有中文
function is_ch(str)
{
	if(escape(str).indexOf('%u')<0)
    {
		//alert('没有中文');
		return 0;
    }
	//alert('包含中文');
	return 1;
}
//获取浏览器localStorage数据
function get_localStorage_data(){
	//下面的数据都源于浏览器localStorage
	var storage=window.localStorage;
	var len=storage.length;
	var arr=new Array();
	if(len==0){
		//alert('浏览器上没有数据，无法为你显示自选股');
		return arr;
	}
	
	//开始获取localStorage数据
	var key=0;
	for(var i=0; i<len; i++){
		key=storage.key(i);
		/*if(key.indexOf("input_data")==0){
			continue;
		}*/
		
		//如果没有中文就中断本次循环
		if(is_ch(key)==0){
			continue;
		}
		
		//将storage数据一条一条的添加到新数组中
		arr.push(storage[key]);
	}
	
	if(arr.length==0){
		//alert('自选股为空');
		return arr;
	}
	
	//字符串转数组，得到二维数组
	var arr_v=new Array();
	for(var j=0,len_v=arr.length; j<len_v; j++){
		//字符串转数组，然后将数组添加到新数组中
		arr_v.push(arr[j].split('->'));		
	}
	
	//对二维数组排序
	arr_v=sort_2(arr_v);
	
	//返回二维数组
	return arr_v;
}

//从文件上取数据到自选股框架
function get_optional_stock_data(){
	//获取localStorage数据
	var arr_v=get_localStorage_data();
	
	var str='';
	str+="<tr><td id='td_my_stock' colspan='4'>我的自选股("+arr_v.length+"只)</td><tr>";
	str+="<tr id='tr_err_k' style='display:none'><td id='td_err_info' colspan='4'></td></tr>";
	str+="<tr>";
	str+="<td class='bold'><span id='set_stock_a' onclick='show_hide_set_stock()'>编辑("+(arr_v.length-1)+")</span></td>";
	str+="<td class='bold'>最新</td>";
	str+="<td class='bold'>涨幅</td>";
	str+="<td class='bold'>涨跌</td>";
	str+="</tr>";
	if(arr_v.length==0){
		//alert('浏览器上没有数据或自选股为空');
		get_obj('show_optional_stock').innerHTML=str;
		return false;
	}
	
	//if(num==0){
		//to_first(arr_v, 1);
	//}
	
	//将二维数组中的数据显示到网页
	var arr_daima=new Array();
	for(var k=0; k<arr_v.length; k++){
		str+="<tr class='xyz' onclick=xyz('"+arr_v[k][4]+"',"+k+")>";
		str+="<td><div class=xyz_"+k+">"
		+arr_v[k][0]+"</div><p class=xyz_"+k+" class='daima'>"
		+arr_v[k][4]+"</p></td>";
		str+="<td class='red_green'>"+arr_v[k][1]+"</td>";
		str+="<td class='red'>"+arr_v[k][2]+"</td>";
		str+="<td class='green'>"+arr_v[k][3]+"</td>";
		//str+="<td>->"+arr_v[k][5]+"</td>";
		str+="</tr>";
			
		//记录股票代码
		arr_daima.push(arr_v[k][4]);
	}
	
	//插入数据到table网页自选股框架
	get_obj('show_optional_stock').innerHTML=str;
	
	var a=document.getElementsByClassName('red');
	var num_1=0;
	for(var i=0; i<a.length; i++){
		num_1=parseFloat(a[i].innerHTML);
		if(num_1>0){
			a[i].style.color='red';	
		}else if(num_1<0){
			a[i].style.color='green';	
		}	
	}

	var b=document.getElementsByClassName('green');
	var c=document.getElementsByClassName('red_green');
	var num_2=0;
	for(var j=0; j<b.length; j++){
		num_2=parseFloat(b[j].innerHTML);
		if(num_2>0){
			b[j].style.color='red';
			c[j].style.color='red';
		}else if(num_2<0){
			b[j].style.color='green';
			c[j].style.color='green';
		}	
	}
	
	//如果用户点击了自选股就给这个自选股加颜色
	if(flag_color>0){
		var obj=document.getElementsByClassName('xyz_'+flag_color);
		for(var z=0; z<obj.length; z++){
			obj[z].style='color:#cc99cc;font-weight:bold';
		}
	}
	
	return arr_daima;

	//说明：此函数只插入数据到框架不显示框架
}
//从文件上取数据到编辑股票框架
function set_optional_stock(){
	
	//获取localStorage数据
	var arr_v=get_localStorage_data();
	
	var str='';
	str+="<tr><td id='close_set_stock_k' colspan='2'><a id='close_set_stock_a' onclick='show_hide_set_stock()'>关闭</a></td></tr>";
	str+="<tr><th colspan='2'>股票编辑("+(arr_v.length-1)+"只)</th></tr>";
	str+="<tr><td><span id='span_change' onclick='change_stock()'>反选</span></td><td></td></tr>";
	//开始插入数据到网页框架
	for(var k=0; k<arr_v.length; k++){
		if(arr_v[k][0]=='上证指数'){
			continue;
		}
		str+="<tr>";
		str+="<td class='show_checkbox'><input class='checkbox' type='checkbox' value='"+arr_v[k][0]+"' onclick='change_stock_2()'></td>";
		str+="<td><p>"+arr_v[k][0]+"</p><p class='a_code'>"+arr_v[k][4]+"</p></td>";
		str+="</tr>";
	}
	str+="<tr><td id='td_del' colspan='2'><span id='del' onclick='del_stock()'>删除(0)</span></td></tr>";
	
	//插入数据到编辑股票框架
	var a=document.getElementById('set_optional_stock');
	a.innerHTML=str;
	
	return true;
}

//反选股票
function change_stock(){
	var a=document.getElementsByClassName('checkbox');
	if(a.length==0){
		alert('没有可选择的股票');
		return false;
	}
	var b=0;
	for(var i=0; i<a.length; i++){
		if(a[i].checked==true){
			a[i].checked=false;
		}else{
			/*if(a[i].value=='上证指数'){
				continue;
			}*/
			a[i].checked=true;
			b++;//获取选中股票的个数
		}
	}
	document.getElementById('del').innerHTML='删除('+b+')';
}
//选择股票
function change_stock_2(){
	var a=document.getElementsByClassName('checkbox');
	var b=0;
	for(var i=0; i<a.length; i++){
		/*if(a[i].value=='上证指数'){
			a[i].checked=false;
			continue;
		}*/
		if(a[i].checked==true){
			b++;//获取选中股票的个数
		}
	}
	document.getElementById('del').innerHTML='删除('+b+')';
}
//删除选择的股票
var arr_del=new Array();
function del_stock(){
	var a=document.getElementsByClassName('checkbox');
	//加入要删除的股票到新数组中
	var arr=new Array();
	for(var i=0; i<a.length; i++){
		if(a[i].checked==true){
			arr.push(a[i].value);
		}
	}
	if(arr.length==0){
		alert('请选择需要删除的股票');
		return false;
	}
	
	//记录要删除的股票
	var str='';
	for(var j=0; j<arr.length; j++){
		if(j==arr.length-1){
			str+=arr[j];
			break;
		}
		str+=arr[j]+'、';
	}
	
	if(!confirm('真的要删除——'+str)){
		return false;	
	}
	
	//开始删除选择的股票
	var storage=window.localStorage;
	for(var k=0; k<arr.length; k++){
		//if(a[k].checked==true){
			storage.removeItem(arr[k]);
		//}
	}
	alert('删除成功——'+str);

	//记录删除成功的股票
	arr_del=arr;
	
	//重新取数据到编辑股票框架
	set_optional_stock();
	
	//记录删除动作
	//optional_del=1;
	
	//重新取数据到自选股框架
	get_optional_stock_data();
	return true;
}

var xml_z='';
//取数据到本地
function get_info(){
	
	//取数据之前先把本地数据插入到自选股框架
	var arr_daima=get_optional_stock_data();
	
	//点了暂停就不往下走
	if(flag_stop==1){
		return false;
	}
	
	//记录股票代码数组的长度
	var len=arr_daima.length;
	
	//如果股票代码为空
	if(len==0){
		alert('获取股票代码失败，无法为你获取最新的股票数据');
		//隐藏暂停按钮
		stop_num(0);
		return false;
	}
	
	//开始发送ajax请求
	xml_z=getXmlHttpObject();
	if(!xml_z){
		alert("ajax对象创建失败");
		//显示停止更新数据提示隐藏暂停按钮
		stop_num(0);
		return false;
	}
	//创建ajax引擎成功
	
	var url='./gupiao3.php';
	var a=JSON.stringify(arr_daima);
	var data='daima_info='+a;
	
	xml_z.open("post",url,true);
	xml_z.setRequestHeader("Content-type","application/x-www-form-urlencoded");

	//发送
	xml_z.send(data);

	//指定回调函数
	xml_z.onreadystatechange=chuli_2;
}
//回调函数
var y=0;
var time_optional_stock=0;
function chuli_2(){
	var td_err_info=get_obj('td_err_info');
	if(xml_z.readyState!=4){
		return false;	
	}
	if(xml_z.status!=200){
		get_obj('tr_err_k').style.display='table-row';
		td_err_info.innerHTML='获取服务器数据失败';
		td_err_info.style.color='red';
		
		//失败返回错误信息
		stop_num(0);

		return false;	
	}
	
	//json字符串转数组
	//var res_z=eval("("+xml_z.responseText+")");
	//var res_z=xml_z.responseText;
	var res_z=JSON.parse(xml_z.responseText);
	
	var s_1='',
	s_2='',
	s_3='',
	s_4='',
	s_5='',
	s_6='';
	var str_1='';
	//更新上证、深证指数
	if(res_z['sh_sz'].length>0){
		for(var j=0; j<res_z['sh_sz'].length; j++){
			s_1=res_z['sh_sz'][j]['sh_sz'];
			s_2=res_z['sh_sz'][j]['xianzai'];
			s_3=res_z['sh_sz'][j]['zhangdielv'];
			s_4=res_z['sh_sz'][j]['zhangdie'];
			s_5=res_z['sh_sz'][j]['daima'];
			s_6=res_z['sh_sz'][j]['id'];
			str_1=s_1+'->'+s_2+'->'+s_3+'->'+s_4+'->'+s_5+'->'+s_6;
			storage[s_1]=str_1;		
		}
	}
	
	var guming='';
	var xianzai='';
	var zuoshou='';
	var daima='';
	var a,b,c,d;
	var str='';
	var flag=0;
	//如果股票数据没有就不往下走
	if(!res_z['stock_info']){
		return false;
	}
	
	//更新个股
	for(var i=0; i<res_z['stock_info'].length; i++){
		guming=res_z['stock_info'][i]['guming'];
		//查询当前股票是不是在被删除的股票之中
		if(arr_del.length>0){
			for(var j=0; j<arr_del.length; j++){
				if(guming==arr_del[j]){
					flag=1;//表示当前股票被删除
					break;
				}	
			}
		}
		//当前股票被删除就不要往下走
		if(flag==1){
			flag=0;
			//alert(guming+'被删除了');
			continue;
		}
		
		//开始插入数据到本地
		xianzai=res_z['stock_info'][i]['xianzai'];
		zuoshou=res_z['stock_info'][i]['zuoshou'];
		daima=res_z['stock_info'][i]['daima'];
		a=parseFloat(xianzai);
		b=parseFloat(zuoshou);
		//得到涨跌
		c=a-b;
		c=c.toFixed(2);
		//得到涨幅
		d=c/b*100;
		d=d.toFixed(2)+'%';
		
		//插入数据到浏览器
		str=guming+'->'+xianzai+'->'+d+'->'+c+'->'+daima+'->'+2;
		storage[guming]=str;
		//alert('服务器数据插入到本地成功');
	}
	
	//如果更新数据超过9次
	if(y>9){
		y=0;
	}

	//记录更新自选股的次数
	optional_stock_num_k.innerHTML=y;

	//统计获取数据成功的次数
	y++;
	
	//数据插入到本地成功就继续从服务器获取数据
	//time_optional_stock=window.setTimeout('get_info()', 1000);
	//清除延时器
	//window.clearTimeout(time);
}

//获取当前时间
/*function get_time(){
	//获取当前时间
	var now_time=date_time(1);
	get_obj('now_time').innerHTML=now_time;
	window.setTimeout('get_time()', 1000);
}*/
/*function paixi(){
	var timeArr=[
	{'id':'A01','date':'2016年04月20日 23:22:11'},
	{'id':'A02','date':'2016年04月21日 21:00:11'},
	{'id':'A03','date':'2016年04月23日 22:00:22'},
	{'id':'A04','date':'2016年04月19日 12:22:00'},
	{'id':'A05','date':'2016年02月19日 11:11:00'}
	];

	//按日期时间正序排序
	timeArr=sort(timeArr);
	
	var str='';
	for(var i in timeArr){
		str+=timeArr[i]['date']+'\n';
	}
	alert(str);
}*/