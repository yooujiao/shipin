<!DOCTYPE html>
<html lang="zh_CN"><!-- manifest="test.appcache" -->
<head>
<!-- 添加viewport标签 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
<!-- 禁止将数字变为电话号码 -->
<meta name="format-detection" content="telephone=no"/>
<!-- 允许全屏模式浏览，隐藏浏览器导航栏 -->
<meta name="apple-mobile-web-app-capable" content="yes"/>
<!-- link标签，它支持用户将网页创建快捷方式到桌面时，其图标变为我们自己定义的图标。 -->
<link rel="apple-touch-icon-precomposed" href="http://3gimg.qq.com/wap30/info/info5/img/logo_icon.png">

<!--UC强制全屏-->
<meta name="x5-fullscreen" content="true">

<meta charset="utf-8">
<title>查询股票</title>
<link id="link" type="text/css" rel="stylesheet">
<script src='../js/my.js'></script>
<script src='../js/common.js'></script>
<script src='./gupiao.js'></script>
</head>
<body>
<div id='div_content'>
	<section class='search_info_time'>
		<!-- 输入框 -->
		<table class='table_search_info'>
		<tr>
		<td>
		<input id='input_i' type='text' value='600197' placeholder="股票代码" maxlength='6' onkeydown='abc(event)'>
		</td>
		<td id='search_stock_a'>查询股票</td>
		</tr>
		
		<tr id='p_i'>
		<td id='error_info'></td>
		<!-- <td class='now_time_k' id='now_time'></td> -->
		</tr>
		
		<!-- 停止更新数据提示 -->
		<tr>
		<td id='all_stock_info_k' style='display:none'></td>
		<td></td>
		</tr>
		</table>
	</section>
	
	<section class='sh_sz_stop'>
		<a id='optional_stock_a'>自选股票</a>
		<a id='now_stock_a'>股票</a>
		<a id='zhishu_a'>股票指数</a>
			
		<span id='optional_stock_num_k'>0</span>
		<span class='fuhao'>-></span>
		<span id='stock_num_k'>0</span>
		<a id='stop_a' style='display:none'>暂停</a>
		<!-- <span id='continue_a'>继续</span> -->
		<!-- <span id='reload_page_a'>刷新页面</span> -->
	</section>

	<section id='div_sh_sz' style='display:none'>
		<!-- 上证指数 -->
		<table id='table_sh'>
		<tr>
			<td id='close_sh_k' colspan='4'>
			<!-- <span id='close_sh_a'>关闭<span> -->
			</td>
		</tr>
		<tr>
			<td class='sh' id='sh' colspan='4'></td>
		</tr>
		<tr id='tr_sh'>
		<td id='add_sh_k' colspan='4'>
		<span id='add_sh' onclick='save_optional_stock(0,0)'>关注</span>
		</td>
		</tr>
		<tr>
			<td class='now_sh'>
			<a id='xianzai_sh'></a>
			</td>
			<td class='liange_sh'>量</td>
			<td class='left_sh' id='shuliang_sh'></td>
		</tr>
		<tr>
		<td class='up_down_sh'>
			<span id='zhangdie_sh'></span>
			<span id='zhangdielv_sh'></span>
		</td>
		<td class='liange_sh'>额</td>
		<td class='left_sh' id='jine_sh'></td>
		</tr>
		</table>
		
		<!-- 深证成指 -->
		<table id='table_sz'>
		<tr>
			<td id='close_sz_k' colspan='4'>
			<!-- <span id='close_sz_a'>关闭<span> -->
			</td>
		</tr>
		<tr>
			<td id='sz' colspan='4'></td>
		</tr>
		<tr id='tr_sz'>
		<td id='add_sz_k' colspan='4'>
		<span id='add_sz' onclick='save_optional_stock(1,0)'>关注</span>
		</td>
		</tr>
		<tr>
			<td class='now_sz'>
				<a id='xianzai_sz'></a>
			</td>
			<td class='liange_sz'>量</td>
			<td class='left_sz' id='shuliang_sz'></td>
		</tr>
		<tr>
			<td class='up_down_sz'>
				<span id='zhangdie_sz'></span>
				<span id='zhangdielv_sz'></span>
			</td>
			<td class='liange_sz'>额</td>
			<td class='left_sz' id='jine_sz'></td>
		</tr>
		</table>
	</section>

	<!-- 我的自选股 -->
	<table id='show_optional_stock' style='display:none'>
	</table>
</div>

<!-- 股票实时信息 -->
<div id='div_stock' style='display:none'>
	<table id='table_stock'>
	<tr><td id='close_stock_k' colspan='8'><a id='close_stock_a'>关闭</a></td></tr>
	<tr><td id='guming' colspan='8'></td></tr>
	<tr>
	<td id='td_add_stock' colspan='8'><span id='add_stock' onclick='save_optional_stock(2,0)'>关注</span></td>
	</tr>
	<tr>
	<td id='xianzai'></td>
	<td>高</td><td id='zuigao'></td>
	<td>开</td><td id='jinkai'></td>
	<td>量</td><td id='shuliang'></td>
	</tr>
	<tr>
		<td>
			<span id='zhangdie'></span>
			<span id='zhangfu'></span>
		</td>
		<td>低</td><td id='zuidi'></td>
		<td>昨</td><td id='zuoshou'></td>
		<td>额</td><td id='jine'></td>
	</tr>
	</table>

	<table id='table_stock_info'>
	<tr>
		<td>卖5</td><td class='jine' id='mai_5jine'></td>
		<td class='shuliang' id='mai_5shuliang'></td>
	</tr>
	<tr>
		<td>卖4</td><td class='jine' id='mai_4jine'></td>
		<td class='shuliang' id='mai_4shuliang'></td>
	</tr>
	<tr>
		<td>卖3</td><td class='jine' id='mai_3jine'></td>
		<td class='shuliang' id='mai_3shuliang'></td>
	</tr>
	<tr>
		<td>卖2</td><td class='jine' id='mai_2jine'></td>
		<td class='shuliang' id='mai_2shuliang'></td>
	</tr>
	<tr>
		<td>卖1</td><td class='jine' id='mai_1jine'></td>
		<td class='shuliang' id='mai_1shuliang'></td>
	</tr>

	<tr><td class='td_c' colspan='3'></td></tr>

	<tr>
		<td>买1</td><td class='jine' id='ai_1jine'></td>
		<td class='shuliang' id='ai_1shuliang'></td>
	</tr>
	<tr>
		<td>买2</td><td class='jine' id='ai_2jine'></td>
		<td class='shuliang' id='ai_2shuliang'></td>
	</tr>
	<tr>
		<td>买3</td><td class='jine' id='ai_3jine'></td>
		<td class='shuliang' id='ai_3shuliang'></td>
	</tr>
	<tr>
		<td>买4</td><td class='jine' id='ai_4jine'></td>
		<td class='shuliang' id='ai_4shuliang'></td>
	</tr>
	<tr>
		<td>买5</td><td class='jine' id='ai_5jine'></td>
		<td class='shuliang' id='ai_5shuliang'></td>
	</tr>
	</table>
</div>

<!-- 编辑股票 -->
<table id='set_optional_stock' style='display:none'>
</table>

<div id='black' style='display:none'>
<p id='guanzhu_k'>
<span>关注成功</span>
</p>
</div>
</body>
</html>