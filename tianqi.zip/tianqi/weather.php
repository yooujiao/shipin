<?php 
  
function city_weather(){
	//session_start();
	/*if(!empty($_POST)){
		$_SESSION['city']=$_POST;
	}
	return $_SESSION['city'];*/
	
	$city=trim($_POST['search_city']);//接收城市名
	//return $city;
	$url='http://wthrcdn.etouch.cn/weather_mini?city='.$city; 
	$str=file_get_contents($url);//调用接口获得天气数据
	if(empty($str)){
		return 0;//天气预报数据获取失败或者天气预报接口失效 
	}
	
	//这一步很重要
	$result=gzdecode($str);//解压
	if(empty($result)){
		return 0;//天气预报数据获取失败或者天气预报接口失效 
	}

	$arr=json_decode($result, true);
	if($arr['status']==1002){
		return 1002; 
	}
	
	$a_a=array();
	//$a_a['yesterday']=$arr['data']['yesterday'];
	$a_a['jintian']=$arr['data']['forecast'][0];
	$a_a['mingtian']=$arr['data']['forecast'][1];
	$a_a['city']=$arr['data']['city'];
	$a_a['ganmao']=$arr['data']['ganmao'];
	$a_a['wendu']=$arr['data']['wendu'];
	
	/*echo '<pre>';
	print_r($arr);
	echo '</pre>';*/
	
	foreach($a_a['jintian'] as $key=>$value){ 
		$a_a['jintian'][$key]=urlencode($value); 
	}
	foreach($a_a['mingtian'] as $key=>$value){ 
		$a_a['mingtian'][$key]=urlencode($value); 
	}
	$a_a['city']=urlencode($a_a['city']);
	$a_a['ganmao']=urlencode($a_a['ganmao']);
		
	return urldecode(json_encode($a_a));
	//echo json_encode($a_a);
}
echo city_weather();
//print_r(city_weather());
