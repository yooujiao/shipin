<?php

//忽略警告
error_reporting(E_ERROR); 
ini_set("display_errors","Off");

//这里两句话很重要，第一句话告诉浏览器返回的数据是xml格式
header("Content-Type: text/html;charset=utf-8");
//告诉浏览器不要缓存数据
//header("Cache-Control: no-cache");
//session_start();
//$_SESSION['video_info_p']=$_POST['search_p'];

//获取用户外网ip
$ip=get_ip();
//echo "你的外网ip是：".$ip; 
function get_ip(){
    static $realip;
    if(isset($_SERVER)){
        if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
            $realip=$_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        else if(isset($_SERVER['HTTP_CLIENT_IP'])){
            $realip=$_SERVER['HTTP_CLIENT_IP'];
        }
        else{
            $realip=$_SERVER['REMOTE_ADDR'];
        }
    }
    else{
        if(getenv('HTTP_X_FORWARDED_FOR')){
            $realip=getenv('HTTP_X_FORWARDED_FOR');
        }
        else if(getenv('HTTP_CLIENT_IP')){
            $realip=getenv('HTTP_CLIENT_IP');
        }
        else{
            $realip=getenv('REMOTE_ADDR');
        }
    }
    return $realip;
}

//PHP获取IP 归属地方法
/**
获取 IP  地理位置
 * 淘宝IP接口
 * @Return: array
 */
function get_city($ip='')
{
    $url="http://ip.taobao.com/service/getIpInfo.php?ip=".$ip;
	//$url=iconv("utf-8","gbk",$url);
	/*if(!is_readable($url)){ //is_writeable($sessSavePath)
		echo "url地址错误";
		return false;
	}*/
	
    /*$ip=json_decode(file_get_contents($url));//字符串转数组
    if((string)$ip->code=='1'){
		
		return "ip归属地查询失败";
    }
    $data = (array)$ip->data;*/
    $json=file_get_contents($url);
	$arr=json_decode($json,true);
	/*echo "<pre>";
	print_r($arr);
	echo "</pre>";*/
	if($arr['code']=='1'){
		echo "ip归属地查询失败";
		return false;
    }
	
	/*foreach ($arr['data'] as $key=>$value)
	{
		if(!empty($value)){
			echo $key.'=>'.$value.'<br>';
		}
	}*/
	$info=array();
	$info['ip']=$arr['data']['ip'];
	$info['region']=$arr['data']['region'];
	$info['city']=$arr['data']['city'];
	$info['isp']=$arr['data']['isp'];
	//print_r($info);
	foreach($info as $key=>$value){ 
		$info[$key]=urlencode($value); 
	}
	return urldecode(json_encode($info));//数组转json易出现中文乱码
	/*echo "<br/>你的ip：{$obj->data->ip}";
	echo "<br/>你的位置：{$obj->data->region}省->{$obj->data->city}市";
	echo "<br/>你的网络：中国".$obj->data->isp;*/
	//$arr=array();
}
echo get_city($ip);



/*//方法1：
$ip = $_SERVER["REMOTE_ADDR"];
echo $ip;

//方法2：
$user_IP = ($_SERVER["HTTP_VIA"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
$user_IP = ($user_IP) ? $user_IP : $_SERVER["REMOTE_ADDR"];
echo $user_IP;

//方法3：
function getRealIp()
{
    $ip=false;
    if(!empty($_SERVER["HTTP_CLIENT_IP"])){
        $ip = $_SERVER["HTTP_CLIENT_IP"];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode (", ", $_SERVER['HTTP_X_FORWARDED_FOR']);
        if ($ip) { array_unshift($ips, $ip); $ip = FALSE; }
        for ($i = 0; $i < count($ips); $i++) {
            if (!eregi ("^(10│172.16│192.168).", $ips[$i])) {
                $ip = $ips[$i];
                break;
            }
        }
    }
    return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
}
echo getRealIp();

//方法4：
if ($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"])
{
    $ip = $HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
}
elseif ($HTTP_SERVER_VARS["HTTP_CLIENT_IP"])
{
    $ip = $HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
}
elseif ($HTTP_SERVER_VARS["REMOTE_ADDR"])
{
    $ip = $HTTP_SERVER_VARS["REMOTE_ADDR"];
}
elseif (getenv("HTTP_X_FORWARDED_FOR"))
{
    $ip = getenv("HTTP_X_FORWARDED_FOR");
}
elseif (getenv("HTTP_CLIENT_IP"))
{
    $ip = getenv("HTTP_CLIENT_IP");
}
elseif (getenv("REMOTE_ADDR"))
{
    $ip = getenv("REMOTE_ADDR");
}
else
{
    $ip = "Unknown";
}
echo $ip ;

//方法5：
if(getenv('HTTP_CLIENT_IP')) {
    $onlineip = getenv('HTTP_CLIENT_IP');
} elseif(getenv('HTTP_X_FORWARDED_FOR')) {
    $onlineip = getenv('HTTP_X_FORWARDED_FOR');
} elseif(getenv('REMOTE_ADDR')) {
    $onlineip = getenv('REMOTE_ADDR');
} else {
    $onlineip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
}
echo $onlineip; 
*/

