-- phpMyAdmin SQL Dump
-- version 4.7.0-beta1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2019-09-10 17:58:14
-- 服务器版本： 5.5.27
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db3`
--

-- --------------------------------------------------------

--
-- 表的结构 `audio`
--

CREATE TABLE `audio` (
  `userAudioId` int(11) NOT NULL,
  `userAudio` varchar(99) DEFAULT NULL COMMENT '用户音乐',
  `uploadUser` varchar(99) DEFAULT NULL COMMENT '上传用户',
  `isDownTheSong` int(1) NOT NULL DEFAULT '0' COMMENT '是否下架',
  `uploadDate` datetime DEFAULT NULL COMMENT '文件上传日期'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `audio`
--

INSERT INTO `audio` (`userAudioId`, `userAudio`, `uploadUser`, `isDownTheSong`, `uploadDate`) VALUES
(4, '冷漠、云菲菲 - 爱的血泪史.mp3', 'yingzi', 0, '2017-12-12 00:00:00'),
(6, '杨梓文祺 - 谁是我的郎.mp3', 'yingzi', 1, '2017-12-15 00:00:00'),
(7, '郑源 - 当我孤独的时候还可以抱着你.mp3', 'yingzi', 1, '2017-12-15 00:00:00'),
(9, '张津涤 - 一百个放心 (DJ版).mp3', 'yingzi', 1, '2018-01-09 00:00:00'),
(10, 'DJ何鹏、张津涤 - 一百个放心.mp3', 'yingzi', 1, '2018-01-09 00:00:00'),
(11, '王绎龙、戴雪儿 - 摇啊摇 (DJ版).mp3', 'yingzi', 1, '2018-01-09 00:00:00'),
(12, 'S.H.E - Super Star.mp3', 'yingzi', 1, '2018-01-09 00:00:00'),
(13, '火火的姑娘.mp3', 'yingzi', 1, '2018-01-15 00:00:00'),
(14, '杨梓文祺 - 郎财女貌.mp3', 'yingzi', 1, '2018-01-19 00:00:00'),
(24, '李飞、田毅 - 香剑吟 (TV版).mp3', 'hongyee3', 1, '2018-01-23 00:00:00'),
(25, '苏有朋-醉春风(倚天屠龙记主题曲).mp3', 'hongyee3', 1, '2018-01-23 00:00:00'),
(29, '陈慧娴 - 逝去的诺言.mp3', 'yooujiao', 1, '2018-01-23 00:00:00'),
(30, '陈慧娴 - 孤单背影.mp3', 'hongye', 0, '2018-01-24 00:00:00'),
(34, '陈慧娴 - 多少柔情多少梦.mp3', 'hongye', 0, '2018-01-24 00:00:00'),
(35, '陈慧娴 - 飘雪.mp3', 'hongye', 0, '2018-01-24 00:00:00'),
(37, '刘小慧 - 初恋情人.mp3', 'yooujiao', 1, '2018-01-31 18:18:53'),
(38, '夏鸣 - 享受寂寞 (DJ王志版).mp3', 'yooujiao', 1, '2018-01-31 18:18:53'),
(39, '陈慧娴 - 傻女.mp3', 'yooujiao', 1, '2018-02-05 12:41:34'),
(43, '陈慧娴 - 玻璃窗的爱.mp3', 'zujiao', 0, '2018-02-05 21:24:33'),
(46, '庄心妍 - 爱囚.mp3', 'zujiao', 0, '2018-02-05 21:26:54'),
(47, '庄心妍 - 错爱.mp3', 'zujiao', 0, '2018-02-05 21:26:54'),
(50, '东方红艳 - 火火的姑娘.mp3', 'hongyee3', 1, '2018-02-14 21:52:30'),
(51, '陈慧娴 - 孤单背影.mp3', 'yooujiao', 1, '2018-02-19 21:40:20'),
(54, '陈慧娴 - 飘雪.mp3', 'yooujiao', 1, '2018-02-19 21:40:21'),
(56, '龚玥 - 十送红军.mp3', 'yooujiao', 1, '2018-08-06 08:48:45'),
(59, '笑傲江湖03版插曲 - 有所思.mp3', 'yingzi', 1, '2018-08-11 21:10:58'),
(60, '笑傲江湖03版插曲 - 有所思.mp3', '小伟12345', 0, '2018-08-16 20:20:15'),
(64, '王绎龙、戴雪儿 - 摇啊摇 (DJ版).mp3', 'yooujiao', 1, '2018-08-21 19:33:03'),
(66, '张津涤 - 一百个放心 (DJ版).mp3', 'yooujiao', 1, '2018-08-21 19:33:03'),
(67, '龚玥 - 我要去西藏.mp3', 'yooujiao', 1, '2018-08-29 17:23:25'),
(68, '忽然好想念_唐古_忽然好想念.mp3', 'yooujiao', 0, '2019-03-28 19:20:50');

-- --------------------------------------------------------

--
-- 表的结构 `gupiao`
--

CREATE TABLE `gupiao` (
  `mingzi` varchar(5) DEFAULT NULL COMMENT '股票名称',
  `daima` varchar(9) DEFAULT NULL COMMENT '股票代码',
  `shiyinglv` varchar(9) DEFAULT NULL COMMENT '股票市盈率',
  `meigushouyi` varchar(10) DEFAULT NULL COMMENT '股票每股收益',
  `liutongguben` varchar(10) DEFAULT NULL COMMENT '股票流通股本',
  `zongguben` varchar(10) DEFAULT NULL COMMENT '股票总股本',
  `junxian1` varchar(9) DEFAULT NULL COMMENT '股票均线1',
  `junxian2` varchar(9) DEFAULT NULL COMMENT '股票均线2',
  `junxian3` varchar(9) DEFAULT NULL COMMENT '股票均线3',
  `lingyu` varchar(5) DEFAULT NULL COMMENT '股票领域',
  `jilushijian` date DEFAULT NULL COMMENT '股票记录时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='股票';

--
-- 转存表中的数据 `gupiao`
--

INSERT INTO `gupiao` (`mingzi`, `daima`, `shiyinglv`, `meigushouyi`, `liutongguben`, `zongguben`, `junxian1`, `junxian2`, `junxian3`, `lingyu`, `jilushijian`) VALUES
('古越龙山', '600059', '40.65', '0.21元', '8.09亿', '8.09亿', '9.12元', '9.35元', '6.88元', '白酒', '2019-04-22'),
('华北制药', '600812', '70.43', '0.02元', '16.31亿', '16.31亿', '6.06元', '7.25元', '5.61元', '医药', '2019-04-22'),
('益伯制药', '600594', '22.21', '0.25元', '7.92亿', '7.92亿', '11.06元', '14.99元', '12.44元', '医药', '2019-04-22'),
('金陵药业', '000919', '18.51', '0.48元', '5.03亿', '5.04亿', '9.19元', '11.79元', '10.04元', '医药', '2019-04-22'),
('青青稞酒', '002646', '54.62', '0.24元', '4.5亿', '4.5亿', '13.33元', '15.11元', '17.50元', '白酒', '2019-04-22'),
('时代出版', '600551', '16.68', '0.65元', '5.06亿', '5.06亿', '12.69元', '15.29元', '13.08元', '传媒出版', '2019-04-22'),
('长江传媒', '600757', '10.84', '0.52元', '12.13亿', '12.14亿', '8.22元', '7.43元', '5.78元', '传媒出版', '2019-04-22'),
('北大医药', '000788', '79.97', '0.03元', '5.96亿', '5.96亿', '11.79元', '10.11元', '6.18元', '医药', '2019-04-22'),
('会稽山', '601579', '27.74', '0.36元', '4亿', '4.97亿', '9.79元', '10.50元', '11.32元', '白酒', '2019-04-22'),
('今世缘', '603369', '13.50', '0.51元', '12.54亿', '12.54亿', '27.12元', '18.37元', '16.65元', '白酒', '2019-04-22'),
('伊力特', '600197', '20.70', '1元', '4.41亿', '4.41亿', '19.01元', '15.31元', '12.97元', '白酒', '2019-04-22'),
('酒鬼酒', '000799', '27.87', '0.22元', '3.25亿', '3.25亿', '18.94元', '20.14元', '14.28元', '白酒', '2019-04-22'),
('迎驾贡酒', '603198', '21.77', '0.62元', '8亿', '8亿', '17.92元', '16.35元', '17.50元', '白酒', '2019-04-22');

-- --------------------------------------------------------

--
-- 表的结构 `stock`
--

CREATE TABLE `stock` (
  `mingzi` varchar(5) DEFAULT NULL COMMENT '股票名称',
  `daima` mediumint(6) UNSIGNED DEFAULT NULL COMMENT '股票代码',
  `shiyinglv` decimal(6,2) UNSIGNED DEFAULT NULL COMMENT '股票市盈率',
  `meigushouyi` float DEFAULT NULL COMMENT '股票每股收益',
  `liutongguben` decimal(6,2) UNSIGNED DEFAULT NULL COMMENT '股票流通股本',
  `zongguben` decimal(6,2) UNSIGNED DEFAULT NULL COMMENT '股票总股本',
  `junxian1` decimal(6,2) DEFAULT NULL COMMENT '股票均线1',
  `junxian2` decimal(6,2) DEFAULT NULL COMMENT '股票均线2',
  `junxian3` decimal(6,2) DEFAULT NULL COMMENT '股票均线3',
  `lingyu` varchar(5) DEFAULT NULL COMMENT '股票领域',
  `jilushijian` datetime DEFAULT NULL COMMENT '股票记录时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='股票';

--
-- 转存表中的数据 `stock`
--

INSERT INTO `stock` (`mingzi`, `daima`, `shiyinglv`, `meigushouyi`, `liutongguben`, `zongguben`, `junxian1`, `junxian2`, `junxian3`, `lingyu`, `jilushijian`) VALUES
('古越龙山', 600059, '40.65', 0.21, '8.09', '8.09', '9.12', '9.35', '6.88', '白酒', '2019-04-23 23:04:53'),
('华北制药', 600812, '70.43', 0.02, '16.31', '16.31', '6.06', '7.25', '5.61', '医药', '2019-04-24 14:23:58'),
('益伯制药', 600594, '22.21', 0.25, '7.92', '7.92', '11.06', '14.99', '12.44', '医药', '2019-04-24 14:25:38'),
('金陵药业', 919, '18.51', 0.48, '5.03', '5.04', '9.19', '11.79', '10.04', '医药', '2019-04-24 14:29:26'),
('青青稞酒', 2646, '54.62', 0.24, '4.50', '4.50', '13.33', '15.11', '17.50', '白酒', '2019-04-24 14:31:03'),
('时代出版', 600551, '16.68', 0.65, '5.06', '5.06', '12.69', '15.29', '13.08', '传媒出版', '2019-04-24 14:34:21'),
('长江传媒', 600757, '10.84', 0.52, '12.13', '12.14', '8.22', '7.43', '5.78', '传媒出版', '2019-04-24 14:35:58'),
('北大医药', 788, '79.97', 0.03, '5.96', '5.96', '11.79', '10.11', '6.18', '医药', '2019-04-24 14:37:31'),
('会稽山', 601579, '27.74', 0.36, '4.00', '4.97', '9.79', '10.50', '11.32', '白酒', '2019-04-24 14:39:45'),
('今世缘', 603369, '13.50', 0.51, '12.54', '12.54', '27.12', '18.37', '16.65', '白酒', '2019-04-24 14:41:17'),
('伊力特', 600197, '20.70', 1, '4.41', '4.41', '19.01', '15.31', '12.97', '白酒', '2019-04-24 14:42:57'),
('酒鬼酒', 799, '27.87', 0.22, '3.25', '3.25', '18.94', '20.14', '14.28', '白酒', '2019-04-24 14:44:19'),
('迎驾贡酒', 603198, '21.77', 0.62, '8.00', '8.00', '17.92', '16.35', '17.50', '白酒', '2019-04-24 14:46:51');

-- --------------------------------------------------------

--
-- 表的结构 `user_info`
--

CREATE TABLE `user_info` (
  `userName` varchar(99) DEFAULT NULL COMMENT '用户名',
  `userSex` varchar(9) DEFAULT NULL COMMENT '用户性别',
  `userPassword` varchar(99) DEFAULT NULL COMMENT '用户密码',
  `userQq` varchar(99) DEFAULT NULL COMMENT '用户qq',
  `userEmail` varchar(99) DEFAULT NULL COMMENT '用户邮箱',
  `userRegDate` datetime DEFAULT NULL COMMENT '用户注册日期'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user_info`
--

INSERT INTO `user_info` (`userName`, `userSex`, `userPassword`, `userQq`, `userEmail`, `userRegDate`) VALUES
('yingzi', '男', '5c3c1b755129ce48e22ade9c1c7432f8', '768326801', '768326801@qq.com', '2017-11-24 00:00:00'),
('yooujiao', '女', '9e3859ca8ca80b6919c9081f9f489580', '123456', 'ptuoshan5@163.com', '2017-11-24 00:00:00'),
('hongyee3', '女', 'e864c4f387fdff93b03f8bb022c3d995', '759092885', 'ptuoshan5@163.com', '2017-11-26 00:00:00'),
('yingzhi', '女', 'acb652721b29ce4809fa89b4e5e1a11a', '75909288', 'ptuoshan5@163.com', '2017-11-26 00:00:00'),
('小红3366', '女', 'be81c01033c7b0c460413aba36bb5b1c', '759092885', 'ptuoshan5@163.com', '2017-12-13 00:00:00'),
('zhujiao', '女', '65e670d6919bf425bcfbe5fb407c6fd4', '2317570145', 'ptuoshan@163.com', '2018-01-24 00:00:00'),
('zujiao', '男', 'b502f753863ea04015e86728bd660db4', '123456', '123456@qq.com', '2018-01-24 00:00:00'),
('hongye', '女', 'be81c01033c7b0c460413aba36bb5b1c', '123456', '123456@163.com', '2018-01-24 00:00:00'),
('jjjfdfbbb', '男', 'e10adc3949ba59abbe56e057f20f883e', '123456', '999@qq.com', '2018-02-17 19:51:55'),
('fgjjmggjj', '男', 'e10adc3949ba59abbe56e057f20f883e', '123456', '123456@souhu.com', '2018-02-17 19:56:23'),
('ffhnnhjjk', '男', 'e10adc3949ba59abbe56e057f20f883e', '123456', '123456@sou.com', '2018-02-20 17:58:08'),
('1234568899', '男', 'e10adc3949ba59abbe56e057f20f883e', '123456', '123456@so.com', '2018-02-20 18:02:01'),
('小伟12345', '男', 'ad7a17d5c01bf9fa199262e2e2808874', '1842660772', '1842660772@qq.com', '2018-08-16 20:18:20'),
('lsllslsl', '男', 'e10adc3949ba59abbe56e057f20f883e', '768326801', '123@qq.com', '2019-03-13 14:30:16'),
('小风123456', '男', 'be81c01033c7b0c460413aba36bb5b1c', '768326801', 'xiaofeng@qq.com', '2019-03-25 21:21:25');

-- --------------------------------------------------------

--
-- 表的结构 `video`
--

CREATE TABLE `video` (
  `userVideoId` int(11) NOT NULL COMMENT '用户视频id',
  `userVideo` varchar(99) DEFAULT NULL COMMENT '用户视频',
  `uploadUser` varchar(99) DEFAULT NULL COMMENT '上传用户',
  `uploadDate` datetime DEFAULT NULL COMMENT '上传文件日期'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `video`
--

INSERT INTO `video` (`userVideoId`, `userVideo`, `uploadUser`, `uploadDate`) VALUES
(130, '张惠妹 - 听海.mp4', 'yooujiao', '2018-01-22 00:00:00'),
(131, '笑傲江湖 01版 40_高清.mp4', 'hongyee3', '2018-01-23 00:00:00'),
(132, '楚留香传奇 08_高清.mp4', 'hongyee3', '2018-01-23 00:00:00'),
(133, '张惠妹 - 听海 - 副本 (3).mp4', 'yooujiao', '2018-02-05 18:20:23'),
(134, '张惠妹 - 听海 - 副本.mp4', 'yooujiao', '2018-02-05 18:20:23'),
(135, '张惠妹 - 听海.mp4', 'yooujiao', '2018-02-05 18:20:24'),
(136, '张惠妹 - 听海 - 副本 (3).mp4', 'yooujiao', '2018-02-05 18:22:49'),
(137, '张惠妹 - 听海 - 副本.mp4', 'yooujiao', '2018-02-05 18:22:49'),
(138, '张惠妹 - 听海.mp4', 'yooujiao', '2018-02-05 18:22:49'),
(139, '张惠妹 - 听海 - 副本 (2).mp4', 'yooujiao', '2018-02-05 18:31:53'),
(140, '张惠妹 - 听海 - 副本 (2).mp4', 'yooujiao', '2018-02-05 18:36:00'),
(141, '张惠妹 - 听海 - 副本 (2).mp4', 'yooujiao', '2018-02-05 18:36:19'),
(142, '张惠妹 - 听海 - 副本 (2).mp4', 'yooujiao', '2018-02-05 18:36:30'),
(143, '张惠妹 - 听海 - 副本 (3).mp4', 'yooujiao', '2018-02-05 18:38:11'),
(144, '张惠妹 - 听海 (2).mp4', 'yooujiao', '2018-02-05 21:08:38'),
(145, 'wx_camera_1553758862534.mp4', 'yooujiao', '2019-03-28 19:10:57'),
(146, '龙梅子 - 泪满天.mp4', 'yooujiao', '2019-04-29 14:14:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audio`
--
ALTER TABLE `audio`
  ADD PRIMARY KEY (`userAudioId`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`userVideoId`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `audio`
--
ALTER TABLE `audio`
  MODIFY `userAudioId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- 使用表AUTO_INCREMENT `video`
--
ALTER TABLE `video`
  MODIFY `userVideoId` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户视频id', AUTO_INCREMENT=147;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
